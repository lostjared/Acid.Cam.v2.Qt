# Example pro file for Windows

Replace the hardcoded paths with the ones you have for your current version of OpenCV compiled  with Visual Studio.
Copy this pro into a new directory with the source files and qrc file.

Also copy ac.h ac.cpp fractal.h fractal.cpp from libacidcam into the directory as well they can be found here:

https://github.com/lostjared/libacidcam/tree/master/source

Using Qt Creator call qmake on the file and it will build Makefiles for Visual Studio.


