/* Acid Cam Functions for OpenCV
 * written by Jared Bruni https://github.com/lostjared
 
 This software is dedicated to all the people that struggle with mental illness.
 
 Website: http://lostsidedead.com
 YouTube: http://youtube.com/LostSideDead
 Instagram: http://instagram.com/jaredbruni
 Twitter: http://twitter.com/jaredbruni
 Facebook: http://facebook.com/LostSideDead0x
 
 You can use this program free of charge and redistrubute as long
 as you do not charge anything for this program. This program is 100%
 Free.
 
 BSD 2-Clause License
 
 Copyright (c) 2018, Jared Bruni
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 
 * Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.
 
 * Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 */
#include "ac.h"
#include "fractal.h"



// Acid Cam namespace
namespace ac {
    const std::string version="2.4.3";
    // variables
    unsigned int swapColor_r = 0, swapColor_g = 0, swapColor_b = 0;
    bool isNegative = false, noRecord = false, pass2_enabled = false, blendW = false, slide_Show = false, slide_Rand = false, strobe_It = false, switch_Back = false, blur_First = false;
    bool images_Enabled = false, fps_force = false,iRev = false;
    bool blur_Second = false;
    int set_color_map = 0;
    cv::Mat orig_frame;
    cv::Mat blendW_frame;
    cv::Mat image_files[4];
    double alpha = 1.0f, tr = 0.01f;
    double fps = 29.97;
    int draw_offset = 0;
    bool snapShot = false;
    int color_order = 0;
    int snapshot_Type = 0;
    bool in_custom = false;
    cv::Size resolution(0, 0);
    std::string fileName ="VideoFile.avi";
    std::string draw_strings_value[] = { "Self AlphaBlend", "Self Scale", "StrobeEffect", "Blend #3", "Negative Paradox","ThoughtMode", "RandTriBlend", "Blank", "Tri", "Distort", "CDraw", "Type", "NewOne", "Blend Fractal","Blend Fractal Mood", "CosSinMultiply", "Color Accumlate1", "Color Accumulate2", "Color Accumulate3", "Filter8","Filter3","Rainbow Blend","Rand Blend","New Blend", "Alpha Flame Filters", "Pixel Scale", "PixelSort", "GlitchSort","Random Filter", "Random Flash", "Blend with Image", "Blend with Image #2", "Blend with Image #3", "Blend with Image #4", "GaussianBlur", "Median Blur", "Blur Distortion", "Diamond Pattern","MirrorBlend","Pulse","Sideways Mirror","Mirror No Blend","Sort Fuzz","Fuzz","Double Vision","RGB Shift","RGB Sep","Graident Rainbow","Gradient Rainbow Flash", "Reverse", "Scanlines", "TV Static", "Mirror Average", "Mirror Average Mix", "Mean", "Laplacian", "Bitwise_XOR", "Bitwise_AND","Bitwise_OR","Equalize", "Channel Sort", "Reverse_XOR", "Combine Pixels", "FlipTrip", "Canny","Boxes","Boxes Fade", "Flash Black","SlideRGB","Side2Side","Top2Bottom","Strobe Red Then Green Then Blue","Blend_Angle", "Outward", "Outward Square","ShiftPixels", "ShiftPixelsDown", "XorMultiBlend", "Bitwise_Rotate", "Bitwise_Rotate Diff","HPPD","FuzzyLines","GradientLines","GradientSelf","GradientSelfVertical","GradientDown","GraidentHorizontal","GradientRGB","Inter","UpDown","LeftRight","StrobeScan","BlendedScanLines","GradientStripes","XorSine","SquareSwap","SquareSwap4x2","SquareSwap8x4","SquareSwap16x8","SquareSwap64x32","SquareBars","SquareBars8","SquareSwapRand16x8","SquareVertical8","SquareVertical16","SquareVertical_Roll","SquareSwapSort_Roll","SquareVertical_RollReverse","SquareSwapSort_RollReverse","Circular","WhitePixel","FrameBlend","FrameBlendRGB","TrailsFilter","TrailsFilterIntense","TrailsFilterSelfAlpha","TrailsFilterXor","ColorTrails","MoveRed","MoveRGB","MoveRedGreenBlue","BlurSim","Block","BlockXor","BlockScale","BlockStrobe","PrevFrameBlend","Wave","HighWave","VerticalSort","VerticalChannelSort","HorizontalBlend","VerticalBlend","OppositeBlend","DiagonalLines","HorizontalLines","InvertedScanlines","Soft_Mirror","KanapaTrip","ColorMorphing","ScanSwitch","ScanAlphaSwitch","NegativeStrobe", "XorAddMul","ParticleRelease", "BlendSwitch", "All Red", "All Green", "All Blue","LineRGB","PixelRGB","BoxedRGB","KruegerSweater","RGBFlash","IncreaseBlendHorizontal","BlendIncrease","GradientReverse","GradientReverseVertical","GradientReverseBox","GradientNewFilter","ReinterpretDouble","ReinterpSelfScale","AverageLines","ImageFile","ImageXor","ImageAlphaBlend","ColorRange","ImageInter","TrailsInter","TrailsBlend","TrailsNegate","InterReverse","InterMirror","InterFullMirror","MirrorRGB","RGBStatic1","RGBStatic2","VectorIncrease","LineByLineReverse","RandomIntertwine","RandomFour","BlendThree","AcidTrails","RandomTwo","HorizontalTrailsInter","Trails","BlendTrails","Negate","RandomFilteredSquare","ImageX","RandomQuads","QuadCosSinMultiply","QuadRandomFilter","RollRandom","AverageRandom","HorizontalStripes","DiamondStrobe","SmoothTrails","GridFilter8x","GridFilter16x","GridFilter8xBlend","GridRandom","GridRandomPixel","Dual_SelfAlphaRainbow","Dual_SelfAlphaBlur","SurroundPixelXor","Darken","WeakBlend","AverageVertical","RandomCollectionAverage","RandomCollectionAverageMax","SmoothTrailsSelfAlphaBlend","SmoothTrailsRainbowBlend","MedianBlend","SmoothRandomImageBlend","SmoothImageAlphaBlend","RandomAlphaBlend","RandomTwoFilterAlphaBlend","PixelatedSquare","AlphaBlendPosition","BlendRowAlpha", "BlendRow","BlendRowByVar","BlendRowByDirection","BlendAlphaXor","SelfXorScale","BitwiseXorScale","XorTrails", "RainbowTrails","NegativeTrails","IntenseTrails","SelfAlphaRGB","BlendImageOnOff","XorSelfAlphaImage","BitwiseXorStrobe","AlphaBlendRandom","ChannelSortAlphaBlend","XorChannelSort","GradientColors","GradientColorsVertical","Bitwise_XOR_Average","NotEqual","ImageShiftUpLeft","GradientXorSelfScale","SmoothSourcePixel","StrobeBlend","FrameBars","Sort_Vertical_Horizontal","Sort_Vertical_Horizontal_Bitwise_XOR","Scalar_Average_Multiply","Scalar_Average","Total_Average","AlphaBlendImageXor","FlashWhite","FlashBlackAndWhite", "No Filter","Blend with Source", "Plugin", "Custom","Blend With Image #1","TriBlend with Image", "Image Strobe", "Image distraction" };
    // draw strings
    std::string *draw_strings = draw_strings_value;
    // filter callback functions
    DrawFunction draw_func_value[] = { SelfAlphaBlend, SelfScale, StrobeEffect, Blend3, NegParadox, ThoughtMode, RandTriBlend, Blank,Tri,Distort,CDraw,Type,NewOne,blendFractal,blendFractalMood,cossinMultiply,colorAccumulate1,colorAccumulate2,colorAccumulate3,filter8,filter3,rainbowBlend,randBlend,newBlend,alphaFlame,pixelScale,pixelSort,glitchSort,randomFilter,randomFlash,imageBlend,imageBlendTwo,imageBlendThree,imageBlendFour,GaussianBlur,MedianBlur,BlurDistortion,DiamondPattern,MirrorBlend,Pulse,SidewaysMirror,MirrorNoBlend,SortFuzz,Fuzz,DoubleVision,RGBShift,RGBSep,GradientRainbow,GradientRainbowFlash,Reverse,Scanlines,TVStatic,MirrorAverage,MirrorAverageMix,Mean,Laplacian,Bitwise_XOR,Bitwise_AND,Bitwise_OR,Equalize,ChannelSort,Reverse_XOR,CombinePixels,FlipTrip,Canny,Boxes,BoxesFade,FlashBlack,SlideRGB,Side2Side,Top2Bottom,StrobeRedGreenBlue,Blend_Angle,Outward,OutwardSquare,ShiftPixels,ShiftPixelsDown,XorMultiBlend,BitwiseRotate,BitwiseRotateDiff,HPPD,FuzzyLines,GradientLines,GradientSelf,GradientSelfVertical,GradientDown,GraidentHorizontal,GradientRGB,Inter,UpDown,LeftRight,StrobeScan,BlendedScanLines,GradientStripes,XorSine,SquareSwap,SquareSwap4x2,SquareSwap8x4,SquareSwap16x8,SquareSwap64x32,SquareBars,SquareBars8,SquareSwapRand16x8,SquareVertical8,SquareVertical16,SquareVertical_Roll,SquareSwapSort_Roll,SquareVertical_RollReverse,SquareSwapSort_RollReverse,Circular,WhitePixel,FrameBlend,FrameBlendRGB,TrailsFilter,TrailsFilterIntense,TrailsFilterSelfAlpha,TrailsFilterXor,ColorTrails,MoveRed,MoveRGB,MoveRedGreenBlue,BlurSim,Block,BlockXor,BlockScale,BlockStrobe,PrevFrameBlend,Wave,HighWave,VerticalSort,VerticalChannelSort,HorizontalBlend,VerticalBlend,OppositeBlend,DiagonalLines,HorizontalLines,InvertedScanlines,Soft_Mirror,KanapaTrip,ColorMorphing,ScanSwitch,ScanAlphaSwitch,NegativeStrobe,XorAddMul,ParticleRelease,BlendSwitch,AllRed,AllGreen,AllBlue,LineRGB,PixelRGB,BoxedRGB,KruegerSweater,RGBFlash,IncreaseBlendHorizontal,BlendIncrease,GradientReverse,GradientReverseVertical,GradientReverseBox,GradientNewFilter,ReinterpretDouble,ReinterpSelfScale,AverageLines,ImageFile,ImageXor,ImageAlphaBlend,ColorRange,ImageInter,TrailsInter,TrailsBlend,TrailsNegate,InterReverse,InterMirror,InterFullMirror,MirrorRGB,RGBStatic1,RGBStatic2,VectorIncrease,LineByLineReverse,RandomIntertwine,RandomFour,BlendThree,AcidTrails,RandomTwo,HorizontalTrailsInter,Trails,BlendTrails,Negate,RandomFilteredSquare,ImageX,RandomQuads,QuadCosSinMultiply,QuadRandomFilter,RollRandom,AverageRandom,HorizontalStripes,DiamondStrobe,SmoothTrails,GridFilter8x,GridFilter16x,GridFilter8xBlend,GridRandom,GridRandomPixel,Dual_SelfAlphaRainbow,Dual_SelfAlphaBlur,SurroundPixelXor,Darken,WeakBlend,AverageVertical,RandomCollectionAverage,RandomCollectionAverageMax,SmoothTrailsSelfAlphaBlend,SmoothTrailsRainbowBlend,MedianBlend,SmoothRandomImageBlend,SmoothImageAlphaBlend,RandomAlphaBlend,RandomTwoFilterAlphaBlend,PixelatedSquare,AlphaBlendPosition,BlendRowAlpha,BlendRow,BlendRowByVar,BlendRowByDirection,BlendAlphaXor,SelfXorScale,BitwiseXorScale,XorTrails,RainbowTrails,NegativeTrails,IntenseTrails,SelfAlphaRGB,BlendImageOnOff,XorSelfAlphaImage,BitwiseXorStrobe,AlphaBlendRandom,ChannelSortAlphaBlend,XorChannelSort,GradientColors,GradientColorsVertical,Bitwise_XOR_Average,NotEqual,ImageShiftUpLeft,GradientXorSelfScale,SmoothSourcePixel,StrobeBlend,FrameBars,Sort_Vertical_Horizontal,Sort_Vertical_Horizontal_Bitwise_XOR,Scalar_Average_Multiply,Scalar_Average,Total_Average,AlphaBlendImageXor,FlashWhite,FlashBlackAndWhite,NoFilter,BlendWithSource,plugin,custom,blendWithImage, triBlendWithImage,imageStrobe, imageDistraction,0};
    // draw functions
    DrawFunction *draw_func = draw_func_value;
    // number of filters
    int draw_max = 262;
    // variables
    double translation_variable = 0.001f, pass2_alpha = 0.75f;
    // swap colors inline function
    std::unordered_map<std::string, int> filter_map;
    bool color_map_set = false;
    DrawFunction custom_callback = 0;
    DrawFunction plugin_func = 0;
    int colors[3] = {rand()%255, rand()%255, rand()%255};
    unsigned int proc_mode = 0;
    bool reset_filter = false;
    double alpha_increase = 0;
}

std::string ac::getVersion() {
    return version;
}

ac::Point::Point() : x(0), y(0) {}
ac::Point::Point(const ac::Point &p) : x(p.x), y(p.y) {}
ac::Point::Point(unsigned int xx, unsigned int yy) : x(xx), y(yy) {}

ac::Point &ac::Point::operator=(const ac::Point &p) {
    x = p.x;
    y = p.y;
    return *this;
}

void ac::Point::setPoint(unsigned int xx, unsigned int yy) {
    x = xx;
    y = yy;
}

ac::Rect::Rect() : x(0), y(0), w(0), h(0) {}
ac::Rect::Rect(const ac::Rect &r) : x(r.x), y(r.y), w(r.w), h(r.h) {}
ac::Rect::Rect(unsigned int xx, unsigned int yy, unsigned int ww, unsigned int hh) : x(xx), y(yy), w(ww), h(hh) {}
ac::Rect::Rect(unsigned int xx, unsigned int yy) : x(xx), y(yy), w(0), h(0) {}
ac::Rect::Rect(unsigned int xx, unsigned int yy, cv::Size s) : x(xx), y(yy), w(s.width), h(s.height) {}
ac::Rect::Rect(Point pt, unsigned int ww, unsigned int hh) : x(pt.x), y(pt.y), w(ww), h(hh) {}
ac::Rect::Rect(Point pt, cv::Size s) : x(pt.x), y(pt.y), w(s.width), h(s.height){}

ac::Rect &ac::Rect::operator=(const ac::Rect &r) {
    x = r.x;
    y = r.y;
    w = r.w;
    h = r.h;
    return *this;
}

void ac::Rect::setRect(unsigned int xx, unsigned int yy, unsigned int ww, unsigned int hh) {
    x = xx;
    y = yy;
    w = ww;
    h = hh;
}
// globals
cv::Mat blend_image, color_image;
bool blend_set = false;
bool colorkey_set = false;

void ac::fill_filter_map() {
    for(int i = 0; i < ac::draw_max; ++i) {
        filter_map[draw_strings[i]] = i;
    }
}

void ac::DrawFilter(const std::string &name, const cv::Mat &frame, cv::Mat &outframe) {
    outframe = frame.clone();
    ac::draw_func[filter_map[name]](outframe);
}

void ac::DrawFilter(unsigned int index, const cv::Mat &frame, cv::Mat &outframe) {
    outframe = frame.clone();
    ac::draw_func[index](outframe);
}
void ac::DrawFilter(unsigned int index, cv::Mat &frame) {
    ac::draw_func[index](frame);
    
}
void ac::DrawFilter(const std::string &name, cv::Mat &frame) {
    ac::draw_func[filter_map[name]](frame);
}


// swapColors inline function takes frame and x, y position
inline void ac::swapColors(cv::Mat &frame, int y, int x) {
    if(in_custom == true) return;
    if(color_order == 0 && swapColor_r == 0 && swapColor_g == 0 && swapColor_b == 0) return; // if no swap needed return
    if(set_color_map > 0 && color_map_set == false) {
        return;
    }
    swapColors_(frame, y, x);
}

inline void ac::swapColors_(cv::Mat &frame, int y, int x) {
    cv::Vec3b &cur = frame.at<cv::Vec3b>(y,x);
    cur[0] += swapColor_b;
    cur[1] += swapColor_g;
    cur[2] += swapColor_r;
    cv::Vec3b temp;// temp
    temp = cur;// temp = cur
    // Default color order is BGR
    // swap RGB orders
    switch(color_order) {
        case 1: // RGB
            cur[0] = temp[2];
            cur[1] = temp[1];
            cur[2] = temp[0];
            break;
        case 2:// GBR
            cur[0] = temp[1];
            cur[1] = temp[0];
            break;
        case 3:// BRG
            cur[1] = temp[2];
            cur[2] = temp[1];
            break;
        case 4: // GRB
            cur[0] = temp[1];
            cur[1] = temp[2];
            cur[2] = temp[0];
            break;
    }
}
// invert pixel in frame at x,y
inline void ac::invert(cv::Mat &frame, int y, int x) {
    if(in_custom == true) return;
    cv::Vec3b &cur = frame.at<cv::Vec3b>(y,x);// cur pixel
    cur[0] = ~cur[0]; // bit manipulation sets opposite
    cur[1] = ~cur[1];
    cur[2] = ~cur[2];
}

// proc position
void ac::procPos(int &direction, double &pos, double &pos_max, const double max_size, double iter) {
    if(alpha_increase != 0) iter = alpha_increase;
    switch(proc_mode) {
        case 0: { // move in - increase move out movin - increase move out
            // static int direction
            // pos max
            // if direction equals 1
            if(direction == 1) {
                pos += iter; // pos plus equal 0.05
                if(pos > pos_max) { // if pos > pos max
                    pos = pos_max; // pos = pos_max
                    direction = 0;// direction equals 0
                    pos_max += 0.5; // pos_max increases by 0.5
                }
            } else if(direction == 0) {// direction equals 0
                pos -= iter;// pos -= 0.05
                if(pos <= 1.0) {// if pos <= 1.0
                    if(pos_max > max_size) pos_max = 1.0;// if pos max at maxmium
                    // set to 1.0
                    direction = 1;// set direction back to 1
                }
            }
        }
            break;
        case 1: { // flat fade in fade out
            if(direction == 1) {
                pos += iter;
                if(pos > max_size) direction = 0;
                
            } else if(direction == 0) {
                pos -= iter;
                if(pos <= 1) direction = 1;
            }
            
        }
            break;
        case 2: {
            pos += iter;
            if(pos >= pos_max) {
                pos = 1.0;
            }
        }
            break;
    }
}


void ac::setProcMode(unsigned int value) {
    proc_mode = value;
}

// SelfAlphaBlend - Perform out of Bounds AlphaBlend on source image
void ac::SelfAlphaBlend(cv::Mat &frame) {
    double alpha_inc = 0.1;
    if(alpha_increase != 0) {
        alpha_inc = alpha_increase;
    } else {
        alpha_inc = 0.1;
    }
    for(int z = 0; z < frame.rows; ++z) {// from top to bottom
        for(int i = 0; i < frame.cols; ++i) {// from left to right
            cv::Vec3b &colorval = frame.at<cv::Vec3b>(z, i);// at x,y
            colorval[0] += static_cast<unsigned char>(colorval[0]*alpha);
            colorval[1] += static_cast<unsigned char>(colorval[1]*alpha);
            colorval[2] += static_cast<unsigned char>(colorval[2]*alpha);
            swapColors(frame, z, i);// swap colors
            if(isNegative == true) { // if negative
                invert(frame, z, i);// invert
            }
        }
    }
    static int direction = 1;// direction equals 1
    if(direction == 1) {// if direction equals 1
        alpha += alpha_inc; // plus equal 0.1
        // if alpha greater than 10
        if(alpha > 10) { alpha = 10; direction = 2; }
    } else {
        alpha -= 0.05f; // minus equal 0.05
        // if alpha <= 0.1f
        if(alpha <= 0.1f) { alpha = 0.1f; direction = 1; }
    }
}
// Self Scale - Scale pixel values by double
// Takes cv::Mat reference
void ac::SelfScale(cv::Mat &frame) {
    double inc_alpha = 0.05;
    if(alpha_increase != 0)
        inc_alpha = alpha_increase;
    else
        inc_alpha = 0.05;
    static double pos = 1.0; // pos the scale
    int w = frame.cols; // width variable
    int h = frame.rows; // height variable
    for(int z = 0; z < h; ++z) {// top to bottom
        for(int i = 0; i < w; ++i) { // left to right
            // current pixel at x,y
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // scale each rgb value by pos
            pixel[0] = static_cast<unsigned char>(pixel[0] * pos);
            pixel[1] = static_cast<unsigned char>(pixel[1] * pos);
            pixel[2] = static_cast<unsigned char>(pixel[2] * pos);
            swapColors(frame, z, i);// swap colors
            // if is negative set, invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // static direction variable
    static int direction = 1;
    static double pos_max = 7.0f; // position max
    if(direction == 1) { // direction equals 1
        pos += inc_alpha; // pos plus equal 0.05
        if(pos > pos_max) { // pos greater than pos_max
            pos = pos_max; // set pos to pos_max
            direction = 0; // set direction to zero
            pos_max += 0.5f; // add 0.5 to pos_max
        }
    } else if(direction == 0) { // direction is zero
        pos += -inc_alpha; // minus equal 0.05
        if(pos <= 1.0) { // pos <= 1.0
            if(pos_max > 15) pos_max = 1.0f; // reset pos if greater than 15
            direction = 1;// set direction to 1
        }
    }
}
// StrobeEffect - Change frame values by passIndex, incrememnt each frame
void ac::StrobeEffect(cv::Mat &frame) {
    static unsigned int passIndex = 0;// passIndex variable
    static double alpha = 1.0f;// alpha is 1.0
    for (int z = 0; z < frame.cols - 2; ++z) {
        for (int i = 0; i < frame.rows - 2; ++i) {
            
            cv::Vec3b &colors = frame.at<cv::Vec3b>(i, z); // current pixel
            
            switch (passIndex) {
                case 0: // pass 0 set color values
                    colors[0] = static_cast<unsigned char>(colors[0] * (-alpha));
                    colors[1] = static_cast<unsigned char>(colors[1] * alpha);
                    colors[2] = static_cast<unsigned char>(colors[2] * alpha);
                    break;
                case 1: // pass 1 set color values
                    colors[0] += static_cast<unsigned char>(colors[0] * alpha);
                    colors[1] += static_cast<unsigned char>(colors[1] * (-alpha));
                    colors[2] += static_cast<unsigned char>(colors[2] * alpha);
                    break;
                case 2: // pass 2 set color values
                    colors[0] = static_cast<unsigned char>(colors[0] * alpha);
                    colors[1] = static_cast<unsigned char>(colors[1] * alpha);
                    colors[2] = static_cast<unsigned char>(colors[2] * (-alpha));
                    break;
                case 3: { // pass 3 grab pixels +1, and +2 ahead and use for colors
                    cv::Vec3b &color1 = frame.at<cv::Vec3b>(i + 1, z);// x,y + 1
                    cv::Vec3b &color2 = frame.at<cv::Vec3b>(i + 2, z);// x,y + 2
                    // set colors accordingly
                    colors[0] += static_cast<unsigned char>(colors[0] * alpha);
                    colors[1] += static_cast<unsigned char>(color1[1] * alpha);
                    colors[2] += static_cast<unsigned char>(color2[2] * alpha);
                    break;
                }
            }
            // swap colors
            swapColors(frame, i, z);
            if(isNegative == true) { // if negative variable set
                invert(frame, i, z);//invert pixel
            }
        }
    }
    ++passIndex; // pass index increased once each frame
    if(passIndex > 3) passIndex = 0; // if greater than 3 set back to zero
    static double max = 4.0f;// max
    if(alpha < 0) // alpha less than zero
        tr = translation_variable; // set as translation variable
    else if(alpha > max) { // greater than max
        tr = -translation_variable; // negative translation variable
        max += 3.0f;// max plus equal 3.0
        if(max > 23) max = 4.0f;// max greater than twenty three max equal four
    }
    alpha += tr; // change position
}

// Blend3
// takes cv::Mat as reference
void ac::Blend3(cv::Mat &frame) {
    static int i=0,z=0;// set i,z to zero
    static double rValue[3] = { 0, 0, 0 };
    for (z = 0; z < frame.cols; ++z) {
        for (i = 0; i < frame.rows; ++i) {
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z); // get pixel value
            for (int j = 0; j < 3; ++j)
                color_value[j] += static_cast<unsigned char>(color_value[j] * rValue[j]); // loop through each color multiply by rValue
            // swap colors
            swapColors(frame, i, z);
            if(isNegative == true) {// if isNegative true
                invert(frame, i, z);// invert pixel
            }
        }
    }
    // change rValue array based on random function
    // set to either -0.1 or 0.1
    double alpha_inc = 0.1;
    if(alpha_increase != 0)
        alpha_inc = alpha_increase;
    else
        alpha_inc = 0.1;
        
        
    for (int q = 0; q < 3; ++q)
        rValue[q] += ((rand() % 10) > 5) ? -alpha_inc : alpha_inc;
}
// takes cv::Mat reference
void ac::NegParadox(cv::Mat &frame) {
    static double alpha = 1.0f; // alpha equals 1.0
    for (int z = 0; z < frame.cols - 3; ++z) { // left to right
        for (int i = 0; i < frame.rows - 3; ++i) { // top to bottom
            cv::Vec3b colors[4];// vector array
            colors[0] = frame.at<cv::Vec3b>(i, z);// grab pixels
            colors[1] = frame.at<cv::Vec3b>(i + 1, z);
            colors[2] = frame.at<cv::Vec3b>(i + 2, z);
            colors[3] = frame.at<cv::Vec3b>(i + 3, z);
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);// grab pixel
            // set final pixel color values
            color_value[0] += static_cast<unsigned char>((colors[0][0] * alpha) + (colors[1][0] * alpha));
            color_value[1] += static_cast<unsigned char>((colors[1][1] * alpha) + (colors[3][1] * alpha));
            color_value[2] += static_cast<unsigned char>((colors[1][2] * alpha) + (colors[2][2] * alpha));
            swapColors(frame, i, z); // swap the colors
            if(isNegative == true) { // if negative is true
                invert(frame, i, z);// invert pixel
            }
        }
    }
    static double trans_var = 0.1f; // translation variable
    double translation_variable = (alpha_increase != 0) ? alpha_increase :0.1;
    if (alpha < 0)
        trans_var = translation_variable;// increase
    else if (alpha > 15)
        trans_var = -translation_variable; // decrease
    alpha += trans_var; // add variable
}

// Thought Mode
// takes cv::Mat reference
void ac::ThoughtMode(cv::Mat &frame) {
    static double alpha = 1.0f, trans_var = 0.1f; // alpha
    static int mode = 0;// current mode
    static int sw = 1, tr = 1;
    for(int z = 2; z < frame.cols-2; ++z) {
        for(int i = 2; i < frame.rows-4; ++i) {
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z); // current pixel
            // set pixel rgb values
            if(sw == 1) color_value[0] += static_cast<unsigned char>(color_value[mode]*alpha);
            if(tr == 0) color_value[mode] -= static_cast<unsigned char>(color_value[rand()%2]*alpha);
            color_value[mode] += static_cast<unsigned char>(color_value[mode]*alpha);
            mode++; // increase mode
            if(mode >= 3) mode = 0; // reset mode if greater than equal three
            swapColors(frame, i, z);// swap colors
            if(isNegative == true) { // if is negative true
                invert(frame, i, z);// invert pixel
            }
        }
    }
    sw = !sw;// not sw
    tr = !tr;// not tr
    static double max = 4.0f;
    if(alpha < 0)
        trans_var = translation_variable;
    else if(alpha > max) {
        trans_var = -translation_variable;
        max += 3.0f;
        if(max > 23) max = 4.0f;
    }
    alpha += trans_var; // add to alpha
}
// blend with original pixel
void ac::Pass2Blend(cv::Mat &frame) {
    for(int z = 0;  z < frame.rows; ++z) { // top to bottom
        for(int i = 0; i < frame.cols; ++i) { // left to right
            if(!frame.empty() && !orig_frame.empty()) {
                cv::Vec3b &color1 = frame.at<cv::Vec3b>(z, i);// current pixel
                cv::Vec3b color2 = orig_frame.at<cv::Vec3b>(z, i);// original frame pixel
                for(int q = 0; q < 3; ++q)
                    color1[q] = static_cast<unsigned char>(color2[q]+(color1[q]*ac::pass2_alpha));// multiply
            }
        }
    }
}

// Takes cv::Mat reference
void ac::RandTriBlend(cv::Mat &frame) {
    static double alpha = 1.0f;//alpha equals 1.0
    static int i = 0, z = 0;// i,z loop variables
    int counter = 0;// center variable
    cv::Vec3b colors[6];// array of six colors
    for (z = 2; z < frame.cols - 2; ++z) {
        for (i = 2; i < frame.rows - 2; ++i) {
            // grab pixels
            colors[0] = frame.at<cv::Vec3b>(i, z);
            colors[1] = frame.at<cv::Vec3b>(i + 1, z);
            colors[2] = frame.at<cv::Vec3b>(i + 2, z);
            // chaos
            counter = rand() % 3;
            if (counter == 0) { // if counter equals zero
                // set pixel values
                colors[3][0] = static_cast<unsigned char>((colors[0][0] + colors[1][0] + colors[2][0]*alpha));
                colors[3][1] = static_cast<unsigned char>((colors[0][1] + colors[1][1]) * alpha);
                colors[3][2] = static_cast<unsigned char>((colors[0][2]) * alpha);
                counter++; // increase counter
            } else if (counter == 1) { // if counter equals one
                // set pixel values
                colors[3][0] = static_cast<unsigned char>((colors[0][0]) * alpha);
                colors[3][1] = static_cast<unsigned char>((colors[0][1] + colors[1][1]) * alpha);
                colors[3][2] = static_cast<unsigned char>((colors[0][2] + colors[1][2] + colors[2][2]) * alpha);
                counter++; // increase counter
            } else {
                // set pixel values
                colors[3][0] = static_cast<unsigned char>((colors[0][0]) * alpha);
                colors[3][2] = static_cast<unsigned char>((colors[0][1] + colors[1][1]) * alpha);
                colors[3][1] = static_cast<unsigned char>((colors[0][2] + colors[1][2] + colors[2][2]) * alpha);
            }
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);// grab current pixel
            color_value = colors[3];// assign pixel
            swapColors(frame, i, z);// swap colors
            if(isNegative == true) { // if isNegative
                invert(frame, i, z);// invert pixel
            }
        }
    }
    static double max = 4.0f, trans_var = translation_variable;// max, translation variable
    if (alpha < 0) // if alpha less than zero
        trans_var = translation_variable;
    else if (alpha > max) {
        trans_var = -translation_variable;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;// add to alpha translation variable
}

// Blank
// takes cv::Mat reference
void ac::Blank(cv::Mat &frame) {
    static double alpha = 1.0f; // static alpha set to 1.0
    static unsigned char val[3] = { 0 };// val array set to zero
    static bool color_switch = false;// color switch set to false
    for(int z = 0; z < frame.cols; ++z) {// left to right
        for(int i = 0; i < frame.rows; ++i) { // top to bottom
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z); // current pixel
            for(int j = 0; j < 3; ++j) {
                // process pixel values
                val[j] = static_cast<unsigned char>((alpha*color_value[j]) / (2-j+1));
                color_value[j] += static_cast<unsigned char>(val[2-j] / (j+1));
                if(color_switch == true) color_value[j] = static_cast<unsigned char>(-color_value[j]);
            }
            swapColors(frame, i, z);
            if(isNegative == true) {
                invert(frame, i, z); // invert pixel
            }
        }
    }
    color_switch = !color_switch;// not color switch
    static double max = 4.0f, trans_var = translation_variable;
    if (alpha < 0)
        trans_var = translation_variable; // positive (up)
    else if (alpha > max) {
        trans_var = -translation_variable; // negative (down)
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var; // add to alpha trans_Var
}
// Tri
// takes cv::Mat reference
void ac::Tri(cv::Mat &frame) {
    static double alpha = 1.0f;// static alpha set to 1
    for(int z = 0; z < frame.cols-3; ++z) {// left to right
        for(int i = 0; i < frame.rows-3; ++i) {// top to bottom
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);// current pixel
            cv::Vec3b colors[2];// colors
            // grab pixels
            colors[0] = frame.at<cv::Vec3b>(i+1, z);
            colors[1] = frame.at<cv::Vec3b>(i+2, z);
            // set pixels
            color_value[0] += static_cast<unsigned char>(color_value[0]*alpha);
            color_value[1] += static_cast<unsigned char>(color_value[1]+colors[0][1]+colors[1][1]*alpha);
            color_value[2] += static_cast<unsigned char>(color_value[2]+colors[0][2]+colors[1][2]*alpha);
            swapColors(frame, i, z);// swap
            if(isNegative == true) {
                invert(frame, i, z); // invert pixel
            }
        }
    }
    static double max = 4.0f, trans_var = 0.1f;
    if (alpha < 0)
        trans_var = translation_variable; // positive (up)
    else if (alpha > max) {
        trans_var = -translation_variable; // negative (down)
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;// add to alpha trans var
}
// Distort
// takes cv::Mat reference
void ac::Distort(cv::Mat &frame) {
    static double alpha = 1.0f; // static alpha set to 1
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) { // left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);
            // set pixel values
            color_value[0] = static_cast<unsigned char>((i*alpha)+color_value[0]);
            color_value[2] = static_cast<unsigned char>((z*alpha)+color_value[2]);
            color_value[1] = static_cast<unsigned char>((alpha*color_value[1]));
            if(strobe_It == true) color_value[1] = static_cast<unsigned char>(((i+z)*alpha)+color_value[1]);
            swapColors(frame, i, z); //swap
            if(isNegative == true) {
                invert(frame, i, z);// invert
            }
        }
    }
    static double max = 4.0f, trans_var = 0.1f;
    if (alpha < 0)
        trans_var = 0.1f;
    else if (alpha > max) {
        trans_var = -0.1f;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;// add translation to alpha
}
// takes cv::Mat reference
void ac::CDraw(cv::Mat &frame) {
    static int i=0,z=0;// loop variables
    static double rad = 80.0f;// radius
    static double deg = 1.0f;// degrees
    for(z = 0; z < frame.cols; ++z) { // left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            int cX = static_cast<int>((rad * cosf(deg)));
            int cY = static_cast<int>((rad * sinf(deg)));
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z); // grab pixel reference
            // set values
            color_value[0] = static_cast<unsigned char>(color_value[0]*(cX * alpha));
            color_value[1] = static_cast<unsigned char>(color_value[1]*(cY * alpha));
            color_value[2] = static_cast<unsigned char>(color_value[2]*alpha);
            deg += 0.1f;
            swapColors(frame, i, z);// swap
            if(isNegative) invert(frame, i, z);// if isNegative invert
        }
    }
    alpha += 0.1f;// add to alpha
    rad += 0.1f;// add to rad
    if(rad > 90) rad = 0;// greater than 90 reset
    if(alpha > 20) alpha = 0;// greater than 20 reset
}
// Light Strobe
// first cycle through the image
// add a variable to each individual pixel (the input sould be different each frame)
// reason for this is adding to the captured image each frame causes a animation a distortion
// each frame the largest value is calculated by adding the rgb values together for one element each iteration.
// test this first
void ac::Type(cv::Mat &frame) {
    int i = 0, z = 0;// loop variables
    static double add_r = 1.0; // add_r
    static int off = 0;// off variable
    for(z = 0; z < frame.rows; ++z) { // top to bottom
        for(i = 0; i < frame.cols; ++i) {// left to right
            cv::Vec3b &current = frame.at<cv::Vec3b>(z, i); // grab pixel reference
            // set pixel values
            current[0] += static_cast<unsigned char>(add_r+current[0]);
            current[1] += static_cast<unsigned char>(add_r+current[1]);
            current[2] += static_cast<unsigned char>(add_r+current[2]);
            // set value indexed by off which changes each frame
            current[off] = current[0]+current[1]+current[2];
            swapColors(frame, z, i);// swap the colors
            if(isNegative) invert(frame, z, i); // invert pixel
        }
    }
    ++off;// increase off
    if(off > 2) off = 0;// greater than two set to zero
    add_r += rand()%255;// random distortion plus equals random number
    if(add_r > 255) add_r = 0;// greater than 255 set to zero
}
// New One
// takes cv::Mat reference
void ac::NewOne(cv::Mat &frame) {
    for(int z = 0; z < frame.cols; ++z) {// left to right
        for(int i = 1; i < frame.rows-1; ++i) {// top to bottom
            cv::Vec3b &colv = frame.at<cv::Vec3b>(i, z);// get pixels
            cv::Vec3b &cola = frame.at<cv::Vec3b>((frame.rows-1)-i, (frame.cols-1)-z);//frame.at<cv::Vec3b>((frame.cols-1)-z, (frame.rows-1)-i);
            // set arrays
            int red_values[] = { colv[0]+cola[2], colv[1]+cola[1], colv[2]+cola[0], 0 };
            int green_values[] = { colv[2]+cola[0], colv[1]+cola[1], colv[0]+cola[2], 0 };
            int blue_values[] = { colv[1]+cola[1], colv[0]+cola[2], colv[2]+cola[0], 0 };
            unsigned char R = 0,G = 0,B = 0;
            // loop through arrays
            for(int iq = 0; iq <= 2; ++iq) {
                R += red_values[iq];
                R /= 3;
                G += green_values[iq];
                G /= 3;
                B += blue_values[iq];
                B /= 3;
            }
            // set pixel values
            colv[0] += static_cast<unsigned char>(alpha*R);
            colv[1] += static_cast<unsigned char>(alpha*G);
            colv[2] += static_cast<unsigned char>(alpha*B);
            swapColors(frame, i, z);//swap colors
            if(isNegative) invert(frame, i, z); // if isNegative invert pixel
        }
    }
    static double max = 8.0f, trans_var = 0.1f;// max and translation
    if (alpha < 0)
        trans_var = 0.1f;
    else if (alpha > max) {
        trans_var = -0.1f;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;// add translation variable
}
// draw a fractal
void ac::blendFractal(cv::Mat &frame) {
    frac::FractalLogic();
    frac::DrawFractal(frame, ac::isNegative);
}

// draw a fractal with background color blended
void ac::blendFractalMood(cv::Mat &frame) {
    // random
    unsigned char color = 0;
    color = rand()%255;
    static bool shift = true;
    static bool shift_value = true;
    for(int z = 0; z < frame.cols; ++z) {// left to right
        for(int i = 0; i < frame.rows; ++i) {// top to bottom
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);// grab pixel
            // set pixel values
            color_value[0] += (shift == shift_value) ? color : -color;
            color_value[1] += (shift == shift_value) ? -color : color;
            color_value[2] += (shift == shift_value) ? color : -color;
            shift_value = !shift_value;// not shift value
        }
    }
    shift = ! shift;// not shift value
    frac::FractalLogic();
    frac::DrawFractal(frame, ac::isNegative); // draw fractal
}

// blend with Image functions Resize X
inline int ac::GetFX(cv::Mat &frame, int x, int nw) {
    double xp = (double)x * (double)frame.rows / (double)nw;
    return (int)xp;
}
// blend with Image function Resize Y
inline int ac::GetFY(cv::Mat &frame, int y, int nh) {
    double yp = (double)y * (double)frame.cols / (double)nh;
    return (int)yp;
}
// blend with Image function
// takes cv::Mat as reference
void ac::blendWithImage(cv::Mat &frame) {
    if(!blendW_frame.data) // if image not loaded return
        return;
    static double alpha = 1.0f; // set alpha to 1
    static double beta = 1.0f; // set beta to 1
    for(int z = 0; z < frame.cols; ++z) {// left to right
        for(int i = 0; i < frame.rows; ++i) {// top to bottom
            // get resized pixel values
            int q = GetFX(blendW_frame, i, frame.rows);
            int j = GetFY(blendW_frame, z, frame.cols);
            // grab pixels
            cv::Vec3b &frame_one = frame.at<cv::Vec3b>(i, z);
            cv::Vec3b &frame_two = blendW_frame.at<cv::Vec3b>(q, j);
            // set pixel values
            for(int p = 0; p < 3; ++p)
                frame_one[p] += static_cast<unsigned char>((frame_one[p]*alpha)+(frame_two[p]*beta));
            swapColors(frame, i, z); // swap colors
            if(isNegative == true) {
                invert(frame, i, z);// invert pixel
            }
        }
    }
    // move alpha and beta values up and down
    static double max = 4.0f, trans_var = 0.1f;
    if (alpha < 0)
        trans_var = translation_variable;
    else if (alpha > max) {
        trans_var = -translation_variable;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;
    beta += -trans_var;
}
// triBlend with Image unused
void ac::triBlendWithImage(cv::Mat &frame) {
    if(images_Enabled == false) return;
    static double alpha = 1.0f, beta = 1.0f;
    static int i = 0, z = 0, j = 0;
    for(z = 0; z < frame.cols; ++z) {
        for(i = 0; i < frame.rows; ++i) {
            cv::Vec3b colors[3];
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);
            int cx[3] =  { ac::GetFX(image_files[0], i, frame.rows), ac::GetFX(image_files[1], i, frame.rows), ac::GetFX(image_files[2], i, frame.rows) };
            int cy[3] =  { ac::GetFY(image_files[0], z, frame.cols),  ac::GetFY(image_files[1], z, frame.cols), ac::GetFY(image_files[2], z, frame.cols) };
            for(j = 0; j < 3; ++j) {
                colors[j] = image_files[j].at<cv::Vec3b>(cx[j], cy[j]);
            }
            color_value[0] = static_cast<unsigned char>(((color_value[0]+colors[0][0])/2)*alpha);
            color_value[1] += static_cast<unsigned char>(((color_value[1]+colors[0][1])/2)*alpha);
            color_value[2] = static_cast<unsigned char>(((color_value[2]+colors[0][2]+colors[1][2]+colors[2][2])/3)*beta);
            swapColors(frame, i, z);
            if(isNegative == true) {
                invert(frame, i, z);
            }
        }
    }
    static double max = 4.0f, trans_var = 0.1f;
    if (alpha < 0)
        trans_var = translation_variable;
    else if (alpha > max) {
        trans_var = -translation_variable;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;
    beta += -trans_var;
}

// Image Strobe - unused
void ac::imageStrobe(cv::Mat &frame) {
    if(images_Enabled == false) return;
    static double alpha = 1.0f;
    static int i = 0, z = 0, j = 0, image_offset = 0;
    for(z = 0; z < frame.cols; ++z) {
        for(i = 0; i < frame.rows; ++i) {
            cv::Vec3b colors[3];
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);
            int cx[3] =  { ac::GetFX(image_files[0], i, frame.rows), ac::GetFX(image_files[1], i, frame.rows), ac::GetFX(image_files[2], i, frame.rows) };
            int cy[3] =  { ac::GetFY(image_files[0], z, frame.cols),  ac::GetFY(image_files[1], z, frame.cols), ac::GetFY(image_files[2], z, frame.cols) };
            for(j = 0; j < 3; ++j)
                colors[j] = image_files[j].at<cv::Vec3b>(cx[j], cy[j]);
            for(j = 0; j < 3; ++j)
                color_value[j] += static_cast<unsigned char>((colors[image_offset][j]*alpha));
            swapColors(frame, i, z);
            if(isNegative == true) {
                invert(frame, i, z);
            }
        }
    }
    ++image_offset;
    if(image_offset >= 4) image_offset = 0;
    static double max = 4.0f, trans_var = 0.1f;
    if (alpha < 0)
        trans_var = translation_variable;
    else if (alpha > max) {
        trans_var = -translation_variable;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;
}
// Image distraction - unused
void ac::imageDistraction(cv::Mat &frame) {
    if(images_Enabled == false) return;
    static double alpha = 1.0f;
    static int i = 0, z = 0, im_off = 2;
    for(z = 0; z < frame.cols; ++z) {
        for(i = 0; i < frame.rows; ++i) {
            cv::Vec3b &color_value = frame.at<cv::Vec3b>(i, z);
            int cX = GetFX(image_files[im_off], i, frame.rows), cY = GetFY(image_files[im_off], z, frame.cols);
            cv::Vec3b manip_color = image_files[im_off].at<cv::Vec3b>(cX, cY);
            color_value[0] = static_cast<unsigned char>((z*alpha)+color_value[0]);
            color_value[1] = static_cast<unsigned char>(manip_color[1]*alpha);
            color_value[2] = static_cast<unsigned char>((i*alpha)+color_value[2]);
            swapColors(frame, i, z);
            if(isNegative) invert(frame, i, z);
        }
    }
    ++im_off;
    if(im_off >= 4) im_off = 0;
    static double max = 4.0f, trans_var = 0.1f;
    if (alpha < 0)
        trans_var = 0.1f;
    else if (alpha > max) {
        trans_var = -0.1f;
        max += 3.0f;
        if (max > 23)
            max = 4.0f;
    }
    alpha += trans_var;
}

// Cos Sin Mulitply draw gradients
// takes cv::Mat reference
void ac::cossinMultiply(cv::Mat &frame) {
    static double alpha = 1.0f;// set static alpha to 1.0
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z); // grab pixel
            // set pixel values
            buffer[0] += static_cast<unsigned char>(1+static_cast<unsigned int>((sinf(alpha))*z));
            buffer[1] += static_cast<unsigned char>(1+static_cast<unsigned int>((cosf(alpha))*i));
            buffer[2] += static_cast<unsigned char>((buffer[0]+buffer[1]+buffer[2])/3);
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// invert pixel
        }
    }
    // add alpha up to 24 return to zero when greater
    static double trans_var = 0.05f;
    if(alpha > 24) alpha = 1.0f;
    alpha += trans_var;
}
// Color Accumulate 1
void ac::colorAccumulate1(cv::Mat &frame) {
    static double alpha = 1.0f; // alpha to 1.0
    static int i = 0, z = 0; // static loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);// current pixel
            // set pixel values
            buffer[0] += static_cast<unsigned char>((buffer[2]*alpha));
            buffer[1] += static_cast<unsigned char>((buffer[0]*alpha));
            buffer[2] += static_cast<unsigned char>((buffer[1]*alpha));
            swapColors(frame, i, z); // swap colors
            if(isNegative) invert(frame, i, z);// invert pixel
        }
    }
    // increase alpha until 24 then reset
    static double trans_var = 0.05f;
    alpha += trans_var;
    if(alpha > 24) alpha = 1.0f;
}
// Color Accumulate 2
void ac::colorAccumulate2(cv::Mat &frame) {
    static double alpha = 1.0f;// static alpha set to 1.0
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            // grab pixel
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);
            // set pixel rgb values
            buffer[0] += static_cast<unsigned char>((buffer[2]*alpha)+i);
            buffer[1] += static_cast<unsigned char>((buffer[0]*alpha)+z);
            buffer[2] += static_cast<unsigned char>((buffer[1]*alpha)+i-z);
            swapColors(frame, i, z);// swap
            if(isNegative) invert(frame, i, z);// if isNegative invert
        }
    }
    static double trans_var = 0.05f;// translation variable
    alpha += trans_var;// alpha plus equal translation variable
    if(alpha > 24) alpha = 1.0f;// if alpha greater than 24 reset to 1
}
// Color Accumulate #3
// takes cv::Mat reference
void ac::colorAccumulate3(cv::Mat &frame) {
    static double alpha = 1.0f;// set alpha to 1.0
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// from left to right
        for(i = 0; i < frame.rows; ++i) {// from top to bottom
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);// grab pixel reference
            // set rgb values
            buffer[0] = static_cast<unsigned char>((-buffer[2])+z);
            buffer[1] = static_cast<unsigned char>((-buffer[0])+i);
            buffer[2] = static_cast<unsigned char>((-buffer[1])+alpha);
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if isNegative true invert pixel
        }
    }
    static double trans_var = 0.05f;// 0.05 variable
    alpha += trans_var;// alpha plus equal translation variable
    if(alpha > 24) alpha = 1.0f;// alpha greater than 24 set to 1 (reset)
}

// takes cv::Mat reference
void ac::filter8(cv::Mat &frame) {
    static double alpha = 1.0f;// set static alpha to 1.0
    static int i = 0, z = 0, q = 0;// loop variable
    for(z = 0; z < frame.cols; ++z) {// from left to right
        for(i = 0; i < frame.rows; ++i) {// from top to bottom
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);// grab pixel
            for(q = 0; q < 3; ++q) {// loop each rgb value
                buffer[q] = static_cast<unsigned char>(buffer[q]+((i+z)*alpha));// preform calculation
                
            }
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if isNegative invert
        }
    }
    // static direction equals 1
    static int direction = 1;
    if(direction == 1) {// if direction equals 1
        alpha += 0.05f;// alpha plus equal 0.05
        if(alpha > 3) { alpha = 3; direction = 2; }// alpha greater than 3 set direction to 2
    } else {
        alpha -= 0.05f;// alpha minus equal 0.05
        if(alpha <= 0.1f) { alpha = 0.1f; direction = 1; }//alpha greater than 3 set direction to 1
    }
}

// takes cv::Mat reference
void ac::filter3(cv::Mat &frame) {
    static double alpha = 1.0f;// set static alpha to 1.0
    static int i = 0, z = 0, q = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);// grab pixel reference
            for(q = 0; q < 3; ++q) {// loop through rgb values
                buffer[q] = static_cast<unsigned char>(buffer[0]+(buffer[q])*(alpha));// preform calculation
            }
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if isNegative invert pixel
        }
    }
    // direction equals 1
    static int direction = 1;
    if(direction == 1) { // if direction equals 1
        alpha += 0.1f;// alpha plus equal 0.1
        if(alpha > 6) { alpha = 6; direction = 2; } // if alpha greater than 6 set alpha to 6 direction to 2
    } else {
        alpha -= 0.05f;// alpha minus equal 0.1
        if(alpha <= 0.1f) { alpha = 0.1f; direction = 1; } // if alpha lses than equal 0.1 set to 0.1 direction equals 1
    }
}

// takes cv::Mat as reference
// uses 3 static variables to represent the RGB values
// to mulitply by the alpha variable
// each frame they either increase or are reset to a random number when set to zero
// when they reach a number greater than 255 they are reset to zero
void ac::rainbowBlend(cv::Mat &frame) {
    static double alpha = 1.0f;// set static alpha to 1.0
    static int rb = 0, gb = 0, bb = 0;// set static integer r,g,b values
    if(rb == 0) // if rb equals 0
        rb = rand()%255;// set rb to random number
    else ++rb;// else increase rb
    if(gb == 0) // if gb equals 0
        gb = rand()%255;// gb equals random number
    else ++gb;// else gb increases
    if(bb == 0) // if bb equals 0
        bb = rand()%255;// bb equals random number
    else ++bb;// else increase bb
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            // grab pixel as cv::Vec3b reference
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);
            // add to rgb values alpha * rb,gb,bb variables
            buffer[0] += static_cast<unsigned char>(alpha*rb);
            buffer[1] += static_cast<unsigned char>(alpha*gb);
            buffer[2] += static_cast<unsigned char>(alpha*bb);
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if isNegative invert pixel
        }
    }
    // if rb greater than 255 set to zero
    if(rb > 255) rb = 0;
    // if gb greater than 255 set to zero
    if(gb > 255) gb = 0;
    // if bb greater than 255 set to zero
    if(bb > 255) bb = 0;
    // static int direction equals 1
    static int direction = 1;
    if(direction == 1) {// if direction equals 1
        alpha += 0.1f;// increase alpha
        // alpha greater than 6 change direction
        if(alpha > 6) { alpha = 6; direction = 2; }
    } else {
        // decrease alpha
        alpha -= 0.05f;
        // if alpha <= 0.1 change direction
        if(alpha <= 0.1f) { alpha = 0.1f; direction = 1; }
    }
}

// random pixel value added to each pixel RGB value each frame
// takes cv::Mat reference
void ac::randBlend(cv::Mat &frame) {
    unsigned char rr = rand()%255;// random Red
    unsigned char rg = rand()%255;// random Green
    unsigned char rb = rand()%255;// random Blue
    static int i = 0, z = 0;// i,z loop variables
    for(z = 0; z < frame.cols; ++z) {// from left to right
        for(i = 0; i < frame.rows; ++i) {// from top to bottom
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);// pixel at
            buffer[0] += rr;// add random R
            buffer[1] += rg;// add random G
            buffer[2] += rb;// add random B
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if negative, invert pixel
        }
    }
}

// takes cv::Mat reference
void ac::newBlend(cv::Mat &frame) {
    static int pos = 300; // static int pos equal 300
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            // grab pixel
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);
            // set pixel RGB values
            buffer[0] = static_cast<unsigned char>(buffer[2]+(1+(i*z)/pos));
            buffer[1] = static_cast<unsigned char>(buffer[1]+(1+(i*z)/pos));
            buffer[2] = static_cast<unsigned char>(buffer[0]+(1+(i*z)/pos));
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if(isNegative) invert pixel
        }
    }
    static unsigned int dir = 1;// static direction equals 1
    if(dir == 1) {// dir equals 1
        pos += 25;// pos plus equal 25
        if(pos > 1024) {// greater than 1024
            pos = 1024;
            dir = 2;// set direction to 2
        }
    }
    else {// direction != 1
        pos -= 25;// minus 25
        if(pos < 100) {// less than 100
            pos = 100;
            dir = 1;// set direction to 1
        }
    }
}
// pixelScale
// takes cv::Mat reference
void ac::pixelScale(cv::Mat &frame) {
    static double pos = 1.0f;// pos equals 1.0
    static int i = 0, z = 0;// loop variables
    for(z = 0; z < frame.cols; ++z) {// left to right
        for(i = 0; i < frame.rows; ++i) {// top to bottom
            // grab pixel reference
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);
            cv::Vec3b buf = buffer;// temp pixel
            // set RGB pixel values
            buffer[0] = static_cast<unsigned char>((buf[0]*pos)+(buf[0]-buffer[2]));
            buffer[1] = static_cast<unsigned char>((buf[1]*pos)+(buf[1]+buffer[1]));
            buffer[2] = static_cast<unsigned char>((buf[2]*pos)+(buf[2]-buffer[0]));
            swapColors(frame, i, z);// swap colors
            if(isNegative) invert(frame, i, z);// if isNegative invert pixel
        }
    }
    static int direction = 1;// direction equals 1
    static double pos_max = 3.0f;// pos_max equals 3.0
    if(direction == 1) {// direction equals 1
        pos += 0.1f;// plus equal 0.1
        if(pos > pos_max) {// greater than pos_max
            pos = pos_max;
            direction = 0;// set direction to zero
            pos_max += 0.5f;// increase pos_max
        }
    } else if(direction == 0) {// direction equals 0
        pos -= 0.1f;// pos minus equal 0.1
        if(pos <= 0) {// pos less than equal 0
            if(pos_max > 15) pos_max = 1.0f;// pos_max > 14 reset
            direction = 1;// direction set back to 1
        }
    }
}
// glitchSort
// takes cv::Mat reference
void ac::glitchSort(cv::Mat &frame) {
    static double pos = 1.0f; // static pos set to 1.0
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static std::vector<unsigned int> v;// static vector of unsigned int
    v.reserve(w);// reserve at least w bytes
    for(int z = 0; z < h; ++z) {// top to bottom
        for(int i = 0; i < w; ++i) { // left to right
            // grab current pixel value reference
            cv::Vec3b &value = frame.at<cv::Vec3b>(z, i);
            // temporary unsigned int variable
            unsigned int vv = 0;
            // pointer to unsigned char * of vv variable
            unsigned char *cv = (unsigned char*)&vv;
            // set RGB values
            cv[0] = value[0];
            cv[1] = value[1];
            cv[2] = value[2];
            cv[3] = 0;
            v.push_back(vv);// push back into vector
        }
        std::sort(v.begin(), v.end());// sort the row of pixels
        for(int i = 0; i < w; ++i) {// left to right
            // pointer to unsigned integer stored at index i
            unsigned char *value = (unsigned char*)&v[i];
            // grab current pixel reference as cv::Vec3b
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // alphablend pixel with values from v at index i
            pixel[0] = static_cast<unsigned char>(pixel[0] + (pos)*value[0]);
            pixel[1] = static_cast<unsigned char>(pixel[1] + (pos)*value[1]);
            pixel[2] = static_cast<unsigned char>(pixel[2] + (pos)*value[2]);
            // swap the colors
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i); // if isNegative invert pixel
            
        }
        v.erase(v.begin(), v.end());// erase pixel data
    }
    static double pos_max = 7.0f;// pos_max = 7.0
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

// takes cv::Mat reference
void ac::pixelSort(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static std::vector<unsigned int> v;// static vector of unsigned int
    v.reserve(w);// reserve w bytes
    for(int z = 0; z < h; ++z) { // top to bottom
        for(int i = 0; i < w; ++i) { // left to right
            //unsigned int value = frame.at<unsigned int>(z, i);
            // grab pixel reference
            cv::Vec3b &value = frame.at<cv::Vec3b>(z, i);
            unsigned int vv = 0;
            // unsigned char * of vv
            unsigned char *cv = (unsigned char*)&vv;
            // set RGB values
            cv[0] = value[0];
            cv[1] = value[1];
            cv[2] = value[2];
            cv[3] = 0;
            // push back into vector v
            v.push_back(vv);
        }
        // sort vector v
        std::sort(v.begin(), v.end());
        for(int i = 0; i < w; ++i) {// left to right
            // unsigned char pointer of vector v at index i
            unsigned char *value = (unsigned char*)&v[i];
            // get pixel reference
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // add to pixel without scaling
            pixel[0] += value[0];
            pixel[1] += value[1];
            pixel[2] += value[2];
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// invert pixel
        }
        v.erase(v.begin(), v.end());
    }
}
// preform a random filter
void ac::randomFilter(cv::Mat &frame) {
    int num;
    do {
        num = rand()%(draw_max-6);
    } while((ac::draw_strings[num] == "Random Filter") || (ac::draw_strings[num] == "RandomIntertwine") || (ac::draw_strings[num] == "RandomFour") || (ac::draw_strings[num] == "BlendThree") || (ac::draw_strings[num] == "RandomTwo"));
    
    draw_func[num](frame);
}

void ac::randomFlash(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static double pos = 1.0;// pos index
    // a random red,green,blue value
    int random_r = rand()%255, random_g = rand()%255, random_b = rand()%255;
    // top to bottom
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {// left to right
            // get pixel reference
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // calculate RGB values
            pixel[0] += static_cast<unsigned char>(pos*random_r);
            pixel[1] += static_cast<unsigned char>(pos*random_g);
            pixel[2] += static_cast<unsigned char>(pos*random_b);
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    static double pos_max = 7.0f;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

// variables for changePixel
int current_filterx = 0;
int bytesPerSample = 0;
int bytesPerRow = 0;
int width = 0;
int height = 0;
int red = 0;
int green = 0;
int blue = 0;
int offset = 0;
int randomNumber = 0;
int reverse = 0;
bool negate = false;

// changePixel for Alpha Flame Filters
// this function is called once for each pixel in the source image
void changePixel(cv::Mat &full_buffer, int i, int z, cv::Vec3b &buffer, double pos, double *count) {
    //each case is a different operation on the RGB pixel values stored in buffer
    switch(current_filterx) {
        case 0:
        {
            double value = pos;
            buffer[0] = static_cast<unsigned char>(value*buffer[0]);
            buffer[1] = static_cast<unsigned char>(value*buffer[1]);
            buffer[2] = static_cast<unsigned char>(value*buffer[2]);
        }
            break;
        case 1:
        {
            double value = pos;
            buffer[0] = static_cast<unsigned char>(value*buffer[0]);
            buffer[1] = static_cast<unsigned char>((-value)*buffer[1]);
            buffer[2] = static_cast<unsigned char>(value*buffer[2]);
        }
            break;
        case 2:
        {
            buffer[0] += static_cast<unsigned char>(buffer[0]*-pos);
            buffer[1] += static_cast<unsigned char>(buffer[1]*pos);
            buffer[2] += static_cast<unsigned char>(buffer[2]*-pos);
        }
            break;
        case 3:
        {
            int current_pos = static_cast<int>(pos*0.2f);
            buffer[0] = static_cast<unsigned char>((i*current_pos)+buffer[0]);
            buffer[2] = static_cast<unsigned char>((z*current_pos)+buffer[2]);
            buffer[1] = static_cast<unsigned char>((current_pos*buffer[1]));
        }
            break;
        case 4:
        {
            int current_pos = static_cast<int>(pos*0.2f);
            buffer[0] = static_cast<unsigned char>((z*current_pos)+buffer[0]);
            buffer[1] = static_cast<unsigned char>((i*current_pos)+buffer[1]);
            buffer[2] = static_cast<unsigned char>(((i+z)*current_pos)+buffer[2]);
        }
            break;
        case 5:
        {
            int current_pos = static_cast<int>(pos*0.2f);
            buffer[0] = static_cast<unsigned char>(-(z*current_pos)+buffer[0]);
            buffer[1] = static_cast<unsigned char>(-(i*current_pos)+buffer[1]);
            buffer[2] = static_cast<unsigned char>(-((i+z)*current_pos)+buffer[2]);
        }
            break;
            
        case 6:
        {
            int zq = z+1, iq = i+1;
            if(zq > height-1 || iq > width-1) return;
            cv::Vec3b &temp = full_buffer.at<cv::Vec3b>(zq, iq);
            buffer[0] += static_cast<unsigned char>((i*pos)+temp[0]);
            buffer[1] += static_cast<unsigned char>((z*pos)+temp[1]);
            buffer[2] += static_cast<unsigned char>((i/(z+1))+temp[2]);
        }
            break;
        case 7:
        {
            unsigned char colv[4], cola[4];
            colv[0] = buffer[0];
            colv[1] = buffer[1];
            colv[2] = buffer[2];
            cola[0] = buffer[2];
            cola[1] = buffer[1];
            cola[2] = buffer[0];
            unsigned int alpha = (int)pos;
            int red_values[] = { colv[0]+cola[2], colv[1]+cola[1], colv[2]+cola[0], 0 };
            int green_values[] = { colv[2]+cola[0], colv[1]+cola[1], colv[0]+cola[2], 0 };
            int blue_values[] = { colv[1]+cola[1], colv[0]+cola[2], colv[2]+cola[0], 0 };
            unsigned char R = 0,G = 0,B = 0;
            for(int iq = 0; iq <= 2; ++iq) {
                R += red_values[iq];
                R /= 3;
                G += green_values[iq];
                G /= 3;
                B += blue_values[iq];
                B /= 3;
            }
            buffer[0] += static_cast<unsigned char>(alpha*R);
            buffer[1] += static_cast<unsigned char>(alpha*G);
            buffer[2] += static_cast<unsigned char>(alpha*B);
        }
            break;
        case 8:
        {
            unsigned char colv[4], cola[4];
            colv[0] = buffer[0];
            colv[1] = buffer[1];
            colv[2] = buffer[2];
            int iq = (width-i-1);
            int zq = (height-z-1);
            cv::Vec3b &t = full_buffer.at<cv::Vec3b>(zq, iq);
            cola[0] = t[0];
            cola[1] = t[1];
            cola[2] = t[2];
            unsigned int alpha = (int)pos;
            int red_values[] = { colv[0]+cola[2], colv[1]+cola[1], colv[2]+cola[0], 0 };
            int green_values[] = { colv[2]+cola[0], colv[1]+cola[1], colv[0]+cola[2], 0 };
            int blue_values[] = { colv[1]+cola[1], colv[0]+cola[2], colv[2]+cola[0], 0 };
            unsigned char R = 0,G = 0,B = 0;
            for(int iq = 0; iq <= 2; ++iq) {
                R += red_values[iq];
                R /= 3;
                G += green_values[iq];
                G /= 3;
                B += blue_values[iq];
                B /= 3;
            }
            buffer[0] += static_cast<unsigned char>(alpha*R);
            buffer[1] += static_cast<unsigned char>(alpha*G);
            buffer[2] += static_cast<unsigned char>(alpha*B);
        }
            break;
        case 9:
        {
            double alpha = pos;
            unsigned char colorz[3][3];
            colorz[0][0] = buffer[0];
            colorz[0][1] = buffer[1];
            colorz[0][2] = buffer[2];
            int total_r = colorz[0][0] +colorz[0][1]+colorz[0][2];
            total_r /= 3;
            total_r *= static_cast<int>(alpha);
            int iq = i+1;
            if(iq > width) return;
            int zq = z;
            cv::Vec3b &temp = full_buffer.at<cv::Vec3b>(zq, iq);
            colorz[1][0] = temp[0];
            colorz[1][1] = temp[1];
            colorz[1][2] = temp[2];
            int total_g = colorz[1][0]+colorz[1][1]+colorz[1][2];
            total_g /= 3;
            total_g *= static_cast<int>(alpha);
            buffer[0] = static_cast<unsigned char>(total_r);
            buffer[1] = static_cast<unsigned char>(total_g);
            buffer[2] = static_cast<unsigned char>(total_r+total_g*alpha);
            
        }
            break;
        case 10:
        {
            buffer[0] = static_cast<unsigned char>(((i+z)*pos)/(i+z+1)+buffer[0]*pos);
            buffer[1] += static_cast<unsigned char>(((i*pos)/(z+1))+buffer[1]);
            buffer[2] += static_cast<unsigned char>(((z*pos)/(i+1))+buffer[2]);
        }
            break;
        case 11:
        {
            buffer[0] += static_cast<unsigned char>((buffer[2]+(i*pos))/(pos+1));
            buffer[1] += static_cast<unsigned char>((buffer[1]+(z*pos))/(pos+1));
            buffer[2] += buffer[0];
        }
            break;
        case 12:
        {
            buffer[0] += static_cast<unsigned char>((i/(z+1))*pos+buffer[0]);
            buffer[1] += static_cast<unsigned char>((z/(i+1))*pos+buffer[1]);
            buffer[2] += static_cast<unsigned char>(((i+z)/(pos+1)+buffer[2]));
        }
            break;
        case 13:
        {
            buffer[0] += static_cast<unsigned char>((pos*(i/(pos+1))+buffer[2]));
            buffer[1] += static_cast<unsigned char>((pos*(z/(pos+1))+buffer[1]));
            buffer[2] += static_cast<unsigned char>((pos*((i*z)/(pos+1)+buffer[0])));
        }
            break;
        case 14:
        {
            buffer[0] = static_cast<unsigned char>(((i+z)*pos)/(i+z+1)+buffer[0]*pos);
            buffer[1] += static_cast<unsigned char>((buffer[1]+(z*pos))/(pos+1));
            buffer[2] += static_cast<unsigned char>(((i+z)/(pos+1)+buffer[2]));
        }
            break;
        case 15:
        {
            buffer[0] = static_cast<unsigned char>((i%(z+1))*pos+buffer[0]);
            buffer[1] = static_cast<unsigned char>((z%(i+1))*pos+buffer[1]);
            buffer[2] = static_cast<unsigned char>((i+z%((int)pos+1))+buffer[2]);
        }
            break;
        case 16:
        {
            unsigned int r = 0;
            r = (buffer[0]+buffer[1]+buffer[2])/3;
            buffer[0] += static_cast<unsigned char>(pos*r);
            buffer[1] += static_cast<unsigned char>(-(pos*r));
            buffer[2] += static_cast<unsigned char>(pos*r);
        }
            break;
        case 17:
        {
            unsigned long r = 0;;
            r = (buffer[0]+buffer[1]+buffer[2])/(pos+1);
            buffer[0] += static_cast<unsigned char>(r*pos);
            r = (buffer[0]+buffer[1]+buffer[2])/3;
            buffer[1] += static_cast<unsigned char>(r*pos);
            r = (buffer[0]+buffer[1]+buffer[2])/5;
            buffer[2] += static_cast<unsigned char>(r*pos);
        }
            break;
        case 18:
        {
            buffer[0] += static_cast<unsigned char>(1+static_cast<unsigned int>((sinf(pos))*z));
            buffer[1] += static_cast<unsigned char>(1+static_cast<unsigned int>((cosf(pos))*i));
            buffer[2] += static_cast<unsigned char>((buffer[0]+buffer[1]+buffer[2])/3);
        }
            break;
        case 19:
        {
            buffer[0] += static_cast<unsigned char>((buffer[2]-i)*((((int)pos+1)%15)+2));
            buffer[1] += static_cast<unsigned char>((buffer[1]-z)*((((int)pos+1)%15)+2));
            buffer[2] += static_cast<unsigned char>(buffer[0]-(i+z)*((((int)pos+1)%15)+2));
        }
            break;
        case 20:
        {
            buffer[0] += static_cast<unsigned char>((buffer[0]+buffer[1]-buffer[2])/3*pos);
            buffer[1] -= static_cast<unsigned char>((buffer[0]-buffer[1]+buffer[2])/6*pos);
            buffer[2] += static_cast<unsigned char>((buffer[0]-buffer[1]-buffer[2])/9*pos);
        }
            break;
        case 21:
        {
            int iq = i, zq = z+1;
            if(zq > height-2) return;
            cv::Vec3b &temp = full_buffer.at<cv::Vec3b>(zq, iq);
            zq = z+2;
            if(zq > height-2) return;
            cv::Vec3b &temp2 = full_buffer.at<cv::Vec3b>(zq, iq);
            int ir, ig, ib;
            ir = buffer[0]+temp[0]-temp2[0];
            ig = buffer[1]-temp[1]+temp2[1];
            ib = buffer[2]-temp[2]-temp2[2];
            if(z%2 == 0) {
                if(i%2 == 0) {
                    buffer[0] = static_cast<unsigned char>(ir+(0.5*pos));
                    buffer[1] = static_cast<unsigned char>(ig+(0.5*pos));
                    buffer[2] = static_cast<unsigned char>(ib+(0.5*pos));
                } else {
                    buffer[0] = static_cast<unsigned char>(ir+(1.5*pos));
                    buffer[1] = static_cast<unsigned char>(ig+(1.5*pos));
                    buffer[2] = static_cast<unsigned char>(ib+(1.5*pos));
                }
            } else {
                if(i%2 == 0) {
                    buffer[0] += static_cast<unsigned char>(ir+(0.1*pos));
                    buffer[1] += static_cast<unsigned char>(ig+(0.1*pos));
                    buffer[2] += static_cast<unsigned char>(ib+(0.1*pos));
                } else {
                    buffer[0] -= static_cast<unsigned char>(ir+(i*pos));
                    buffer[1] -= static_cast<unsigned char>(ig+(z*pos));
                    buffer[2] -= static_cast<unsigned char>(ib+(0.1*pos));
                }
            }
        }
            break;
        case 22:
        {
            if((i%2) == 0) {
                if((z%2) == 0) {
                    buffer[0] = static_cast<unsigned char>(1-pos*buffer[0]);
                    buffer[2] = static_cast<unsigned char>((i+z)*pos);
                } else {
                    buffer[0] = static_cast<unsigned char>(pos*buffer[0]-z);
                    buffer[2] = static_cast<unsigned char>((i-z)*pos);
                }
            } else {
                if((z%2) == 0) {
                    buffer[0] = static_cast<unsigned char>(pos*buffer[0]-i);
                    buffer[2] = static_cast<unsigned char>((i-z)*pos);
                } else {
                    buffer[0] = static_cast<unsigned char>(pos*buffer[0]-z);
                    buffer[2] = static_cast<unsigned char>((i+z)*pos);
                }
            }
        }
            break;
        case 23:
        {
            buffer[0] = static_cast<unsigned char>(buffer[0]+buffer[1]*2+pos);
            buffer[1] = static_cast<unsigned char>(buffer[1]+buffer[0]*2+pos);
            buffer[2] = static_cast<unsigned char>(buffer[2]+buffer[0]+pos);
        }
            break;
        case 24:
        {
            buffer[0] += static_cast<unsigned char>(buffer[2]+pos);
            buffer[1] += static_cast<unsigned char>(buffer[1]+pos);
            buffer[2] += static_cast<unsigned char>(buffer[0]+pos);
        }
            break;
        case 25:
        {
            buffer[0] += static_cast<unsigned char>((buffer[2]*pos));
            buffer[1] += static_cast<unsigned char>((buffer[0]*pos));
            buffer[2] += static_cast<unsigned char>((buffer[1]*pos));
        }
            break;
        case 26:
        {
            buffer[0] += static_cast<unsigned char>((buffer[2]*pos)+i);
            buffer[1] += static_cast<unsigned char>((buffer[0]*pos)+z);
            buffer[2] += static_cast<unsigned char>((buffer[1]*pos)+i-z);
        }
            break;
        case 27:
        {
            buffer[0] = static_cast<unsigned char>((-buffer[2])+z);
            buffer[1] = static_cast<unsigned char>((-buffer[0])+i);
            buffer[2] = static_cast<unsigned char>((-buffer[1])+pos);
        }
            break;
        case 28:
        {
            buffer[0] = static_cast<unsigned char>(buffer[2]+(1+(i*z)/pos));
            buffer[1] = static_cast<unsigned char>(buffer[1]+(1+(i*z)/pos));
            buffer[2] = static_cast<unsigned char>(buffer[0]+(1+(i*z)/pos));
        }
            break;
        case 29:
        {
            int iq = i, zq = z+1;
            if(zq > height-2) return;
            cv::Vec3b &temp = full_buffer.at<cv::Vec3b>(zq, iq);
            zq = z+2;
            if(zq > height-2) return;
            cv::Vec3b &temp2 = full_buffer.at<cv::Vec3b>(zq, iq);
            zq = z+3;
            if(zq > height-2) return;
            cv::Vec3b &temp3 = full_buffer.at<cv::Vec3b>(zq, iq);
            zq = z+4;
            if(zq > height-2) return;
            cv::Vec3b &temp4 = full_buffer.at<cv::Vec3b>(zq, iq);
            unsigned char col[4];
            col[0] = static_cast<unsigned char>((temp[0]+temp2[0]+temp3[0]+temp4[0])/4);
            col[1] = static_cast<unsigned char>((temp[1]+temp2[1]+temp3[1]+temp4[1])/4);
            col[2] = static_cast<unsigned char>((temp[2]+temp2[2]+temp3[2]+temp4[2])/4);
            buffer[0] = static_cast<unsigned char>(col[0]*pos);
            buffer[1] = static_cast<unsigned char>(col[1]*pos);
            buffer[2] = static_cast<unsigned char>(col[2]*pos);
        }
            break;
        case 30:
        {
            double rad = 100.0;
            double degree = 0.01*pos;
            int x = static_cast<int>(rad*(cos(degree)));
            int y = rad * static_cast<int>(sin(degree));
            int z = rad * static_cast<int>(tanf(degree));
            buffer[0] = static_cast<unsigned char>(buffer[0]+x);
            buffer[2] = static_cast<unsigned char>(buffer[1]+y);
            buffer[1] = static_cast<unsigned char>(buffer[1]+z);
        }
            break;
        case 31:
        {
            int average= static_cast<unsigned char>((buffer[0]+buffer[1]+buffer[2]+1)/3);
            buffer[0] += static_cast<unsigned char>(buffer[2]+average*(pos));
            buffer[1] += static_cast<unsigned char>(buffer[0]+average*(pos));
            buffer[2] += static_cast<unsigned char>(buffer[1]+average*(pos));
        }
            break;
        case 32:
        {
            unsigned int value = 0;
            value  = ~buffer[0] + ~buffer[1] + ~buffer[2];
            value /= 2;
            buffer[0] = static_cast<unsigned char>(buffer[0]+value*pos);
            value /= 2;
            buffer[1] = static_cast<unsigned char>(buffer[1]+value*pos);
            value /= 2;
            buffer[2] = static_cast<unsigned char>(buffer[2]+value*pos);
        }
            break;
        case 33:
        {
            buffer[0] += static_cast<unsigned char>(*count*pos);
            buffer[1] += static_cast<unsigned char>(*count*pos);
            buffer[2] += static_cast<unsigned char>(*count*pos);
            *count += 0.00001f;
            if(*count > 255) *count = 0;
        }
            break;
        case 34:
        {
            buffer[0] += static_cast<unsigned char>(pos*(randomNumber+pos));
            buffer[1] += static_cast<unsigned char>(pos*(randomNumber+z));
            buffer[2] += static_cast<unsigned char>(pos*(randomNumber+i));
        }
            break;
        case 35:
        {
            buffer[0] += static_cast<unsigned char>(*count *z);
            buffer[1] += static_cast<unsigned char>(*count *pos);
            buffer[2] += static_cast<unsigned char>(*count *z);
            *count += 0.0000001f;
        }
            break;
        case 36:
        {
            buffer[0] += static_cast<unsigned char>(sinf(3.14+pos)*pos);
            buffer[1] += static_cast<unsigned char>(cosf(3.14+pos)*pos);
            buffer[2] += static_cast<unsigned char>(tanf(3.14+pos)*pos);
        }
            break;
    }
    buffer[0] += red;
    buffer[1] += green;
    buffer[2] += blue;
    if(negate == true) {
        buffer[0] = ~buffer[0];
        buffer[1] = ~buffer[1];
        buffer[2] = ~buffer[2];
    }
    unsigned char buf[3];
    buf[0] = buffer[0];
    buf[1] = buffer[1];
    buf[2] = buffer[2];
    switch(reverse) {
        case 0://normal
            break;
        case 1:
            buffer[0] = buf[2];
            buffer[1] = buf[1];
            buffer[2] = buf[0];
            break;
        case 2:
            buffer[0] = buf[1];
            buffer[1] = buf[2];
            buffer[2] = buf[0];
            break;
        case 3:
            buffer[0] = buf[2];
            buffer[1] = buf[0];
            buffer[2] = buf[1];
            break;
        case 4:
            buffer[0] = buf[1];
            buffer[1] = buf[0];
            buffer[2] = buf[2];
            break;
    }
}

// alpha flame filters
// a collection of filters
void ac::alphaFlame(cv::Mat &frame) {
    static double pos = 1.0f;// pos set to 1
    double count = 1.0f;// count set to 1
    static int i = 0, z = 0;// i,z variables
    width = frame.cols;// frame width
    height = frame.rows;// frame height
    for(z = 0; z < frame.cols; ++z) {
        for(i = 0; i < frame.rows; ++i) {
            // grab pixel reference as cv::Vec3b
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(i, z);
            // call change pixel function
            changePixel(frame, z, i, buffer, pos, &count);
        }
    }
    // static direction set to 1
    static int direction = 1;
    if(direction == 1) {// if direction is equal to 1
        pos += 0.1f;// pos plus equal 0.1
        if(pos > 512) {// pos greater than 512
            pos = 512;// pos equal 512
            direction = 0;// direction equals 0
        }
    }
    else {
        pos -= 0.1f; // pos minus equal 0.1
        if(pos < 1) {// if pos less than 1
            pos = 1;// pos equal 1
            direction = 1;// direction set back to 1
        }
    }
}

// Resize X variable
int AC_GetFX(int oldw,int x, int nw) {
    float xp = (float)x * (float)oldw / (float)nw;
    return (int)xp;
}
// Resize Y Variable
int AC_GetFZ(int oldh, int y, int nh) {
    float yp = (float)y * (float)oldh / (float)nh;
    return (int)yp;
}

// Image blend
// cv::Mat as reference
void ac::imageBlend(cv::Mat &frame) {
    static double pos = 1.0f;// static pos set to 1
    if(blend_set == true) {// if image is set
        int i,z;
        for(i = 0; i < frame.cols; ++i) { // top to bottom
            for(z = 0; z < frame.rows; ++z) {// left to right
                // get resized x,y
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b &current = frame.at<cv::Vec3b>(z, i);// get current pixel
                cv::Vec3b im = blend_image.at<cv::Vec3b>(cY, cX);// get pixel to blend from resized x,y
                // set pixel values
                current[0] = static_cast<unsigned char>(current[0]+(im[0]*pos));
                current[1] = static_cast<unsigned char>(current[1]+(im[1]*pos));
                current[2] = static_cast<unsigned char>(current[2]+(im[2]*pos));
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i);// invert pixel
            }
        }
    }
    static double pos_max = 7.0f;// max pos value
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// takes cv::Mat reference
void ac::imageBlendTwo(cv::Mat &frame) {
    static double pos = 1.0f; // static pos equal 1.0
    if(blend_set == true) {// if image is set to blend with
        int i,z;// loop variables
        for(i = 0; i < frame.cols; ++i) { // left to right
            for(z = 0; z < frame.rows; ++z) {// top to bottom
                // resize x,y
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                // grab pixels
                cv::Vec3b &current = frame.at<cv::Vec3b>(z, i);
                cv::Vec3b im = blend_image.at<cv::Vec3b>(cY, cX);
                // set pixel values
                current[0] = static_cast<unsigned char>(im[0]+(current[0]*pos));
                current[1] = static_cast<unsigned char>(im[1]+(current[1]*pos));
                current[2] = static_cast<unsigned char>(im[2]+(current[2]*pos));
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i); // invert pixel
            }
        }
    }
    static double pos_max = 7.0f;// max position set to 7.0
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// blend with Image
// takes cv::Mat reference
void ac::imageBlendThree(cv::Mat &frame) {
    if(blend_set == true) { // if blend_set is true (image selected)
        static double pos = 1.0f;// static pos equals 1.0
        for(int i = 0; i < frame.cols; ++i) { // from top to bottom
            for(int z = 0; z < frame.rows; ++z) {// from left to right
                // calculate x,y pixel position
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                // get pixel to manipulate reference
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                // get image pixel from calculated x,y positions
                cv::Vec3b im = blend_image.at<cv::Vec3b>(cY, cX);
                // calculate pixel data
                pixel[0] += (pixel[0]^im[0]);
                pixel[1] += (pixel[1]^im[1]);
                pixel[2] += static_cast<unsigned char>((pixel[2]^im[2])*pos);
                swapColors(frame, z, i);//swap colors
                if(isNegative) invert(frame, z, i);// if isNegative invert pixel
                
            }
        }
        // static int directione quals 1
        static int direction = 1;
        // static pos_max equals 7.0
        static double pos_max = 7.0f;
        if(direction == 1) {// if direction equals 1
            pos += 0.005;// pos plus equal 0.005
            if(pos > pos_max) {// pos greater than pos_max
                pos = pos_max;// pos set to pos_max
                direction = 0;// direction set to zero
                pos_max += 0.5f;// pos_max plus equal 0.5
            }
        } else if(direction == 0) {// direction is set to 0
            pos -= 0.005;// pos minus equal 0.005
            if(pos <= 1) {/// pos less than equal 1
                if(pos_max > 15) pos_max = 1.0f;//reset pos_max if greater than 15
                direction = 1;// direction set to 1
            }
        }
    }
}

// imageblend4
void ac::imageBlendFour(cv::Mat &frame) {
    if(blend_set == true) {
        static unsigned int state = 0;
        static double pos = 1.0;
        int w = frame.cols;// frame width
        int h = frame.rows;// frame height
        int cw = blend_image.cols;
        int ch = blend_image.rows;
        for(int z = 3; z < h-3; ++z) {// top to bottom
            for(int i = 3; i < w-3; ++i) {// left to right
                // current pixel by reference
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                // calculate resized image based x,y positions
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                // grab pixel refernces from blend_image
                cv::Vec3b &pr = blend_image.at<cv::Vec3b>((ch-cY), (cw-cX));
                cv::Vec3b &pg = blend_image.at<cv::Vec3b>((ch-cY), cX);
                cv::Vec3b &pb = blend_image.at<cv::Vec3b>(cY, (cw-cX));
                // perform operation based on current state variable
                switch(state) {
                    case 0:
                        pixel[0] += static_cast<unsigned char>((pr[0]+pg[1]+pb[2])*pos);
                        pixel[1] += static_cast<unsigned char>((pr[2]+pg[1]+pb[0])*pos);
                        break;
                    case 1:
                        pixel[1] += static_cast<unsigned char>((pr[2]+pg[1]+pb[0])*pos);
                        pixel[2] += static_cast<unsigned char>((pr[0]+pg[1]+pb[2])*pos);
                        break;
                    case 2:
                        pixel[2] += static_cast<unsigned char>((pr[0]+pg[1]+pb[2])*pos);
                        pixel[0] += static_cast<unsigned char>((pr[2]+pg[1]+pb[0])*pos);
                        break;
                }
                
            }
            
        }
        ++state;// increase state
        if(state > 2) state = 0; // greater than 2 reset state
        static int direction = 1;
        // static pos_max equals 7.0
        static double pos_max = 3.0f;
        if(direction == 1) {// if direction equals 1
            pos += 0.005;// pos plus equal 0.005
            if(pos > pos_max) {// pos greater than pos_max
                pos = pos_max;// pos set to pos_max
                direction = 0;// direction set to zero
                pos_max += 0.5f;// pos_max plus equal 0.5
            }
        } else if(direction == 0) {// direction is set to 0
            pos -= 0.005;// pos minus equal 0.005
            if(pos <= 1) {/// pos less than equal 1
                if(pos_max > 3) pos_max = 1.0f;//reset pos_max if greater than 15
                direction = 1;// direction set to 1
            }
        }
    }
}

// preform GaussianBlur
void ac::GaussianBlur(cv::Mat &frame) {
    cv::Mat out;
    cv::GaussianBlur(frame, out, cv::Size(5, 5), 0, 0);
    frame = out;
}
// preform MedianBlur
void ac::MedianBlur(cv::Mat &frame) {
    cv::Mat out;
    cv::medianBlur(frame, out, 5);
    frame = out;
}
// Increase / Decrease GaussianBlur
// takes cv::Mat reference
void ac::BlurDistortion(cv::Mat &frame) {
    cv::Mat out;// output
    static unsigned int index = 1, direction = 1;
    cv::GaussianBlur(frame, out, cv::Size(index, index), 0, 0);// output
    if(direction == 1) {// if direction equals 1
        if(index >= 51) direction = 0;// if greater than 51 set to zero go
        // opposite direction
        else index += 2;// increase
    } else {
        if(index <= 1) direction = 1;// go opposite direction
        else index -= 2;// decrease
    }
    frame = out;// frame equals out
}

// Draw gradient diamonds that grow and shrink and blend with source image
// takes cv::Mat reference
void ac::DiamondPattern(cv::Mat &frame) {
    static double pos = 1.0;// set pos to 1.0
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    for(int z = 0; z < h; ++z) {// from top to bottom
        for(int i = 0; i < w; ++i) {// from left to right
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);// get current pixel
            // calculate the colors of the gradient diamonds
            if((i%2) == 0) {// if i % 2 equals 0
                if((z%2) == 0) {// if z % 2 equals 0
                    // set pixel component values
                    buffer[0] = static_cast<unsigned char>(1-pos*buffer[0]);
                    buffer[2] = static_cast<unsigned char>((i+z)*pos);
                } else {
                    // set pixel coomponent values
                    buffer[0] = static_cast<unsigned char>(pos*buffer[0]-z);
                    buffer[2] = static_cast<unsigned char>((i-z)*pos);
                }
            } else {
                if((z%2) == 0) {// if z % 2 equals 0
                    // set pixel component values
                    buffer[0] = static_cast<unsigned char>(pos*buffer[0]-i);
                    buffer[2] = static_cast<unsigned char>((i-z)*pos);
                } else {
                    // set pixel component values
                    buffer[0] = static_cast<unsigned char>(pos*buffer[0]-z);
                    buffer[2] = static_cast<unsigned char>((i+z)*pos);
                }
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    // static direction starts off with 1
    static double pos_max = 7.0f;// pos maximum
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// Mirror blend
// blend current pixel in loop with current pixel
// on opposite side of image (width-x), (height-y)
// then increase / decrease the pixel colors
// takes cv::Mat reference
void ac::MirrorBlend(cv::Mat &frame) {
    static double pos = 1.0; // pos set to 1.0
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    cv::Mat orig;// unaltered image
    orig = frame.clone();// clone to orig
    for(int z = 2; z < h-3; ++z) { // from top to bottom
        for(int i = 2; i < w-3; ++i) {// from left to right
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i); // get pixel at i,z
            cv::Vec3b &pix1 = orig.at<cv::Vec3b>((h-z), (w-i));// get pixel at w-i, h-z
            // set pixel rgb components
            buffer[0] += static_cast<unsigned char>(pix1[0]*pos);
            buffer[1] += static_cast<unsigned char>(pix1[1]*pos);
            buffer[2] += static_cast<unsigned char>(pix1[2]*pos);
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i); // invert if isNegative true
        }
    }
    // static direction variable
    static int direction = 1;
    static double pos_max = 2.0f; // position maximum
    if(direction == 1) {// if direction is equal to 1
        pos += 0.1;// pos plus equal 0.1
        if(pos > pos_max) {// pos greater than pos max
            pos = pos_max;// pos = pos max
            direction = 0;// direction equals 0
            pos_max += 1.0f;// pos max pluse qual 1.0
        }
    } else if(direction == 0) {// if direction equals zero
        pos -= 0.1;// pos plus equal 0.1
        if(pos <= 1.0) {// pos less than 1.0
            if(pos_max > 2.0f) pos_max = 1.0f;// pos max greater than 2, pos_max set to 1
            direction = 1;// direction set back to 1
        }
    }
}

// Pulse color in and out
// takes cv::Mat reference
void ac::Pulse(cv::Mat &frame) {
    static double pos = 1.0; // index
    int w = frame.cols;// width variable
    int h = frame.rows;// height variable
    for(int z = 0; z < h; ++z) { // from top to bottom
        for(int i = 0; i < w; ++i) { // from left to right
            // current pixel reference cv::Vec3b
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);
            // pixel rgb components plus equal multiplied by pos
            buffer[0] += static_cast<unsigned char>(buffer[0]*pos);
            buffer[1] += static_cast<unsigned char>(buffer[1]*pos);
            buffer[2] += static_cast<unsigned char>(buffer[2]*pos);
            // swap colors
            swapColors(frame, z, i);
            // if negative variable true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1; // current direction
    static double pos_max = 3.0f; // maximum
    if(direction == 1) { // direction equals 1
        pos += 0.1; // pos plus equal 0.1
        if(pos > pos_max) {// pos greater than pos max
            pos = pos_max;// pos equals pox max
            direction = 0; // direction is zero
            pos_max += 1.0f; // pos max plus equal 1.0
        }
    } else if(direction == 0) { // direction is 0
        pos -= 0.1; // pos minus equal 0.1
        if(pos <= 1.0) { // less thane equal 1
            // reset pos max
            if(pos_max > 3.0f) pos_max = 1.0f;
            direction = 1; // direction set to 1
        }
    }
}

// Sideways Mirror function
// takes reference cv::Mat (an image)
void ac::SidewaysMirror(cv::Mat &frame) {
    static double pos = 1.0;
    int w = frame.cols;// frame image width
    int h = frame.rows;// frame image height
    cv::Mat orig;// unaltered image matrix
    orig = frame.clone();// clone frame to orig
    for(int z = 2; z < h-3; ++z) {// loop from top to bottom
        for(int i = 2; i < w-3; ++i) {// loop each row from left
            // to right
            // current pixel
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);
            // h minus y, width minus x positioned pixel
            cv::Vec3b &pix1 = orig.at<cv::Vec3b>((h-z), (w-i));
            // y and width minus x pixel
            cv::Vec3b &pix2 = orig.at<cv::Vec3b>(z, (w-i));
            // current pixel compponents equal
            // pix1[0] plus pix2[0] multiplied by kernel
            buffer[0] += static_cast<unsigned char>((pix1[0]+pix2[0])*pos);
            // do the same for each component
            buffer[1] += static_cast<unsigned char>((pix1[1]+pix2[1])*pos);
            buffer[2] += static_cast<unsigned char>((pix1[2]+pix2[2])*pos);
            // swap colors
            swapColors(frame, z, i);
            // if negative flag set invert frame
            if(isNegative) invert(frame, z, i);
        }
    }
    // max size
    static double pos_max = 4.0f;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

// Mirror function without blending
void ac::MirrorNoBlend(cv::Mat &frame) {
    int w = frame.cols; // width of frame
    int h = frame.rows; // height of frame
    cv::Mat orig;// original image unaltered
    orig = frame.clone(); // clone the frame to orig
    for(int z = 2; z < h-3; ++z) { // loop through the height
        for(int i = 2; i < w-3; ++i) {// go across each row
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);// current pixel
            // opposite of current pixel
            cv::Vec3b &pix1 = orig.at<cv::Vec3b>((h-z), (w-i));
            // opposite width, same height
            cv::Vec3b &pix2 = orig.at<cv::Vec3b>(z, (w-i));
            // opposite height, same width
            cv::Vec3b &pix3 = orig.at<cv::Vec3b>((h-z), i);
            // current pixel components equal
            // add each pixel value together
            buffer[0] = (pix1[0]+pix2[0]+pix3[0]);
            buffer[1] = (pix1[1]+pix2[1]+pix3[1]);
            buffer[2] = (pix1[2]+pix2[2]+pix3[2]);
            // swap RGB positions
            swapColors(frame, z, i);
            // if the negative switch is on, invert
            if(isNegative) invert(frame, z, i);
        }
    }
}
// Sort the Fuzz
void ac::SortFuzz(cv::Mat &frame) {
    unsigned int r = rand()%255; // random number betwen 0-254
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static std::vector<unsigned int> v;// vector for row of bytes info
    v.reserve(w);// reserve at least width bytes
    for(int z = 0; z < h; ++z) { //  loop: top to bottom
        for(int i = 0; i < w; ++i) { // loop: left ro right
            cv::Vec3b &value = frame.at<cv::Vec3b>(z, i); // current pixel
            unsigned int vv = 0; // unsigned integer
            unsigned char *cv = (unsigned char*)&vv; // pointer to unsigned char*
            // set each byte
            cv[0] = value[0];
            cv[1] = value[1];
            cv[2] = value[2];
            cv[3] = 0;
            v.push_back(vv); // push back
        }
        std::sort(v.begin(), v.end());// sort greater
        for(int i = 0; i < w; ++i) { // left to right
            unsigned char *value = (unsigned char*)&v[i];
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);// pixel at i,z
            // pixel values plus equal value plus r
            pixel[0] += static_cast<unsigned char>(value[0]+r);
            pixel[1] += static_cast<unsigned char>(value[1]+r);
            pixel[2] += static_cast<unsigned char>(value[2]+r);
            // swap colors
            swapColors(frame, z, i);
            // if negative variable set invert pixel
            if(isNegative) invert(frame, z, i);
            
        }
        v.erase(v.begin(), v.end()); // erase row
        // repeat
    }
}
// Fuzz filter
// takes cv::Mat reference
void ac::Fuzz(cv::Mat &frame) {
    int w = frame.cols;// width of frame
    int h = frame.rows;// height of frame
    static int amount = 5; // num pixel distortion
    for(int z = 0; z < h; ++z) {// loop top to bottom
        for(int i = 0; i < w; ++i) { // loop from left ro gith
            if((rand()%amount)==1) {// if random is true
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);// grab pixel
                pixel[0] += rand()%255;// add random numbers
                pixel[1] += rand()%255;
                pixel[2] += rand()%255;
            }
            // swap colors
            swapColors(frame, z, i);
            // if negative invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // direction equals 1 to start
    static int direction = 1;
    if(direction == 1) {// if direction equals 1
        ++amount; // increase amount
        if(amount >= 10) direction = 0; // greater than ten lower to zero
    } else {
        --amount;// decrease amount
        if(amount <= 5) direction = 1;// less than five direction equals 1
    }
}

// Double vision
// takes cv::Mat by refrence
void ac::DoubleVision(cv::Mat &frame) {
    static double pos = 1.0; // index
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    cv::Mat orig = frame.clone(); // clone frame to orig
    for(int z = 3; z < h-3; ++z) {// top to bottom
        for(int i = 3; i < w-3; ++i) { // left to right
            // current pixel
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &g = orig.at<cv::Vec3b>((h-z), i); // pixel at h-y, x
            cv::Vec3b &b = orig.at<cv::Vec3b>(z, (w-i)); // pixel at y, w-x
            // this is what gives the diamond image
            if((i%2) == 0) {// if modulus i by two returns zero
                if((z%2) == 0) {// modulus z by two returns zero
                    buffer[2] += static_cast<unsigned char>((i+z)*pos);// buffer[2] plus equals (i plus z) multiplied by pos
                } else {
                    buffer[2] += static_cast<unsigned char>((i-z)*pos); // buffer[2] plus equals (i minus z) mulitplied by pos
                }
            } else {
                if((z%2) == 0) {// modulus z by two equals zero
                    buffer[2] += static_cast<unsigned char>((i-z)*pos); // buffer[2] plus equals (i minus z) multiplied by pos
                } else {
                    buffer[2] += static_cast<unsigned char>((i+z)*pos); // buffer[2] plus equals (i plus z) multiplied by pos
                }
            }
            // this is what adds the rgb from other positions
            buffer[0] += g[0];
            buffer[1] += b[1];
            // swap colors
            swapColors(frame, z, i);
            // if negative variable set invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // static int direction
    // pos max
    static double pos_max = 7.0f;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// RGB Shift
// takes cv::Mat reference
void ac::RGBShift(cv::Mat &frame) {
    int w = frame.cols; // frame width
    int h = frame.rows;// frame height
    cv::Mat orig = frame.clone();// clone frame to orig
    static int shift = 0;// shift equals 0
    for(int z = 3; z < h-3; ++z) {// top to bottom
        for(int i = 3; i < w-3; ++i) {// left to right
            // grab pixel values
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &g = orig.at<cv::Vec3b>((h-z), i);
            cv::Vec3b &b = orig.at<cv::Vec3b>(z, (w-i));
            cv::Vec3b &r = orig.at<cv::Vec3b>((h-z), (w-i));
            // switch shift, each state preforms addition on different
            // pixel component values
            switch(shift) {
                case 0:
                    buffer[0] += r[0];
                    buffer[1] += g[1];
                    buffer[2] += b[2];
                case 1:
                    buffer[0] += g[0];
                    buffer[1] += b[1];
                    buffer[2] += r[2];
                    break;
                case 2:
                    buffer[0] += b[0];
                    buffer[1] += r[1];
                    buffer[2] += g[2];
                    break;
            }
            swapColors(frame, z, i);// swap the colors
            if(isNegative) invert(frame, z, i);// invert current pixel
        }
    }
    ++shift;// increase shift
    if(shift > 2) shift = 0;// shift greater than two reset shift
}
// RGB Seperation
// takes cv::Mat
void ac::RGBSep(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    cv::Mat orig = frame.clone();// orig is clone of frame
    for(int z = 3; z < h-3; ++z) {// top to bottom
        for(int i = 3; i < w-3; ++i) {// left to right
            // grab pixel values
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &g = orig.at<cv::Vec3b>((h-z), i);
            cv::Vec3b &b = orig.at<cv::Vec3b>(z, (w-i));
            // set pixel values
            buffer[0] += g[0];
            buffer[2] += b[2];
            swapColors(frame, z, i); // swap colors
            if(isNegative) invert(frame, z, i); // invert pixel
        }
    }
}
// Gradient Rainbow
// takes cv::Mat reference
void ac::GradientRainbow(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    // start color double
    double start_color = (1+(rand()%255))* 0.5;
    
    for(int z = 0; z < h; ++z) { // top to bottom
        for(int i = 0; i < w; ++i) {// left to right
            // reference to current pixel
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // color RGB variables
            int color_R = static_cast<int>(start_color * 4), color_G = static_cast<int>(start_color * 6), color_B = static_cast<int>(start_color * 8);
            // add to pixel color
            pixel[0] += static_cast<unsigned char>(color_R);
            pixel[1] += static_cast<unsigned char>(color_G);
            pixel[2] += static_cast<unsigned char>(color_B);
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
        start_color += 0.1;// increase start_color
    }
}
// Flash
// takes cv::Mat
void ac::GradientRainbowFlash(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static double pos = 0.1;
    static int shift = 0;
    // start color double
    double start_color = (1+(rand()%255)) * pos;
    for(int z = 0; z < h; ++z) { // top to bottom
        for(int i = 0; i < w; ++i) {// left to right
            // reference to current pixel
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // color RGB variables
            int color_R = static_cast<int>(start_color * 4), color_G = static_cast<int>(start_color * 6), color_B = static_cast<int>(start_color * 8);
            // add to pixel colors
            pixel[2] += static_cast<unsigned char>(color_R);
            pixel[1] += static_cast<unsigned char>(color_G);
            pixel[0] += static_cast<unsigned char>(color_B);
            // flash
            if(shift == 0) {
                pixel[2] = ~pixel[2];
                pixel[1] = ~pixel[1];
                pixel[0] = ~pixel[0];
            }
            
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
        start_color += 0.050;// increase start_color
    }
    shift = !shift;
    // static int direction
    static int direction = 1;
    // pos max
    // if direction equals 1
    if(direction == 1) {
        pos += 0.05; // pos plus equal 0.05
        if(pos > 1.0) { // if pos > pos max
            pos = 1.0;
            direction = 0;// direction equals 0
        }
    } else if(direction == 0) {// direction equals 1
        pos -= 0.05;// pos -= 0.05
        if(pos <= 0.1) {// if pos <= 1.0
            // set to 1.0
            direction = 1;// set direction back to 1
            pos = 0.1;
        }
    }
}
// Reverse Frame
// takes cv::Mat reference
void ac::Reverse(cv::Mat &frame) {
    cv::Mat output;//output matrix
    cv::flip(frame, output, 1); // flip image
    frame = output; // set frame to output
}
// Scanlines - Draws scanlines like a CRT.
void ac::Scanlines(cv::Mat &frame) {
    int w = frame.cols;// width
    int h = frame.rows;// height
    for(int z = 0; z < h; z += 2) {// top to bottom step by 2
        for(int i = 0; i < w; ++i) {// left to right
            cv::Vec3b &pix = frame.at<cv::Vec3b>(z, i);// current pixel
            pix[0] = pix[1] = pix[2] = 0;// set to zero
        }
    }
}
// Random Pixels
void ac::TVStatic(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static int dir = 0;
    for(int z = dir; z < h; z += 2) {// top to bottom step by 2 pixels
        for(int i = 0; i < w; ++i) {// left to right
            cv::Vec3b &pix = frame.at<cv::Vec3b>(z, i);// current pixel
            if(rand()%2>0) {
                pix[0] = pix[1] = pix[2] = 0;
            } else {
                pix[0] = pix[1] = pix[2] = 255;
            }
        }
    }
    ++dir;
    if(dir >= 2) dir = 0;
}
// Mirror Average
// takes cv::Mat reference
void ac::MirrorAverage(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    cv::Mat orig = frame.clone(); // clone original frame (make a copy)
    static double pos = 1.0f; // current index
    for(int z = 1; z < h-1; ++z) { // top to bottom
        for(int i = 1; i < w-1; ++i) {// left to right
            // refernce to current pixel located at i,z
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b mir_pix[3]; // array of Vec3b variables
            mir_pix[0] = orig.at<cv::Vec3b>((h-z), (w-i)); // pixel at w-i, h-z
            mir_pix[1] = orig.at<cv::Vec3b>((h-z), i); // pixel at i, h-z
            mir_pix[2] = orig.at<cv::Vec3b>(z,(w-i)); // pixel at w-i, z
            // take each component from mir_pix and find the average
            // with the same index from each variable in the mir_pix array
            // then multiply it by the position index (pos) then add it
            // to current pixel
            pixel[0] += static_cast<unsigned char>(((mir_pix[0][0]+mir_pix[1][0]+mir_pix[2][0])/3)*pos);
            pixel[1] += static_cast<unsigned char>(((mir_pix[0][1]+mir_pix[1][1]+mir_pix[2][1])/3)*pos);
            pixel[2] += static_cast<unsigned char>(((mir_pix[0][2]+mir_pix[1][2]+mir_pix[2][2])/3)*pos);
            
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // move up and down the color scale
    
    static double pos_max = 7.0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// Mirror Average Mix
// Takes cv::Mat matrix
void ac::MirrorAverageMix(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    cv::Mat orig = frame.clone(); // clone original frame
    static double pos = 1.0; // position index floating point
    for(int z = 1; z < h-1; ++z) { // loop from top to bottom
        for(int i = 1; i < w-1; ++i) { // loop from left to right
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i); // current pixel at i,z
            cv::Vec3b mir_pix[3]; // array of 3 cv::Vec3b vectors
            mir_pix[0] = orig.at<cv::Vec3b>((h-z), (w-i)); // pixel at w-i, h-z
            mir_pix[1] = orig.at<cv::Vec3b>((h-z), i); // pixel at i, h-z
            mir_pix[2] = orig.at<cv::Vec3b>(z,(w-i)); // pixel at w-i, z
            // take each pixel and average together mulitply by pos
            // and add its value to different components in
            // pixel reference vector
            pixel[0] += static_cast<unsigned char>(((mir_pix[0][0]+mir_pix[0][1]+mir_pix[0][2])/3)*pos);
            pixel[1] += static_cast<unsigned char>(((mir_pix[1][0]+mir_pix[1][1]+mir_pix[1][2])/3)*pos);
            pixel[2] += static_cast<unsigned char>(((mir_pix[2][0]+mir_pix[2][1]+mir_pix[2][2])/3)*pos);
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // pos max
    static double pos_max = 7.0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// Mean takes cv::Mat reference
void ac::Mean(cv::Mat &frame) {
    static double pos = 1.0; // position index floating point
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    cv::Scalar s = cv::mean(frame);
    for(int z = 0; z < h; ++z) { // from top to bottom
        for(int i = 0; i < w; ++i) {// from left to right
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i); // pixel at (i,z)
            // add to pixel values
            pixel[0] += static_cast<unsigned char>(pos*s[0]);
            pixel[1] += static_cast<unsigned char>(pos*s[1]);
            pixel[2] += static_cast<unsigned char>(pos*s[2]);
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // position movement
    static double pos_max = 7.0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

// Laplacian - takes cv::Mat reference
void ac::Laplacian(cv::Mat &frame) {
    cv::Mat out;
    cv::Laplacian(frame, out, CV_8U);
    frame = out;
}

// XOR - takes cv::Mat reference
void ac::Bitwise_XOR(cv::Mat &frame) {
    static cv::Mat initial;// set initial frame
    if(initial.size() != frame.size()) {
        initial = frame.clone(); // did frame resize? if so set the new frame value
    }
    cv::Mat start = frame.clone(); // clone frame (make a copy)
    cv::Mat output = frame.clone();// output variable
    cv::bitwise_xor(frame, initial, output); // OpenCV function bitwise_and
    initial = start;// set initial to start
    frame = output; // set frame to output
}

// And takes cv::Mat reference
void ac::Bitwise_AND(cv::Mat &frame) {
    static cv::Mat initial;// set initial frame
    if(initial.size() != frame.size()) {
        initial = frame.clone(); // did frame resize? if so set the new frame value
    }
    cv::Mat start = frame.clone(); // clone frame (make a copy)
    cv::Mat output = frame.clone();// output variable
    cv::bitwise_and(frame, initial, output); // OpenCV function bitwise_and
    initial = start;// set initial to start
    frame = output; // set frame to output
}
// takes cv::Mat reference
void ac::Bitwise_OR(cv::Mat &frame) {
    static cv::Mat initial;// set initial frame
    if(initial.size() != frame.size()) {
        initial = frame.clone(); // did frame resize? if so set the new frame value
    }
    cv::Mat start = frame.clone(); // clone frame (make a copy)
    cv::Mat output = frame.clone();// output variable
    cv::bitwise_or(frame, initial, output); // OpenCV function bitwise_and
    initial = start;// set initial to start
    frame = output; // set frame to output
}
// takes cv::Mat reference
// Equalize image
void ac::Equalize(cv::Mat &frame) {
    cv::Mat output[3]; // array of cv::Mat
    std::vector<cv::Mat> v; // vector to hold cv::Mat values
    cv::split(frame, v);// split b,g,r values
    cv::equalizeHist(v[0], output[0]);// equalize
    cv::equalizeHist(v[1], output[1]);
    cv::equalizeHist(v[2], output[2]);
    cv::merge(output,3,frame);// merge back to create final output
}

// Channel sort - takes cv::Mat reference
void ac::ChannelSort(cv::Mat &frame) {
    static double pos = 1.0; // color scale
    std::vector<cv::Mat> v; // to hold the Matrix for split
    cv::split(frame, v);// split the channels into seperate matrices
    cv::Mat channels[3]; // output channels
    cv::Mat output; // for merge
    cv::sort(v[0], channels[0],cv::SORT_ASCENDING); // sort each matrix
    cv::sort(v[1], channels[1],cv::SORT_ASCENDING);
    cv::sort(v[2], channels[2],cv::SORT_ASCENDING);
    cv::merge(channels, 3, output); // combine the matrices
    for(int z = 0; z < frame.rows; ++z) { // top to bottom
        for(int i = 0; i < frame.cols; ++i) { // left to right
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i); // get reference to pixel
            cv::Vec3b &ch_pixel = output.at<cv::Vec3b>(z, i); // get reference to pixel
            // add and multiply components to channels
            pixel[0] += static_cast<unsigned char>(ch_pixel[0]*pos);
            pixel[1] += static_cast<unsigned char>(ch_pixel[1]*pos);
            pixel[2] += static_cast<unsigned char>(ch_pixel[2]*pos);
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    // pos max
    static double pos_max = 7.0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

// takes cv::Mat reference
void ac::Reverse_XOR(cv::Mat &frame) {
    static cv::Mat initial = frame;
    if(initial.cols != frame.cols || initial.rows != frame.rows) {
        initial = frame;
    }
    static double pos = 1.0;
    cv::Mat start = frame.clone();
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &in_pixel = initial.at<cv::Vec3b>(z, i);
            pixel[0] ^= in_pixel[2];
            pixel[1] ^= in_pixel[1];
            pixel[2] ^= in_pixel[0];
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    initial = start;
    static double pos_max = 7.0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

// takes cv::Mat reference
void ac::CombinePixels(cv::Mat &frame) {
    static double pos = 1.0, pos_max = 7.0;
    static int direction = 1;
    cv::Scalar s(1.0, 100.0, 200.0);
    for(int z = 2; z < frame.rows-2; ++z) {
        for(int i = 2; i < frame.cols-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b pixels[4];
            pixels[0] = frame.at<cv::Vec3b>(z, i+1);
            pixels[1] = frame.at<cv::Vec3b>(z+1, i);
            pixels[2] = frame.at<cv::Vec3b>(z+1, i+1);
            pixel[0] ^= (pixels[0][0]+pixels[1][0]+pixels[2][0]);
            pixel[1] ^= (pixels[0][1]+pixels[1][1]+pixels[2][1]);
            pixel[2] ^= (pixels[0][2]+pixels[1][2]+pixels[2][2]);
            pixel[0] *= static_cast<unsigned char>(pos);
            pixel[1] *= static_cast<unsigned char>(pos);
            pixel[2] *= static_cast<unsigned char>(pos);
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    procPos(direction, pos, pos_max);
}
// Canny takes cv::Mat reference
void ac::Canny(cv::Mat &frame) {
    cv::Mat out;
    static double x = 50, y = 10;
    cv::Canny(frame, out, x, y);
    cv::Mat converted;
    cv::cvtColor(out, converted, cv::COLOR_GRAY2BGR);
    frame = converted;
}

// Flip takes cv::Mat reference
// flip the iamge every other frame
void ac::FlipTrip(cv::Mat &frame) {
    static int _flip = 0;// index variable
    cv::Mat output;// output matrix
    switch(_flip){
        case 0:
            cv::flip(frame, output, 1); // flip matrix
            frame = output;// frame equals output
            _flip++;// increase index
            break;
        case 1:
            // do nothing
            _flip = 0; // index equals zero
            break;
    }
}

// Loop tiled boxes
void ac::Boxes(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int pixel_size = 8; // size of each tile
    for(int z = 0; z < h; z += pixel_size) { // from top to bottom
        for(int i = 0; i < w; i += pixel_size) { // from left to right
            unsigned char rgb[3]; // 3 bytes
            rgb[0] = rand()%255; // set to random number
            rgb[1] = rand()%255;
            rgb[2] = rand()%255;
            for(int y = z; y < static_cast<int>(z+pixel_size); ++y) { // tile top to bottom
                for(int x = i; x < static_cast<int>(i+pixel_size); ++x) {// tile left to right
                    if(x < w && y < h) { // is x,y on screen?
                        // reference to pixel
                        cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
                        pixel[0] += rgb[0]; // add each component
                        pixel[1] += rgb[1];
                        pixel[2] += rgb[2];
                    }
                }
            }
        }
    }
    static int direction = 1; // current direction, grow versus shrink
    if(direction == 1) {
        ++pixel_size;// grow by 1
        // if greater than 1/6 of frame size set to zero
        if(static_cast<int>(pixel_size) > (w/6)) direction = 0;
    } else if(direction == 0) {// direction equals zero shrink
        --pixel_size;// shrink
        if(pixel_size < 24) direction = 1;
    }
}
// Loop tiled box fade
void ac::BoxesFade(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static cv::Vec3b color(rand()%255, rand()%255, rand()%255); // random color
    static int sw = 0; // with component to increase
    static unsigned int pixel_size = 8; // size of each tile
    for(int z = 0; z < h; z += pixel_size) { // from top to bottom
        ++sw;// increase
        if(sw > 2) sw = 0;//greater than 2 reset
        for(int i = 0; i < w; i += pixel_size) { // from left to right
            for(int y = z; y < z+pixel_size; ++y) { // tile top to bottom
                for(int x = i; x < i+pixel_size; ++x) {// tile left to right
                    if(x < w && y < h) { // is x,y on screen?
                        // reference to pixel
                        switch(sw) {
                            case 0: // increase B
                                ++color[0];
                                break;
                            case 1://  increase G
                                ++color[1];
                                break;
                            case 2:// increase R
                                ++color[2];
                                break;
                        }
                        if(color[0] >= 254) color[0] = rand()%255; // reset if over
                        if(color[1] >= 254) color[1] = rand()%255;
                        if(color[2] >= 254) color[2] = rand()%255;
                        
                        cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
                        pixel[0] += color[0]; // add each component
                        pixel[1] += color[1];
                        pixel[2] += color[2];
                    }
                }
            }
        }
    }
    static int direction = 1; // current direction, grow versus shrink
    if(direction == 1) {
        ++pixel_size;// grow by 1
        // if greater than 1/6 of frame size set to zero
        if(pixel_size > (w/6)) direction = 0;
    } else if(direction == 0) {// direction equals zero shrink
        --pixel_size;// shrink
        if(pixel_size < 24) direction = 1;
    }
}


void ac::FlashBlack(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static cv::Vec3b black(0, 0, 0);
    static bool flash = false;
    for(int z = 0; z < h; ++z) {
        for(int i = 0;  i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(flash == true)
                pixel = black;
            
        }
    }
    flash = !flash;
}

void ac::SlideRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static int offset_x = 0;
    int color[2] = { rand()%3, rand()%3 };
    for(int z = 3; z < h-3; ++z) {
        for(int i = 3; i < w-3; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(offset_x+i < (w-1)) {
                cv::Vec3b off_pix = frame.at<cv::Vec3b>(z, offset_x+i);
                pixel[color[0]] += static_cast<unsigned char>(off_pix[color[0]]);
                cv::Vec3b off_red = frame.at<cv::Vec3b>(z, (w-(offset_x+i)));
                pixel[color[1]] += static_cast<unsigned char>(off_red[color[1]]);
            }
        }
    }
    static unsigned int direction = 1;
    if(direction == 1) {
        ++offset_x;
        if(offset_x > 5) {
            direction = 0;
        }
    } else {
        --offset_x;
        if(offset_x <= 1) {
            direction = 1;
        }
    }
}
// Blend from Side to Side
void ac::Side2Side(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 3.0;
    for(int z = 0; z < h; ++z) {
        cv::Scalar total;
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            total[0] += (pixel[0]/2);
            total[1] += (pixel[1]/2);
            total[2] += (pixel[2]/2);
            pixel[0] = static_cast<unsigned char>(pixel[0] + (total[0]*pos)*0.01);
            pixel[1] = static_cast<unsigned char>(pixel[1] + (total[1]*pos)*0.01);
            pixel[2] = static_cast<unsigned char>(pixel[2] + (total[2]*pos)*0.01);
            
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}
// Blend from Top To Bottom
void ac::Top2Bottom(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 5.0;
    for(int i = 0; i < w; ++i) {
        cv::Scalar total;
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            total[0] += (pixel[0]/2);
            total[1] += (pixel[1]/2);
            total[2] += (pixel[2]/2);
            pixel[0] = static_cast<unsigned char>(pixel[0] + (total[0]*pos)*0.01);
            pixel[1] = static_cast<unsigned char>(pixel[1] + (total[1]*pos)*0.01);
            pixel[2] = static_cast<unsigned char>(pixel[2] + (total[2]*pos)*0.01);
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::StrobeRedGreenBlue(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned color = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(color) {
                case 0: // B
                    pixel[1] = pixel[2] = 0;
                    break;
                case 1:// G
                    pixel[0] = pixel[2] = 0;
                    break;
                case 2:// R
                    pixel[0] = pixel[1] = 0;
            }
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    ++color;
    if(color > 2) color = 0;
}

void ac::Blend_Angle(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 5.0;
    for(int z = 0; z < h; ++z) {
        cv::Scalar total;
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            total[0] += pixel[0] * 0.01;
            total[1] += pixel[1] * 0.01;
            total[2] += pixel[2] * 0.01;
            
            pixel[0] = static_cast<unsigned char>(pixel[0] + (total[0]) * (pos*0.1));
            pixel[1] = static_cast<unsigned char>(pixel[1] + (total[1]) * (pos*0.1));
            pixel[2] = static_cast<unsigned char>(pixel[2] + (total[2]) * (pos*0.1));
            
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    
    static int direction = 1;
    procPos(direction, pos,pos_max);
}

void ac::Outward(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static double start_pos = 1, pos = 1.0, pos_max = 5.0;
    
    static cv::Scalar offset(5, 50, 100);
    
    pos = start_pos;
    
    for(int y = h/2; y > 0; --y) {
        for(int x = 0; x < w; ++x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] += static_cast<unsigned char>((pos*offset[0]));
            pixel[1] += static_cast<unsigned char>((pos*offset[1]));
            pixel[2] += static_cast<unsigned char>((pos*offset[2]));
            // swap colors
            swapColors(frame, y, x);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, y, x);
            
        }
        pos += 0.005;
    }
    
    pos = start_pos;
    
    for(int y = h/2+1; y < h; ++y) {
        for(int x = 0; x < w; ++x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] += static_cast<unsigned char>((pos*offset[0]));
            pixel[1] += static_cast<unsigned char>((pos*offset[1]));
            pixel[2] += static_cast<unsigned char>((pos*offset[2]));
            // swap colors
            swapColors(frame, y, x);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, y, x);
        }
        pos += 0.005;
    }
    
    offset[0] += 12;
    offset[1] += 6;
    offset[2] += 3;
    
    for(int i = 0; i < 3; ++i) if(offset[i] > 200) offset[i] = 0;
    
    static int direction = 1;
    procPos(direction, start_pos, pos_max);
}

void ac::OutwardSquare(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    int wx = w/2;
    static double start_pos = 1, pos = 1.0, pos_max = 5.0;
    static cv::Scalar offset(5, 50, 100);
    pos = start_pos;
    
    for(int y = h/2; y > 0; --y) {
        for(int x = 0; x < wx; ++x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] += static_cast<unsigned char>((pos*offset[0]));
            pixel[1] += static_cast<unsigned char>((pos*offset[1]));
            pixel[2] += static_cast<unsigned char>((pos*offset[2]));
            // swap colors
            swapColors(frame, y, x);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, y, x);
        }
        pos += 0.005;
    }
    //pos = start_pos;
    for(int y = h/2; y > 0; --y) {
        for(int x = w-1; x > wx-1; --x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] += static_cast<unsigned char>((pos*offset[0]));
            pixel[1] += static_cast<unsigned char>((pos*offset[1]));
            pixel[2] += static_cast<unsigned char>((pos*offset[2]));
            // swap colors
            swapColors(frame, y, x);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, y, x);
        }
        pos += 0.005;
    }
    
    pos = start_pos;
    for(int y = h/2+1; y < h; ++y) {
        for(int x = 0; x < wx; ++x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] += static_cast<unsigned char>((pos*offset[0]));
            pixel[1] += static_cast<unsigned char>((pos*offset[1]));
            pixel[2] += static_cast<unsigned char>((pos*offset[2]));
            // swap colors
            swapColors(frame, y, x);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, y, x);
        }
        pos += 0.005;
    }
    //pos = start_pos;
    for(int y = h/2+1; y < h; ++y) {
        for(int x = w-1; x > wx-1; --x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] += static_cast<unsigned char>((pos*offset[0]));
            pixel[1] += static_cast<unsigned char>((pos*offset[1]));
            pixel[2] += static_cast<unsigned char>((pos*offset[2]));
            // swap colors
            swapColors(frame, y, x);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, y, x);
        }
        pos += 0.005;
    }
    offset[0] += 12;
    offset[1] += 6;
    offset[2] += 3;
    for(int i = 0; i < 3; ++i) if(offset[i] > 200) offset[i] = 0;
    static int direction = 1;
    procPos(direction, start_pos, pos_max);
}

void ac::ShiftPixels(cv::Mat &frame) {
    static unsigned int offset = 1;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    for(int z = 0; z < h; ++z) {
        unsigned int start = 0;
        for(int i = offset; i < w && start < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &source = frame.at<cv::Vec3b>(z, start);
            pixel[0] += source[0];
            pixel[1] += source[1];
            pixel[2] += source[2];
            ++start;
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
        for(int i = 0; i < offset-1 && start < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &source = frame.at<cv::Vec3b>(z, start);
            pixel[0] += source[0];
            pixel[1] += source[1];
            pixel[2] += source[2];
            ++start;
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    static unsigned int max_up = (w/16);
    if(direction == 1) {
        ++offset;
        if(offset > max_up)  {
            direction = 0;
            max_up += 4;
            if(max_up > (w/4)) {
                max_up = (w/16);
            }
        }
    } else if(direction == 0) {
        --offset;
        if(offset < 2) direction = 1;
    }
}

void ac::ShiftPixelsDown(cv::Mat &frame) {
    static unsigned int offset = 1;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    for(int i = 0; i < w; ++i) {
        unsigned int start = 0;
        for(int z = offset; z < h && start < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &source = frame.at<cv::Vec3b>(z, start);
            pixel[0] += static_cast<unsigned char>(source[0]*pos);
            pixel[1] += static_cast<unsigned char>(source[1]*pos);
            pixel[2] += static_cast<unsigned char>(source[2]*pos);
            ++start;
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
        for(int z = 0; z < offset-1 && start < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b &source = frame.at<cv::Vec3b>(z, start);
            pixel[0] += static_cast<unsigned char>(source[0]*pos);
            pixel[1] += static_cast<unsigned char>(source[1]*pos);
            pixel[2] += static_cast<unsigned char>( source[2]*pos);
            ++start;
            // swap colors
            swapColors(frame, z, i);
            // if isNegative true invert pixel
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    static unsigned int max_up = (h/8);
    if(direction == 1) {
        ++offset;
        if(offset > max_up)  {
            direction = 0;
            max_up += 4;
            if(max_up > (h/2)) {
                max_up = (h/8);
            }
        }
    } else if(direction == 0) {
        --offset;
        if(offset < 2) direction = 1;
    }
    static int dir = 1;
    procPos(dir, pos, pos_max);
    
}

void ac::XorMultiBlend(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 3.0;
    cv::Scalar s(pos, -pos, pos);
    for(int y = h-1; y > 0; --y) {
        for(int x = w-1; x > 0; --x) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(y, x);
            pixel[0] = static_cast<unsigned char>((pixel[0]^(int)s[0])*pos);
            pixel[1] = static_cast<unsigned char>((pixel[1]^(int)s[1])*pos);
            pixel[2] = static_cast<unsigned char>((pixel[2]^(int)s[2])*pos);
            
            swapColors(frame, y, x);
            if(isNegative) invert(frame, y, x);
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max, 4.0);
}

void ac::BitwiseRotate(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int offset = 0;
    static int direction = 1;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            
            if(direction == 1) {
                pixel[0] = ror(pixel[0], offset);
                pixel[1] = rol(pixel[1], offset);
                pixel[2] = ror(pixel[2], offset);
            } else {
                pixel[0] = rol(pixel[0], offset);
                pixel[1] = ror(pixel[1], offset);
                pixel[2] = rol(pixel[2], offset);
            }
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    if(direction == 1) {
        offset++;
        if(offset >= 7) {
            direction = 0;
        }
    } else {
        offset--;
        if(offset <= 1) {
            direction = 1;
        }
    }
}

void ac::BitwiseRotateDiff(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int offset = 1;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int q = 0; q < 3; ++q)
                pixel[q] += static_cast<unsigned char>((pixel[q]-ror(pixel[q], offset)));
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    ++offset;
    if(offset > 7) offset = 1;
}

void ac::HPPD(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 4.0;
    for(int z = 0; z < h; ++z) {
        cv::Scalar total;
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            total[0] += pixel[0];
            total[1] += pixel[1];
            total[2] += pixel[2];
            pixel[0] = static_cast<unsigned char>(pixel[0]-total[0]*pos);
            pixel[1] = static_cast<unsigned char>(pixel[1]-total[1]*pos);
            pixel[2] = static_cast<unsigned char>(pixel[2]-total[2]*pos);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::FuzzyLines(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 4.0;
    cv::Scalar prev_pixel;
    double value[3] = { 0 };
    
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b temp = pixel;
            
            value[0] += temp[0]+temp[1]+temp[2];
            value[1] -= temp[0]+temp[1]+temp[2];
            value[2] += temp[0]+temp[1]+temp[2];
            pixel[0] += static_cast<unsigned char>((value[0]*pos)*0.001);
            pixel[1] += static_cast<unsigned char>((value[1]*pos)*0.001);
            pixel[2] += static_cast<unsigned char>((value[2]*pos)*0.001);
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
            prev_pixel[0] = pixel[0];
            prev_pixel[1] = pixel[1];
            prev_pixel[2] = pixel[2];
        }
    }
    
    static int direction = 1;
    procPos(direction, pos, pos_max);
    
    
}

void ac::GradientLines(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int count = 0, index = 0;
    
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] += static_cast<unsigned char>(count);
            ++count;
            if(count >= 255) {
                count = 0;
                ++index;
                if(index > 2) index = 0;
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
}

void ac::GradientSelf(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static unsigned int count = 0, index = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] = static_cast<unsigned char>((pixel[index]*pos)+count);
            ++count;
            if(count >= 255) {
                count = 0;
            }
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++index;
        if(index > 2) index = 0;
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::GradientSelfVertical(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static unsigned int count = 0, index = 0;
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] = static_cast<unsigned char>((pixel[index]*pos)+count);
            ++count;
            if(count >= 255) {
                count = 0;
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++index;
        if(index > 2) index = 0;
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::GradientDown(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static unsigned int count = 0, index = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] = static_cast<unsigned char>((pixel[index]*pos)+count);
            ++index;
            if(index > 2) index = 0;
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++count;
        if(count >= 255) {
            count = 0;
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::GraidentHorizontal(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static unsigned int count = 0, index = 0;
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] = static_cast<unsigned char>((pixel[index]*pos)+count);
            ++index;
            if(index > 2) index = 0;
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++count;
        if(count >= 255) {
            count = 0;
        }
    }
    int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::GradientRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int count = 0, index = 0;
    static unsigned int direction = 1;
    if(direction == 1) {
        for(int z = 0; z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                pixel[index] = pixel[index]*count;
                ++count;
                if(count >= 255) {
                    ++index;
                    if(index > 2) {
                        index = 0;
                    }
                }
                swapColors(frame, z, i);
                if(isNegative) invert(frame, z, i);
            }
        }
    } else {
        for(int i = 0; i < w; ++i) {
            for(int z = 0; z < h; ++z) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                pixel[index] = pixel[index]*count;
                ++count;
                if(count >= 255) {
                    ++index;
                    if(index > 2) {
                        index = 0;
                    }
                }
                swapColors(frame, z, i);
                if(isNegative) invert(frame, z, i);
            }
        }
    }
    if(direction == 1) direction = 0; else direction = 1;
}


void ac::Inter(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int start_x = 0;
    for(int z = start_x; z < h; z += 2) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] = pixel[1] = pixel[2] = 0;
        }
    }
    if(start_x == 0) start_x = 1; else start_x = 0;
}


void ac::UpDown(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    double alpha = 1.0;
    bool order = true;
    
    for(int i = 0; i < w; ++i) {
        if(order == true) {
            order = false;
            for(int z = 0; z < h; ++z) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                for(int q = 0; q < 3; ++q)
                    pixel[q] = static_cast<unsigned char>(alpha+(pixel[q]*pos));
                
                swapColors(frame, z, i);
                if(isNegative) invert(frame, z, i);
            }
            alpha += 0.1;
        } else {
            order = true;
            for(int z = h-1; z > 1; --z) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                for(int q = 0; q < 3; ++q)
                    pixel[q] =static_cast<unsigned char>(alpha-(pixel[q]*pos));
                
                swapColors(frame, z, i);
                if(isNegative) invert(frame, z, i);
            }
            
            alpha += 0.1;
        }
        
    }
    
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::LeftRight(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    double alpha = 1.0;
    bool order = true;
    for(int z = 0; z < h; ++z) {
        if(order == true) {
            order = false;
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                for(int q = 0; q < 3; ++q)
                    pixel[q] = static_cast<unsigned char>(alpha+(pixel[q]*pos));
                
                swapColors(frame, z, i);
                if(isNegative) invert(frame, z, i);
            }
            alpha += 0.1;
        } else {
            order = true;
            for(int i = w-1; i > 1; --i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                for(int q = 0; q < 3; ++q)
                    pixel[q] = static_cast<unsigned char>(alpha-(pixel[q]*pos));
                
                swapColors(frame, z, i);
                if(isNegative) invert(frame, z, i);
            }
            
            alpha += 0.1;
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::StrobeScan(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static int color_mode = 0;
    unsigned int over = rand()%255;
    static unsigned int cdirection = 1;
    
    for(int z = 0; z < h; ++z) {
        switch(color_mode) {
            case 0: {
                for(int i = 0; i < w; ++i) {
                    cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                    pixel[color_mode] = static_cast<unsigned char>(over+(pixel[color_mode]*pos));
                    swapColors(frame, z, i);
                    if(isNegative) invert(frame, z, i);
                }
            }
                break;
            case 1: {
                for(int i = w-1; i > 1; --i) {
                    cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                    pixel[color_mode] -= static_cast<unsigned char>(over+(pixel[1]*pos));
                    swapColors(frame, z, i);
                    if(isNegative) invert(frame, z, i);
                    
                }
            }
                break;
            case 2: {
                for(int i = 0; i < w; ++i) {
                    cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                    pixel[color_mode] ^= static_cast<unsigned char>(over+(pixel[color_mode]*pos));
                    swapColors(frame, z, i);
                    if(isNegative) invert(frame, z, i);
                    
                }
            }
                break;
        }
        
        if(cdirection == 1) {
            ++color_mode;
            if(color_mode > 2) {
                cdirection = 0;
            }
        } else if(cdirection == 0) {
            --color_mode;
            if(color_mode < 0) {
                cdirection = 1;
            }
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::BlendedScanLines(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int cnt = 0;
    for(int z = 0; z < h; ++z) {
        int r = rand()%255;
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[cnt] += static_cast<unsigned char>(r);
            ++r;
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
            ++cnt;
            if(cnt > 2) {
                cnt = 0;
            }
        }
    }
}

void ac::GradientStripes(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int offset = 0, count = 0;
    unsigned int count_i = (rand()%0xFF)+(rand()%0xFFFFFF);//color offset
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[offset] += static_cast<unsigned char>(count);
            pixel[2-offset] -= static_cast<unsigned char>(count_i);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++count;
        ++count_i;
    }
    ++offset;
    if(offset > 2)
        offset = 0;
}
// this one pixelates the image very heavily.
void ac::XorSine(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static cv::Scalar val(rand()%10, rand()%10, rand()%10);
    static double pos = 1.0, pos_max = 7.0;
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] ^= static_cast<unsigned char>(sin(pixel[0])*val[0]);
            pixel[1] ^= static_cast<unsigned char>(sin(pixel[1])*val[1]);
            pixel[2] ^= static_cast<unsigned char>(sin(pixel[2])*val[2]);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    for(int q = 0; q < 3; ++q) {
        if(direction == 1)
            val[q] += pos;
        else
            val[q] -= pos;
    }
    procPos(direction, pos, pos_max);
}


void ac::Square::setSize(const int &xx, const int &yy, const int &w, const int &h) {
    x = xx;
    y = yy;
    if(width != w || height != h) {
        width = w;
        height = h;
        image.create(cvSize(w, h), CV_8UC3);
    }
}
void ac::Square::setPos(const int &p) {
    pos = p;
}
void ac::Square::copyImage(const cv::Mat &f) {
    for(int i = 0, src_x = x; i < width; ++i, ++src_x) {
        for(int z = 0, src_y = y; z < height; ++z, ++src_y) {
            cv::Vec3b &pixel = image.at<cv::Vec3b>(z, i);
            cv::Vec3b src = f.at<cv::Vec3b>(src_y, src_x);
            pixel = src;
        }
    }
}
void ac::Square::copyImageToTarget(int xx, int yy, cv::Mat &f) {
    for(int i = 0, dst_x = xx; i < width; ++i, ++dst_x) {
        for(int z = 0, dst_y = yy; z < height; ++z, ++dst_y) {
            cv::Vec3b &pixel = f.at<cv::Vec3b>(dst_y, dst_x);
            cv::Vec3b src = image.at<cv::Vec3b>(z, i);
            pixel = src;
        }
    }
}

void Square_Swap(ac::Square *squares, int num_w, int num_h, cv::Mat &frame, bool random = false) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    unsigned int square_w=(w/num_w), square_h=(h/num_h);
    int pos = 0;
    ac::Point *points = new ac::Point[num_w*num_h];
    std::vector<ac::Square *> square_vec;
    for(int rx = 0; rx < num_w; ++rx) {
        for(int ry = 0; ry < num_h; ++ry) {
            int cx = rx*square_w;
            int cy = ry*square_h;
            points[pos].x = cx;
            points[pos].y = cy;
            squares[pos].setPos(pos);
            squares[pos].setSize(cx, cy, square_w, square_h);
            squares[pos].copyImage(frame);
            square_vec.push_back(&squares[pos]);
            ++pos;
        }
    }
    
    static auto rng = std::default_random_engine {};
    // shuffle instead of randomize
    if(random == false) std::shuffle(square_vec.begin(), square_vec.end(),rng);
    for(int i = 0; i < pos; ++i) {
        if(random == false)
            // use shuffled
            square_vec[i]->copyImageToTarget(points[i].x, points[i].y,frame);
        else
            // use random
            square_vec[rand()%pos]->copyImageToTarget(points[i].x, points[i].y,frame);
    }
    delete [] points;
}


// SquareSwap
void ac::SquareSwap(cv::Mat &frame) {
    static unsigned int cnt = 0;
    switch(cnt) {
        case 0:
            SquareSwap4x2(frame);
            break;
        case 1:
            SquareSwap8x4(frame);
            break;
        case 2:
            SquareSwap16x8(frame);
            break;
        case 3:
            SquareSwap64x32(frame);
            break;
    }
    ++cnt;
    if(cnt > 3) cnt = 0;
}

void ac::SquareSwap4x2(cv::Mat &frame) {
    const int num_w = 4, num_h = 2;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareSwap8x4(cv::Mat &frame) {
    const int num_w = 8, num_h = 4;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareSwap16x8(cv::Mat &frame) {
    const int num_w = 16, num_h = 8;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareSwap64x32(cv::Mat &) {
    //const int num_w = 64, num_h = 32;
    //static Square squares[num_w*num_h];
    //Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareBars(cv::Mat &frame) {
    static const int num_w = 16, num_h = 1;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareBars8(cv::Mat &frame) {
    static const int num_w = 8, num_h = 1;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareSwapRand16x8(cv::Mat &frame) {
    static const int num_w = 16, num_h = 8;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame, true);
}

void ac::SquareVertical8(cv::Mat &frame) {
    static const int num_w = 1, num_h = 8;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}

void ac::SquareVertical16(cv::Mat &frame) {
    static const int num_w = 1, num_h = 16;
    static Square squares[num_w*num_h];
    Square_Swap(squares, num_w, num_h, frame);
}


void ShiftSquares(std::vector<ac::Square *> &s, int pos, bool direction=true) {
    if(direction == true) {
        for(int i = 0; i < s.size(); ++i) {
            int p = s[i]->getPos();
            if(p+1 > (int)s.size()-1) {
                s[i]->setPos(0);
            } else {
                ++p;
                s[i]->setPos(p);
            }
        }
    } else {
        for(int i = 0; i < pos; ++i) {
            int p = s[i]->getPos();
            --p;
            s[i]->setPos(p);
            if(p < 0) {
                s[i]->setPos(pos-1);
            }
        }
    }
}

void SquareVertical(const int num_w, const int num_h, ac::Square *squares, cv::Mat &frame, bool direction=true) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    int square_w=(w/num_w), square_h=(h/num_h);
    int pos = 0;
    ac::Point *points = new ac::Point[num_w*num_h];
    std::vector<ac::Square *> square_vec;
    for(int rx = 0; rx < (int)num_w; ++rx) {
        for(int ry = 0; ry < (int)num_h; ++ry) {
            int cx = rx*square_w;
            int cy = ry*square_h;
            points[pos].x = cx;
            points[pos].y = cy;
            squares[pos].setSize(cx, cy, square_w, square_h);
            squares[pos].copyImage(frame);
            square_vec.push_back(&squares[pos]);
            ++pos;
        }
    }
    ShiftSquares(square_vec,pos,direction);
    for(int i = 0; i < pos; ++i) {
        const int p = square_vec[i]->getPos();
        square_vec[i]->copyImageToTarget(points[p].x, points[p].y, frame);
    }
    delete [] points;
}

void ac::SquareVertical_Roll(cv::Mat &frame) {
    const int num_w = 1, num_h = 20;
    static Square squares[num_w*num_h];
    static int lazy = 0;
    if(lazy == 0) {
        int cpos = 0;
        for(int cx = 0; cx < num_w; ++cx)
            for(int cy = 0; cy < num_h; ++cy) {
                squares[cpos].setPos(cpos);
                ++cpos;
            }
        lazy = 1;
    }
    SquareVertical(num_w, num_h, squares, frame);
}

void ac::SquareSwapSort_Roll(cv::Mat &frame) {
    const int num_w = 16, num_h = 8;
    static Square squares[num_w*num_h];
    static int lazy = 0;
    if(lazy == 0) {
        int cpos = 0;
        for(int cx = 0; cx < num_w; ++cx)
            for(int cy = 0; cy < num_h; ++cy) {
                squares[cpos].setPos(cpos);
                ++cpos;
            }
        lazy = 1;
    }
    SquareVertical(num_w, num_h, squares, frame);
}

void ac::SquareVertical_RollReverse(cv::Mat &frame) {
    const int num_w = 1, num_h = 20;
    static Square squares[num_w*num_h];
    static int lazy = 0;
    if(lazy == 0) {
        int cpos = 0;
        for(int cx = 0; cx < num_w; ++cx)
            for(int cy = 0; cy < num_h; ++cy) {
                squares[cpos].setPos(cpos);
                cpos++;
                
            }
        lazy = 1;
    }
    SquareVertical(num_w, num_h, squares, frame, false);
}

void ac::SquareSwapSort_RollReverse(cv::Mat &frame) {
    const int num_w = 16, num_h = 8;
    static Square squares[num_w*num_h];
    static int lazy = 0;
    if(lazy == 0) {
        int cpos = 0;
        for(int cx = 0; cx < num_w; ++cx)
            for(int cy = 0; cy < num_h; ++cy) {
                ++cpos;
                squares[cpos].setPos(cpos);
            }
        lazy = 1;
    }
    SquareVertical(num_w, num_h, squares, frame,false);
}

void ac::Circular(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static double deg = 0.0;
    static double rad = 50;
    
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            int X_color = int(rad * cos(deg));
            int Y_color = int(rad * sin(deg));
            pixel[0] += static_cast<unsigned char>(pos*X_color);
            pixel[1] *= static_cast<unsigned char>(pos);
            pixel[2] += static_cast<unsigned char>(pos*Y_color);
            deg += 0.1;
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    rad += 0.5;
    if(rad > 100) rad = 50;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}


void ac::WhitePixel(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int pixel_count = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            if(pixel_count == 4) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                pixel[0] = pixel[1] = pixel[2] = 255;
                pixel_count = rand()%2;
            } else ++pixel_count;
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        pixel_count = rand()%2;
    }
}

void ac::FrameBlend(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static cv::Mat stored_frame;
    if((frame.rows != stored_frame.rows) || (frame.cols != stored_frame.cols)) {
        stored_frame = frame.clone();
    }
    cv::Mat start = frame.clone();
    // process frame
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b old_pixel = stored_frame.at<cv::Vec3b>(z, i);
            pixel[0] += static_cast<unsigned char>((old_pixel[0]^pixel[0])*pos);
            pixel[1] += static_cast<unsigned char>((old_pixel[1]&pixel[1])*pos);
            pixel[2] += static_cast<unsigned char>((old_pixel[2]|pixel[2])*pos);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    stored_frame = start;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::FrameBlendRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos = 1.0, pos_max = 7.0;
    static cv::Mat stored_frame;
    if((frame.rows != stored_frame.rows) || (frame.cols != stored_frame.cols)) {
        stored_frame = frame.clone();
    }
    cv::Mat start = frame.clone();
    static int swap = 0;
    // process frame
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b old_pixel = stored_frame.at<cv::Vec3b>(z, i);
            switch(swap) {
                case 0:
                    pixel[0] += static_cast<unsigned char>((old_pixel[0]^pixel[0])*pos);
                    pixel[1] += static_cast<unsigned char>((old_pixel[1]&pixel[1])*pos);
                    pixel[2] += static_cast<unsigned char>((old_pixel[2]|pixel[2])*pos);
                    break;
                case 1:
                    pixel[0] += static_cast<unsigned char>((old_pixel[0]&pixel[0])*pos);
                    pixel[1] += static_cast<unsigned char>((old_pixel[1]|pixel[1])*pos);
                    pixel[2] += static_cast<unsigned char>((old_pixel[2]^pixel[2])*pos);
                    break;
                case 2:
                    pixel[0] += static_cast<unsigned char>((old_pixel[0]|pixel[0])*pos);
                    pixel[1] += static_cast<unsigned char>((old_pixel[1]^pixel[1])*pos);
                    pixel[2] += static_cast<unsigned char>((old_pixel[2]&pixel[2])*pos);
                    break;
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    ++swap;
    if(swap > 2) swap = 0;
    stored_frame = start;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::TrailsFilterIntense(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Scalar s;
            cv::Vec3b frame_pixels[8];
            frame_pixels[0] = collection.frames[1].at<cv::Vec3b>(z, i);
            frame_pixels[1] = collection.frames[2].at<cv::Vec3b>(z, i);
            frame_pixels[2] = collection.frames[3].at<cv::Vec3b>(z, i);
            frame_pixels[3] = collection.frames[4].at<cv::Vec3b>(z, i);
            frame_pixels[4] = collection.frames[5].at<cv::Vec3b>(z, i);
            frame_pixels[5] = collection.frames[6].at<cv::Vec3b>(z, i);
            pixel[0] += (frame_pixels[0][0] + frame_pixels[1][0] + frame_pixels[2][0] + frame_pixels[3][0] + frame_pixels[4][0] + frame_pixels[5][0]);
            pixel[1] += (frame_pixels[0][1] + frame_pixels[1][1] + frame_pixels[2][1] + frame_pixels[3][1] + frame_pixels[4][1] + frame_pixels[5][1]);
            pixel[2] += (frame_pixels[0][2] + frame_pixels[1][2] + frame_pixels[2][2] + frame_pixels[3][2] + frame_pixels[4][2] + frame_pixels[5][2]);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
}

void ac::TrailsFilter(cv::Mat &frame) {
    static MatrixCollection<4> collection;
    collection.shiftFrames(frame);
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Scalar s;
            cv::Vec3b frame_pixels[4];
            frame_pixels[0] = collection.frames[1].at<cv::Vec3b>(z, i);
            frame_pixels[1] = collection.frames[2].at<cv::Vec3b>(z, i);
            frame_pixels[2] = collection.frames[3].at<cv::Vec3b>(z, i);
            pixel[0] += (frame_pixels[0][0] + frame_pixels[1][0] + frame_pixels[2][0]);
            pixel[1] += (frame_pixels[0][1] + frame_pixels[1][1] + frame_pixels[2][1]);
            pixel[2] += (frame_pixels[0][2] + frame_pixels[1][2] + frame_pixels[2][2]);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
}

void ac::TrailsFilterSelfAlpha(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    static double pos = 1.0, pos_max = 7.0;
    collection.shiftFrames(frame);
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Scalar s;
            cv::Vec3b frame_pixels[8];
            frame_pixels[0] = collection.frames[1].at<cv::Vec3b>(z, i);
            frame_pixels[1] = collection.frames[2].at<cv::Vec3b>(z, i);
            frame_pixels[2] = collection.frames[3].at<cv::Vec3b>(z, i);
            frame_pixels[3] = collection.frames[4].at<cv::Vec3b>(z, i);
            frame_pixels[4] = collection.frames[5].at<cv::Vec3b>(z, i);
            frame_pixels[5] = collection.frames[6].at<cv::Vec3b>(z, i);
            pixel[0] += (frame_pixels[0][0] + frame_pixels[1][0] + frame_pixels[2][0] + frame_pixels[3][0] + frame_pixels[4][0] + frame_pixels[5][0])*pos;
            pixel[1] += (frame_pixels[0][1] + frame_pixels[1][1] + frame_pixels[2][1] + frame_pixels[3][1] + frame_pixels[4][1] + frame_pixels[5][1])*pos;
            pixel[2] += (frame_pixels[0][2] + frame_pixels[1][2] + frame_pixels[2][2] + frame_pixels[3][2] + frame_pixels[4][2] + frame_pixels[5][2])*pos;
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::TrailsFilterXor(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    static double pos = 1.0, pos_max = 7.0;
    collection.shiftFrames(frame);
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Scalar s;
            cv::Vec3b frame_pixels[8];
            frame_pixels[0] = collection.frames[1].at<cv::Vec3b>(z, i);
            frame_pixels[1] = collection.frames[2].at<cv::Vec3b>(z, i);
            frame_pixels[2] = collection.frames[3].at<cv::Vec3b>(z, i);
            frame_pixels[3] = collection.frames[4].at<cv::Vec3b>(z, i);
            frame_pixels[4] = collection.frames[5].at<cv::Vec3b>(z, i);
            frame_pixels[5] = collection.frames[6].at<cv::Vec3b>(z, i);
            pixel[0] ^= (frame_pixels[0][0] + frame_pixels[1][0] + frame_pixels[2][0] + frame_pixels[3][0] + frame_pixels[4][0] + frame_pixels[5][0]);
            pixel[1] ^= (frame_pixels[0][1] + frame_pixels[1][1] + frame_pixels[2][1] + frame_pixels[3][1] + frame_pixels[4][1] + frame_pixels[5][1]);
            pixel[2] ^= (frame_pixels[0][2] + frame_pixels[1][2] + frame_pixels[2][2] + frame_pixels[3][2] + frame_pixels[4][2] + frame_pixels[5][2]);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::ColorTrails(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Scalar s;
            cv::Vec3b frame_pixels[8];
            frame_pixels[0] = collection.frames[1].at<cv::Vec3b>(z, i);
            frame_pixels[1] = collection.frames[2].at<cv::Vec3b>(z, i);
            frame_pixels[2] = collection.frames[3].at<cv::Vec3b>(z, i);
            frame_pixels[3] = collection.frames[4].at<cv::Vec3b>(z, i);
            frame_pixels[4] = collection.frames[5].at<cv::Vec3b>(z, i);
            frame_pixels[5] = collection.frames[6].at<cv::Vec3b>(z, i);
            for(int q = 0; q < 6; ++q) {
                if(frame_pixels[q][0] > pixel[0]) frame_pixels[q][0] = 0;
                if(frame_pixels[q][1] < pixel[1]) frame_pixels[q][1] = 0;
                if(frame_pixels[q][2] > pixel[2]) frame_pixels[q][2] = 0;
            }
            pixel[0] = (frame_pixels[0][0] + frame_pixels[1][0] + frame_pixels[2][0] + frame_pixels[3][0] + frame_pixels[4][0] + frame_pixels[5][0]);
            pixel[1] = (frame_pixels[0][1] + frame_pixels[1][1] + frame_pixels[2][1] + frame_pixels[3][1] + frame_pixels[4][1] + frame_pixels[5][1]);
            pixel[2] = (frame_pixels[0][2] + frame_pixels[1][2] + frame_pixels[2][2] + frame_pixels[3][2] + frame_pixels[4][2] + frame_pixels[5][2]);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
}

void ac::MoveRed(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double pos = 1.0, pos_max = 7.0;
    static unsigned int movement = 0;
    cv::Mat frame_copy = frame.clone();
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(i+movement < (w-1)) {
                cv::Vec3b add = frame_copy.at<cv::Vec3b>(z, (i+movement));
                pixel[2] += static_cast<unsigned char>((add[2]*pos));
            } else if((i-movement) > 1) {
                cv::Vec3b add = frame_copy.at<cv::Vec3b>(z, (i-movement));
                pixel[2] += static_cast<unsigned char>((add[2]*pos));
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    ++movement;
    if(movement > (w-1)) movement = 0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::MoveRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double pos = 1.0, pos_max = 7.0;
    static unsigned int rgb = 0;
    static unsigned int movement = 0;
    cv::Mat frame_copy = frame.clone();
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(i+movement < (w-1)) {
                cv::Vec3b add = frame_copy.at<cv::Vec3b>(z, (i+movement));
                pixel[rgb] += static_cast<unsigned char>((add[rgb]*pos));
            } else if((i-movement) > 1) {
                cv::Vec3b add = frame_copy.at<cv::Vec3b>(z, (i-movement));
                pixel[rgb] += static_cast<unsigned char>((add[rgb]*pos));
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    ++rgb;
    if(rgb > 2) rgb = 0;
    ++movement;
    if(movement > (w-1)) movement = 0;
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::MoveRedGreenBlue(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double pos = 1.0, pos_max = 7.0; // position in transition, maximum value
    static int movement[4] = {0, w, 0}; // movement variable array
    static int stored_w = w; // stored_w in case the frame size changes
    if(stored_w != w) {
        movement[1] = w-1; // set movement[1] to width
        stored_w = w; // stored_w set to new width
    }
    cv::Mat frame_copy = frame.clone(); // make a copy of the frame
    for(int z = 0; z < h; ++z) { // loop from top to bottom
        for(int i = 0; i < w; ++i) { // loop from left to right
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i); // reference to current pixel
            for(int q = 0; q <= 2; ++q) { // loop from 0 to 2
                unsigned int pos_x = i+movement[q];// pixel position
                unsigned int pos_y = i-movement[q];// pixel position
                if(pos_x < (w-1) && pos_x > 0) { // if within the screen
                    cv::Vec3b add = frame_copy.at<cv::Vec3b>(z, pos_x); // grab pixel
                    pixel[q] += static_cast<unsigned char>((add[q]*pos)); // add to current index multiplied by position
                } else if(pos_y > 0 && pos_y < (w-1)) {// if pos y within the screen
                    cv::Vec3b add = frame_copy.at<cv::Vec3b>(z, pos_y); // grab pixel
                    pixel[q] += static_cast<unsigned char>((add[q]*pos));// add to current index multiplied by position
                }
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    movement[0] += 4; // movement position increase by 4
    if(movement[0] > (w-1)) movement[0] = 0;
    movement[1] -= 4;// movement position decrease by 4
    if(movement[1] < 1) movement[1] = w-1; // set to width -1
    movement[2] += 8;// movement position increase by 8
    if(movement[2] > (w-1)) movement[2] = 0;// if greater than widthset to zero
    static int direction = 1;// direction of transition animation
    procPos(direction, pos, pos_max);// proc the position by increasing/decreasing
}

void ac::BlurSim(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double pos = 1.0, pos_max = 7.0;
    
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b pixels[2][2];
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            bool grabbed = true;
            for(int a = 0; a < 2; a++) {
                for(int b = 0; b < 2; b++) {
                    if((a+i) < (w-1) && (b+z) < (h-1)) {
                        pixels[a][b] = frame.at<cv::Vec3b>(z+b, i+a);
                    } else {
                        grabbed = false;
                        break;
                    }
                }
            }
            if(grabbed == false) continue;
            unsigned char rgb[3] = {0};
            for(int q = 0; q < 3; ++q)
                for(int a = 0; a < 2; ++a) {
                    for(int b = 0; b < 2; ++b) {
                        rgb[q] += pixels[a][b][q];
                    }
                }
            pixel[0] ^= static_cast<unsigned char>((rgb[0]/4)*pos);
            pixel[1] ^= static_cast<unsigned char>((rgb[1]/4)*pos);
            pixel[2] ^= static_cast<unsigned char>((rgb[2]/4)*pos);
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::Block(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static unsigned int square = 2;
    for(int z = 0; z < h; z += square) {
        for(int i = 0; i < w; i += square) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int x = 0; x < square; ++x) {
                for(int y = 0; y < square; ++y) {
                    if(y+z < h && i+x < w) {
                        cv::Vec3b &pix = frame.at<cv::Vec3b>(y+z, i+x);
                        pix = pixel;
                    }
                }
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    static int direction = 1;
    if(direction == 1) {
        square += 2;
        if(square >= 32) direction = 0;
    } else {
        square -= 2;
        if(square <= 2) direction = 1;
    }
}

void ac::BlockXor(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double pos = 1.0, pos_max = 3.0;
    static unsigned int square = 2;
    for(int z = 0; z < h; z += square) {
        for(int i = 0; i < w; i += square) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int x = 0; x < square; ++x) {
                for(int y = 0; y < square; ++y) {
                    if(y+z < h && i+x < w) {
                        cv::Vec3b &pix = frame.at<cv::Vec3b>(y+z, i+x);
                        pix[0] ^= static_cast<unsigned char>(pixel[0]*pos);
                        pix[1] ^= static_cast<unsigned char>(pixel[1]*pos);
                        pix[2] ^= static_cast<unsigned char>(pixel[2]*pos);
                        
                    }
                }
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
            
        }
    }
    static int direction = 1;
    if(direction == 1) {
        square += 2;
        if(square >= 8) direction = 0;
    } else {
        square -= 2;
        if(square <= 2) direction = 1;
    }
    static int posDirection = 1;
    procPos(posDirection, pos, pos_max);
}
// BlockScale
void ac::BlockScale(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double pos = 1.0, pos_max = 3.0;
    static unsigned int square = 2;
    for(int z = 0; z < h; z += square) { // loop from top to bottom
        for(int i = 0; i < w; i += square) { // loop from left to right
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);// grab pixel value
            for(int x = 0; x < square; ++x) {// draw square from left to right
                for(int y = 0; y < square; ++y) {// draw square form top to bottom
                    if(y+z < h && i+x < w) {// within bounds?
                        cv::Vec3b &pix = frame.at<cv::Vec3b>(y+z, i+x); // grab pixel
                        pix[0] = static_cast<unsigned char>(pixel[0]*pos); // calculate values
                        pix[1] = static_cast<unsigned char>(pixel[1]*pos);
                        pix[2] = static_cast<unsigned char>(pixel[2]*pos);
                    }
                }
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    // move in/out direction
    static int direction = 1;
    if(direction == 1) {
        square += 2;
        if(square >= 8) direction = 0;
    } else {
        square -= 2;
        if(square <= 2) direction = 1;
    }
    static int posDirection = 1;
    procPos(posDirection, pos, pos_max);
}

void ac::BlockStrobe(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static unsigned int square = 2;
    for(int z = 0; z < h; z += square) {
        for(int i = 0; i < w; i += square) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int x = 0; x < square; ++x) {
                for(int y = 0; y < square; ++y) {
                    if(y+z < h && i+x < w) {
                        cv::Vec3b &pix = frame.at<cv::Vec3b>(y+z, i+x);
                        pix[0] += static_cast<unsigned char>(pixel[0]*(x*y));
                        pix[1] += static_cast<unsigned char>(pixel[1]*(x*y));
                        pix[2] += static_cast<unsigned char>(pixel[2]*(x*y));
                    }
                }
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    static int direction = 1;
    if(direction == 1) {
        square += 2;
        if(square >= 8) direction = 0;
    } else {
        square -= 2;
        if(square <= 2) direction = 1;
    }
}

// Prev Frame Blend
// store previous frame and manipulate with current frame
void ac::PrevFrameBlend(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    double pos = 1.0;
    static unsigned int old_w = w;
    static cv::Mat stored = frame.clone(), temp;
    temp = frame.clone();
    if(old_w != w) {
        stored = frame.clone();
        old_w = w;
    }
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b old_pixel = stored.at<cv::Vec3b>(z, i);
            pixel[0] = static_cast<unsigned char>((pixel[0])+(1-old_pixel[0])*pos);
            pixel[1] = static_cast<unsigned char>((pixel[1])+(1-old_pixel[1])*pos);
            pixel[2] = static_cast<unsigned char>((pixel[2])+(1-old_pixel[2])*pos);
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    stored = temp;
    static int direction = 1;
    if(direction == 1) {
        pos += 0.1;
        if(pos > 7.0) direction = 0;
    } else {
        pos -= 0.1;
        if(pos <= 1.0) direction = 1;
    }
}

class WavePoints {
public:
    WavePoints() : x1(0), x2(0), x1_dir(0), x2_dir(0),c_dir(0),color(0) {}
    unsigned int x1,x2;
    unsigned int x1_dir, x2_dir, c_dir;
    double color;
};


void ac::Wave(cv::Mat &frame) {
    static unsigned int width = 0, height = 0;
    // uses lazy allocation when frame is resized pointer is reallocated.
    // last deallocation is done when program exits so no need to manually release
    static std::unique_ptr<WavePoints[]> points;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    const int slice = (h/16);
    
    if(width != w || height != h) {
        points.reset(new WavePoints[w]);
        width = w;
        height = h;
        
        for(int i = 0; i < w; ++i) {
            points[i].x1 = rand()%slice;
            points[i].x2 = h-rand()%slice;
            points[i].color = rand()%13;
            points[i].x1_dir = 0;
            points[i].x2_dir = 0;
            points[i].c_dir = 0;
        }
    }
    for(int z = 0; z <h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(z >= points[i].x1 && z <= points[i].x2) {
                pixel[0] += pixel[0]*points[i].color;
                pixel[1] += pixel[1]*points[i].color;
                pixel[2] += pixel[2]*points[i].color;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    for(int i = 0; i < w; ++i) {
        // color direction
        if(points[i].c_dir == 0) {
            points[i].color += 0.1;
            if(points[i].color >= 10) {
                points[i].c_dir = 1;
            }
        } else if(points[i].c_dir == 1) {
            points[i].color -= 0.1;
            if(points[i].color <= 1) {
                points[i].c_dir = 0;
            }
        }
        
        // x1 point direction/move down and up
        if(points[i].x1_dir == 0) {
            points[i].x1 ++;
            if(points[i].x1 > slice) {
                points[i].x1_dir = 1;
            }
        } else if(points[i].x1_dir == 1) {
            points[i].x1--;
            if(points[i].x1 < 1) {
                points[i].x1_dir = 0;
            }
        }
        
        // x2 point up/down
        if(points[i].x2_dir == 0) {
            points[i].x2--;
            if(points[i].x2 < (h-slice)) {
                points[i].x2_dir = 1;
            }
        } else if(points[i].x2_dir == 1) {
            points[i].x2++;
            if(points[i].x2 > (h-4)) {
                points[i].x2_dir = 0;
            }
        }
    }
}

void ac::HighWave(cv::Mat &frame) {
    static unsigned int width = 0, height = 0;
    static std::unique_ptr<WavePoints[]> points;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    const int slice = (h/8);
    
    if(width != w || height != h) {
        points.reset(new WavePoints[w]);
        width = w;
        height = h;
        
        for(int i = 0; i < w; ++i) {
            points[i].x1 = rand()%slice;
            points[i].x2 = h-rand()%slice;
            points[i].color = rand()%13;
            points[i].x1_dir = 0;
            points[i].x2_dir = 0;
            points[i].c_dir = 0;
        }
    }
    for(int z = 0; z <h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] -= pixel[0]*points[i].color;
            pixel[1] += pixel[1]*points[i].color;
            pixel[2] -= pixel[2]*points[i].color;
            swapColors(frame, z, i);// swap colors for rgb slides
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    for(int i = 0; i < w; ++i) {
        // color direction
        if(points[i].c_dir == 0) {
            points[i].color += 0.25;
            if(points[i].color >= 10) {
                points[i].c_dir = 1;
            }
        } else if(points[i].c_dir == 1) {
            points[i].color -= 0.25;
            if(points[i].color <= 1) {
                points[i].c_dir = 0;
            }
        }
    }
}

void ac::VerticalSort(cv::Mat &frame) {
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static std::vector<unsigned int> v;// static vector of unsigned int
    v.reserve(w);// reserve w bytes
    for(int i = 0; i < w; ++i) { // top to bottom
        for(int z = 0; z < h; ++z) { // left to right
            //unsigned int value = frame.at<unsigned int>(z, i);
            // grab pixel reference
            
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
            
            cv::Vec3b &value = frame.at<cv::Vec3b>(z, i);
            unsigned int vv = 0;
            // unsigned char * of vv
            unsigned char *cv = (unsigned char*)&vv;
            // set RGB values
            cv[0] = value[0];
            cv[1] = value[1];
            cv[2] = value[2];
            cv[3] = 0;
            // push back into vector v
            v.push_back(vv);
        }
        // sort vector v
        std::sort(v.begin(), v.end());
        for(int q = 0; q < h; ++q) {// left to right
            // unsigned char pointer of vector v at index i
            unsigned char *value = (unsigned char*)&v[q];
            // get pixel reference
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(q, i);
            // add to pixel without scaling
            pixel[0] = value[0];
            pixel[1] = value[1];
            pixel[2] = value[2];
            
        }
        v.erase(v.begin(), v.end());
    }
}

void ac::VerticalChannelSort(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    std::vector<unsigned char> pixels[3];
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
            
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j)
                pixels[j].push_back(pixel[j]);
        }
        
        for(int j = 0; j < 3; ++j)
            std::sort(pixels[j].begin(), pixels[j].end());
        
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] = pixels[0][z];
            pixel[1] = pixels[1][z];
            pixel[2] = pixels[2][z];
        }
        for(int j = 0; j < 3; ++j)
            if(!pixels[j].empty())
                pixels[j].erase(pixels[j].begin(), pixels[j].end());
    }
    
}

void ac::HorizontalBlend(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double alpha[3] = {1,8,16};
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] = static_cast<unsigned char>(pixel[0] * alpha[0]);
            pixel[1] = static_cast<unsigned char>(pixel[1] * alpha[1]);
            pixel[2] = static_cast<unsigned char>(pixel[2] * alpha[2]);
            
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
        if((rand()%4)==0) {
            for(int i = 0; i < 3; ++i) {
                alpha[i] += 0.1;
                if(alpha[i] > 25) alpha[i] = 1;
            }
        }
    }
}

void ac::VerticalBlend(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double alpha[3] = {1,8,16};
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] = static_cast<unsigned char>(pixel[0] * alpha[0]);
            pixel[1] = static_cast<unsigned char>(pixel[1] * alpha[1]);
            pixel[2] = static_cast<unsigned char>(pixel[2] * alpha[2]);
            
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
        if((rand()%4)==0) {
            for(int i = 0; i < 3; ++i) {
                alpha[i] += 0.1;
                if(alpha[i] > 25) alpha[i] = 1;
            }
        }
    }
}

void ac::OppositeBlend(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    cv::Mat temp = frame.clone();
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w-1; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b temp_pixel = temp.at<cv::Vec3b>(z, w-i-1);
            pixel[0] = static_cast<unsigned char>((pixel[0]+temp_pixel[0]));
            pixel[1] = static_cast<unsigned char>((pixel[1]+temp_pixel[1]));
            pixel[2] = static_cast<unsigned char>((pixel[2]+temp_pixel[2]));
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
}

void ac::DiagonalLines(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    cv::Mat temp = frame.clone();
    static double pos = 1.0;
    
    for(int i = 0; i < w-1; ++i) {
        for(int z = 0; z < h-1; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b temp_pixel = temp.at<cv::Vec3b>(h-z-1, i);
            for(int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>((pixel[j]+temp_pixel[j])+pos);
                ++pos;
                if(pos > 100) pos = 0;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
}

void ac::HorizontalLines(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static double pos[3] = {1.0, 16.0, 32.0};
    
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>(pixel[j] + pos[j]);
                pos[j] += 0.1;
                if(pos[j] > 100)
                    pos[j] = 0;
                
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
}

void ac::InvertedScanlines(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    
    static unsigned int index = 0;
    static double alpha = 1.0;
    static double pos_max = 14.0;
    
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0: {
                    for(int j = 0; j < 3; ++j)
                        pixel[j] = static_cast<unsigned char>((~pixel[j])*alpha);
                    index++;
                }
                case 1: {
                    cv::Vec3b temp = pixel;
                    pixel[0] = static_cast<unsigned char>(temp[2]*alpha);
                    pixel[1] = static_cast<unsigned char>(temp[1]*alpha);
                    pixel[2] = static_cast<unsigned char>(temp[0]*alpha);
                    index++;
                }
                    break;
                case 2:
                    index = 0;
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    
    static int direction = 1;
    procPos(direction, alpha, pos_max);
}

void ac::Soft_Mirror(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int index = 0;
    cv::Mat temp = frame.clone();
    for(int z = 1; z < h-1; ++z) {
        for(int i = 1; i < w-1; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0:
                    index++;
                    break;
                case 1: {
                    cv::Vec3b pix = frame.at<cv::Vec3b>(h-z-1, w-i-1);
                    pixel[0] = pix[0];
                    pixel[1] = pix[1];
                    pixel[2] = pix[2];
                    index = 0;
                }
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
}

void ac::KanapaTrip(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int start_index = 0;
    unsigned int index = start_index;
    cv::Mat temp = frame.clone();
    for(int z = 1; z < h-1; ++z) {
        for(int i = 1; i < w-1; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0:
                    index++;
                    break;
                case 1: {
                    cv::Vec3b pix = frame.at<cv::Vec3b>(h-z-1, w-i-1);
                    pixel[0] = pix[0];
                    pixel[1] = pix[1];
                    pixel[2] = pix[2];
                    index = 0;
                }
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    if(start_index == 0)
        start_index = 1;
    else
        start_index = 0;
}

void ac::ColorMorphing(cv::Mat &frame) {
    KanapaTrip(frame);
    SidewaysMirror(frame);
}


void ac::ScanSwitch(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int start_index = 0;
    unsigned int index = start_index;
    for(int z = 3; z < h-3; ++z) {
        for(int i = 3; i < w-3; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0:
                    index++;
                    break;
                case 1: {
                    pixel[0] = ~pixel[0];
                    pixel[1] = ~pixel[1];
                    pixel[2] = ~pixel[2];
                    index = 0;
                }
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    if(start_index == 0)
        start_index = 1;
    else
        start_index = 0;
}


void ac::ScanAlphaSwitch(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int start_index = 0;
    static double alpha = 1.0, alpha_max = 10.0;
    unsigned int index = start_index;
    for(int z = 3; z < h-3; ++z) {
        for(int i = 3; i < w-3; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0:
                    index++;
                    pixel[0] = ~pixel[0];
                    pixel[1] = ~pixel[1];
                    pixel[2] = ~pixel[2];
                    break;
                case 1: {
                    pixel[0] += static_cast<unsigned char>(pixel[0]*alpha);
                    pixel[1] += static_cast<unsigned char>(pixel[1]*alpha);
                    pixel[2] += static_cast<unsigned char>(pixel[2]*alpha);
                    index = 0;
                }
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    if(start_index == 0)
        start_index = 1;
    else
        start_index = 0;
    
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::NegativeStrobe(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame height
    static unsigned int flash = 1;
    if(flash == 1) {
        for(int z = 0; z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                pixel[0] = ~pixel[0];
                pixel[1] = ~pixel[1];
                pixel[2] = ~pixel[2];
            }
        }
    }
    if(flash == 1) {
        flash = 0;
    } else {
        flash = 1;
    }
}

void ac::XorAddMul(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static double blend = 1.0, blend_max = 13.0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            unsigned int b = static_cast<unsigned int>(blend);
            pixel[0] += static_cast<unsigned char>(pixel[0]^b);
            pixel[1] += static_cast<unsigned char>(pixel[1]+b);
            pixel[2] += static_cast<unsigned char>(pixel[2]*b);
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    static int direction = 1;
    procPos(direction, blend, blend_max);
    //if(blend > 255) blend = 1.0;
}

// initalize to null
ac::ParticleEmiter::ParticleEmiter() : part(0), w(0), h(0) {}

// clean up after done
ac::ParticleEmiter::~ParticleEmiter() {
    if(part != 0) {
        for(int i = 0; i < w; ++i)
            delete [] part[i];
        delete [] part;
        part = 0;
    }
}

void ac::ParticleEmiter::reset() {
    w = 0;
    h = 0;
}

// set frame pixel values
void ac::ParticleEmiter::set(cv::Mat &frame) {
    if(static_cast<unsigned int>(frame.cols) != w || static_cast<unsigned int>(frame.rows) != h) {
        if(part != 0) {
            for(int i = 0; i < w; ++i)
                delete [] part[i];
            delete [] part;
        }
        w = frame.cols;
        h = frame.rows;
        part = new Particle*[w];
        for(int i = 0; i < w; ++i) {
            part[i] = new Particle[h];
            for(int z = 0; z < h; ++z) {
                part[i][z].x = i;
                part[i][z].y = z;
                part[i][z].dir = rand()%4;
            }
        }
    }
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b pixel = frame.at<cv::Vec3b>(z, i);
            part[i][z].pixel = pixel;
        }
    }
}
// draw pixel values to frame
void ac::ParticleEmiter::draw(cv::Mat &frame) {
    movePixels();//move values before drawing
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            int x_pos = part[i][z].x;
            int y_pos = part[i][z].y;
            if(x_pos > 0 && x_pos < frame.cols && y_pos > 0 && y_pos < frame.rows) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(y_pos, x_pos);
                pixel = part[i][z].pixel;
            }
        }
    }
}
// move pixel coordinates around
void ac::ParticleEmiter::movePixels() {
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            Particle &p = part[i][z];
            p.m_count ++;
            if(p.m_count > 250) {
                p.m_count = 0;
                p.dir = rand()%4;
                continue;
            }
            switch(p.dir) {
                case DIR_UP:
                    if(p.y > 0) {
                        p.y--;
                    } else {
                        p.y = 1+rand()%(h-1);
                        p.dir = rand()%4;
                    }
                    break;
                case DIR_DOWN:
                    if(p.y < h-1) {
                        p.y++;
                    } else {
                        p.dir = rand()%4;
                        p.y = 1+rand()%(h-1);
                    }
                    break;
                case DIR_LEFT:
                    if(p.x > 0) {
                        p.x--;
                    } else {
                        p.dir = rand()%4;
                        p.x = 1+rand()%(w-1);
                    }
                    break;
                case DIR_RIGHT:
                    if(p.x < w-1) {
                        p.x++;
                    } else {
                        p.dir = rand()%4;
                        p.x = rand()%(w-1);
                    }
                    break;
                default:
                    p.dir = rand()%4;
            }
        }
    }
}

ac::ParticleEmiter emiter; // initialize

// Particle Filter
void ac::ParticleRelease(cv::Mat &frame) {
    emiter.set(frame);// set values each frame
    emiter.draw(frame); // draw values each frame
}

void ac::BlendSwitch(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static unsigned int pos = 0;
    static unsigned char blend_pixel = 0;
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[pos] *= blend_pixel++;
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
        pos++;
        if(pos > 2) pos = 0;
    }
}

// set all color components other than red to zero
void ac::AllRed(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] = pixel[1] = 0;
        }
    }
}
// set all color components other than green to zero
void ac::AllGreen(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] = pixel[2] = 0;
        }
    }
}
// set all color components other than blue to zero
void ac::AllBlue(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[2] = pixel[1] = 0;
        }
    }
}
// set colors to zero based on counter
// increment counter after each nested loop
void ac::LineRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static unsigned int counter = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(counter) {
                case 0:
                    pixel[0] = pixel[1] = 0;
                    break;
                case 1:
                    pixel[0] = pixel[2] = 0;
                    break;
                case 2:
                    pixel[2] = pixel[1] = 0;
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
        ++counter;
        if(counter > 2) counter = 0;
    }
}
// set colors to zero based on counter
// increment counter each iteration of nested loop
void ac::PixelRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static unsigned int counter = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(counter) {
                case 0:
                    pixel[0] = pixel[1] = 0;
                    break;
                case 1:
                    pixel[0] = pixel[2] = 0;
                    break;
                case 2:
                    pixel[2] = pixel[1] = 0;
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
            ++counter;
            if(counter > 2) counter = 0;
        }
    }
}

// Boxed RGB
void ac::BoxedRGB(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static int row_counter = 0; // row counter
    
    for(int z = 0; z < h; ++z) { // from top to bottom
        for(int i = 0; i < w; ++i) { // from left to right
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i); // pixel
            switch(row_counter) {// row counter iterate between red,green,and blue
                case 0:
                    pixel[0] = pixel[1] = 0; // red
                    break;
                case 1:
                    pixel[0] = pixel[2] = 0; // green
                    break;
                case 2:
                    pixel[2] = pixel[1] = 0; // blue
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
        // if z is evenly divideable by 32
        if((z%32) == 0) {
            ++row_counter;// increment row counter
            if(row_counter > 3) row_counter = 0;
        }
    }
}

// joke filter
// color the image with red/green bars switching color each frame
void ac::KruegerSweater(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static int row_counter = 0;// row counter
    static unsigned int rg = 0;// row counter start variable
    row_counter = rg; // set row counter to start
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // set the colors other than red or green to zero based on row counter
            switch(row_counter) {
                case 0:
                    pixel[0] = pixel[1] = 0; // red
                    break;
                case 1:
                    pixel[0] = pixel[2] = 0; // green
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
        if((z%32) == 0) {
            ++row_counter; // increment row counter
            if(row_counter >= 2) { // if greater than or equal 2
                row_counter = 0; // set to row_counter to zero
            }
        }
    }
    rg = (rg == 0) ? 1 : 0; // swap back and forth rg between zero and one.
}

void ac::RGBFlash(cv::Mat &frame) {
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    static unsigned int counter = 0; // counter for setting the pixel
    static unsigned int start = 0; // start position
    for(int z = start; z < h; z += 2) { // top to bottom, skipping 1 each time
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            // set pixel a certain color based on the counter
            switch(counter) {
                case 0:
                    pixel[2] = 255;// set red
                    break;
                case 1:
                    pixel[1] = 255; // set green
                    break;
                case 2:
                    pixel[0] = 255;// set blue
                    break;
            }
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    ++counter;// increment counter
    if(counter > 2) counter = 0; // if greater than 2 reset to zero
    start = (start == 0) ? 1 : 0; // swap start back and forth between 0 and 1
}

void ac::IncreaseBlendHorizontal(cv::Mat &frame) {
    ac::orig_frame = frame.clone();
    const int w = frame.cols;
    const int h = frame.rows;
    for(int i = 0; i < w; ++i) {
        cv::Vec3b pix;
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pix[0] += pixel[0]/2;
            pix[1] += pixel[1]/4;
            pix[2] += pixel[2]/6;
            pixel[0] += pixel[0] * (pix[0]/32);
            pixel[1] += pixel[1] * (pix[1]/32);
            pixel[2] += pixel[2] * (pix[2]/32);
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    ac::pass2_alpha = 0.75;
    Pass2Blend(frame);
}
// blend increase
void ac::BlendIncrease(cv::Mat &frame) {
    static int blend_r = rand()%255, blend_g = rand()%255, blend_b = rand()%255;
    static bool cblend_r = true, cblend_g = true, cblend_b = true;
    static unsigned int increase_value_r = 2, increase_value_g = 2, increase_value_b = 2;
    const int w = frame.cols;
    const int h = frame.rows;
    if(blend_r > 255) {
        blend_r = rand()%255;
        if(cblend_r == true) {
            blend_r = -blend_r;
            cblend_r = false;
        } else {
            cblend_r = true;
        }
    }
    if(blend_g > 255) {
        blend_g = rand()%255;
        if(cblend_g == true) {
            blend_g = -blend_g;
            cblend_g = false;
        } else {
            cblend_g = true;
        }
    }
    if(blend_b > 255) {
        blend_b = rand()%255;
        if(cblend_b == true) {
            blend_b = -blend_b;
            cblend_b = false;
        } else {
            cblend_b = true;
        }
    }
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[2] += static_cast<unsigned char>(blend_r);
            pixel[1] += static_cast<unsigned char>(blend_g);
            pixel[0] += static_cast<unsigned char>(blend_b);
            swapColors(frame, z, i);// swap colors for rgb sliders
            if(isNegative) invert(frame, z, i); // if is negative
        }
    }
    blend_r += increase_value_r;
    blend_g += increase_value_g;
    blend_b += increase_value_b;
    increase_value_r += rand()%5;
    increase_value_g += rand()%5;
    increase_value_b += rand()%5;
    if(increase_value_r > 20) {
        increase_value_r = 2;
    }
    if(increase_value_g  > 20) {
        increase_value_g = 2;
    }
    if(increase_value_b > 20) {
        increase_value_b = 2;
    }
}

void ac::GradientReverse(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static bool direction = true;
    static double alpha = 1.0, alpha_max = 8;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                if(direction == true)
                    pixel[j] += static_cast<unsigned char>(i*alpha);
                else
                    pixel[j] -= static_cast<unsigned char>(i*alpha);
            }
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
        }
        direction = (direction == true) ? false : true;
    }
    static int direction_ = 1;
    procPos(direction_, alpha, alpha_max);
}

void ac::GradientReverseBox(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static bool direction = true;
    static double alpha = 1.0, alpha_max = 8;
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                if(direction == true)
                    pixel[j] += static_cast<unsigned char>((i*alpha));
                else
                    pixel[j] -= static_cast<unsigned char>((z*alpha));
            }
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
        }
        direction = (direction == true) ? false : true;
    }
    static int direction_ = 1;
    procPos(direction_, alpha, alpha_max);
}

void ac::GradientReverseVertical(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static bool direction = true;
    static double alpha = 1.0, alpha_max = 8;
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                if(direction == true)
                    pixel[j] += static_cast<unsigned char>((z*alpha));
                else
                    pixel[j] -= static_cast<unsigned char>((z*alpha));
            }
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
        }
        direction = (direction == true) ? false : true;
    }
    static int direction_ = 1;
    procPos(direction_, alpha, alpha_max);
}

void ac::GradientNewFilter(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static unsigned int index = 0;
    static double alpha = 1.0, alpha_max = 9;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                switch(index) {
                    case 0:
                        pixel[j] = static_cast<unsigned char>((pixel[j] ^ (unsigned int)(alpha*z)));
                        break;
                    case 1:
                        pixel[j] = static_cast<unsigned char>((pixel[j] & (unsigned int)(alpha*i)));
                        break;
                    case 2:
                        pixel[j] = static_cast<unsigned char>((pixel[j] ^ (unsigned int)alpha));
                        break;
                }
            }
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
            ++index;
            if(index > 2) index = 0;
        }
    }
    static int direction_ = 1;
    procPos(direction_, alpha, alpha_max);
}

void ac::ReinterpretDouble(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static double alpha = 1.0, alpha_max = 8;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            unsigned char *value = reinterpret_cast<unsigned char*>(&alpha);
            for(int j = 0; j < 3; ++j)
                pixel[j] = cv::saturate_cast<uchar>(pixel[j] ^ value[j]);
            
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
        }
    }
    static int direction_ = 1;
    procPos(direction_, alpha, alpha_max);
}


void ac::ReinterpSelfScale(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static unsigned int index = 0;
    static double alpha = 1.0, alpha_max = 8;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            unsigned char *value = reinterpret_cast<unsigned char*>(&alpha);
            switch(index) {
                case 0: {
                    pixel[0] = static_cast<unsigned char>(pixel[0]*alpha)^value[0];
                    pixel[1] = static_cast<unsigned char>(pixel[1]*alpha);
                    pixel[2] = static_cast<unsigned char>(pixel[2]*alpha);
                }
                    break;
                case 1: {
                    pixel[0] = static_cast<unsigned char>(pixel[0]*alpha);
                    pixel[1] = static_cast<unsigned char>(pixel[0]*alpha)^value[1];
                    pixel[2] = static_cast<unsigned char>(pixel[2]*alpha);
                }
                    break;
                case 2: {
                    pixel[0] = static_cast<unsigned char>(pixel[0]*alpha);
                    pixel[1] = static_cast<unsigned char>(pixel[1]*alpha);
                    pixel[2] = static_cast<unsigned char>(pixel[2]*alpha)^value[2];
                }
                    break;
            }
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
        }
        ++index;
        if(index > 2) index = 0;
    }
    static int direction_ = 1;
    procPos(direction_, alpha, alpha_max);
}

void ac::AverageLines(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    unsigned char average[3];
    static double alpha = 1.0, alpha_max = 11;
    for(int z = 0; z < h; ++z) {
        cv::Scalar s(1,1,1);
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            s[0] += pixel[0];
            s[1] += pixel[1];
            s[2] += pixel[2];
            pixel[0] = static_cast<unsigned char>((pixel[0]^average[0])*alpha);
            pixel[1] = static_cast<unsigned char>((pixel[1]^average[1])*alpha);
            pixel[2] = static_cast<unsigned char>((pixel[2]^average[2])*alpha);
            ac::swapColors(frame, z, i);
            if(isNegative) ac::invert(frame, z, i);
        }
        average[0] = cv::saturate_cast<unsigned char>((s[0]/w));
        average[1] = cv::saturate_cast<unsigned char>((s[1]/w));
        average[2] = cv::saturate_cast<unsigned char>((s[2]/w));
    }
    int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::ImageFile(cv::Mat &frame) {
    if(blend_set == true) {
        const int w = frame.cols;
        const int h = frame.rows;
        for(int z = 0;  z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b add_i = blend_image.at<cv::Vec3b>(cY, cX);
                pixel[0] += add_i[0];
                pixel[1] += add_i[1];
                pixel[1] += add_i[2];
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i); // invert pixel
            }
        }
    }
    
}
void ac::ImageXor(cv::Mat &frame) {
    if(blend_set == true) {
        const int w = frame.cols;
        const int h = frame.rows;
        static double alpha = 1.0, alpha_max = 4.0;
        for(int z = 0;  z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b add_i = blend_image.at<cv::Vec3b>(cY, cX);
                for(int j = 0; j < 3; ++j)
                    pixel[j] = cv::saturate_cast<unsigned char>(pixel[j]^add_i[j])*alpha;
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i); // invert pixel
            }
        }
        static int direction = 1;
        procPos(direction, alpha, alpha_max);
    }
}

void ac::ImageAlphaBlend(cv::Mat &frame) {
    if(blend_set == true) {
        const int w = frame.cols;
        const int h = frame.rows;
        static double alpha = 1.0, alpha_max = 2.0;
        for(int z = 0;  z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b add_i = blend_image.at<cv::Vec3b>(cY, cX);
                for(int j = 0; j < 3; ++j)
                    pixel[j] = static_cast<unsigned char>((pixel[j]*alpha) + (add_i[j] * alpha));
                
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i); // invert pixel
            }
        }
        static int direction = 1;
        procPos(direction, alpha, alpha_max);
    }
}


void ac::ColorRange(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static double alpha = 1.0, alpha_max = 6;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j)
                pixel[j] = static_cast<unsigned char>((pixel[j]+colors[j])*alpha);
        }
    }
    static unsigned int direction[3] = {1, 0, 1};
    for(int j = 0; j < 3; ++j) {
        if(direction[j] == 1) {
            colors[j] ++;
            if(colors[j] >= 255) {
                direction[j] = 0;
                colors[j] = 255;
            }
        } else if(direction[j] == 0) {
            colors[j] --;
            if(colors[j] <= 0) {
                direction[j] = 1;
                colors[j] = 0;
            }
        }
    }
    
    static int _direction = 1;
    procPos(_direction, alpha, alpha_max);
}

void ac::ImageInter(cv::Mat &frame) {
    if(blend_set == true) {
        static int start = 0, restart = 0;
        const int w = frame.cols;
        const int h = frame.rows;
        for(int z = 0;  z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b add_i = blend_image.at<cv::Vec3b>(cY, cX);
                if(start == 0) {
                    pixel = add_i;
                }
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i); // invert pixel
            }
            start = (start == 0) ? 1 : 0;
        }
        if(restart == 0) {
            start = 1;
            restart = 1;
        } else {
            start = 0;
            restart = 0;
        }
    }
}

void ac::TrailsInter(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    static int counter = 0;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel = collection.frames[counter+1].at<cv::Vec3b>(z, i);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++counter;
        if(counter > 6) counter = 0;
    }
}

void ac::TrailsBlend(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    cv::Mat new_frame = frame.clone();
    ac::SelfAlphaBlend(new_frame);
    collection.shiftFrames(new_frame);
    static int counter = 0;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel = collection.frames[counter+1].at<cv::Vec3b>(z, i);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++counter;
        if(counter > 6) counter = 0;
    }
}

void ac::TrailsNegate(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    static unsigned int index = 0;
    cv::Mat new_frame = frame.clone();
    if(index == 0) {
        ac::Negate(new_frame);
        index = 1;
    } else {
        index = 0;
    }
    collection.shiftFrames(new_frame);
    static int counter = 0;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int z = 0; z < h-1; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel = collection.frames[counter+1].at<cv::Vec3b>(z, i);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++counter;
        if(counter > 6) counter = 0;
    }
}

void ac::InterReverse(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    bool get_value = true;
    static bool value_start = true;
    get_value = value_start;
    cv::Mat frame_copy = frame.clone();
    for(int z = 2; z < h-2; ++z) {
        for(int i = 2; i < w-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(get_value == true) {
                cv::Vec3b value;
                value = frame_copy.at<cv::Vec3b>(h-z-1, i);
                pixel = value;
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        get_value = (get_value == true) ? false : true;
    }
    value_start = (value_start == true) ? false : true;
}

void ac::InterMirror(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    bool get_value = true;
    static bool value_start = true;
    get_value = value_start;
    cv::Mat frame_copy = frame.clone();
    for(int z = 2; z < h-2; ++z) {
        for(int i = 2; i < w-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(get_value == true) {
                cv::Vec3b value;
                value = frame_copy.at<cv::Vec3b>(h-z-1, i);
                cv::Vec3b value2;
                value2 = frame_copy.at<cv::Vec3b>(z, w-i-1);
                cv::Vec3b value3;
                value3 = frame_copy.at<cv::Vec3b>(h-z-1, w-i-1);
                pixel[0] = static_cast<unsigned char>(value[0]+value2[0]+value3[0]);
                pixel[1] = static_cast<unsigned char>(value[1]+value2[1]+value3[1]);
                pixel[2] = static_cast<unsigned char>(value[2]+value2[2]+value3[2]);
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        get_value = (get_value == true) ? false : true;
    }
    value_start = (value_start == true) ? false : true;
}

void ac::InterFullMirror(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    unsigned int index = 0;
    cv::Mat frame_copy = frame.clone();
    for(int z = 2; z < h-2; ++z) {
        for(int i = 2; i < w-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0:
                    continue;
                case 1:
                    pixel = frame_copy.at<cv::Vec3b>(h-z-1, i);
                    break;
                case 2:
                    pixel = frame_copy.at<cv::Vec3b>(z, w-i-1);
                    break;
                case 3:
                    pixel = frame_copy.at<cv::Vec3b>(h-z-1, w-i-1);
                    break;
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++index;
        if(index > 3) index = 0;
    }
}

void ac::MirrorRGB(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    cv::Mat frame_copy = frame.clone();
    for(int z = 2; z < h-2; ++z) {
        for(int i = 2; i < w-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b frame_pixels[4] = {frame_copy.at<cv::Vec3b>(h-z-1, i), frame_copy.at<cv::Vec3b>(z, w-i-1), frame_copy.at<cv::Vec3b>(h-z-1, w-i-1)};
            for(int j = 0; j < 3; ++j) {
                pixel[j] += static_cast<unsigned char>(frame_pixels[j][j]);
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
}

void ac::RGBStatic1(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static double pos = 0.25;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b add(rand()%255, rand()%255, rand()%255);
            for(int j = 0; j < 3; ++j)
                pixel[j] += static_cast<unsigned char>(add[j] * pos);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    static double direction_max = 0.4;
    if(direction == 1) {
        pos += 0.005;
        if(pos > direction_max) {
            direction = 0;
            direction_max += 0.05;
            if(direction_max >= 0.8) {
                direction_max = 0.5;
            }
        }
    } else if(direction == 0) {
        pos -= 0.005;
        if(pos <= 0.25)
            direction = 1;
    }
}

void ac::RGBStatic2(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static double pos = 0.05;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b add(rand()%255, rand()%255, rand()%255);
            for(int j = 0; j < 3; ++j)
                pixel[j] += static_cast<unsigned char>(add[j] * pos);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    static int direction = 1;
    static double direction_max = 0.4;
    if(direction == 1) {
        pos += 0.005;
        if(pos > direction_max) {
            direction = 0;
            direction_max += 0.05;
            if(direction_max >= 0.9) {
                direction_max = 0.4;
            }
        }
    } else if(direction == 0) {
        pos -= 0.05;
        if(pos <= 0.05)
            direction = 1;
    }
    
}

void ac::VectorIncrease(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    static double pos = 0.25;
    static cv::Vec3b value(rand()%255, rand()%255, rand()%255);
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j)
                pixel[j] = static_cast<unsigned char>((pixel[j]*value[j]) * pos);
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    for(int j = 0; j < 3; ++j)
        value[j] += rand()%8;
}

void ac::LineByLineReverse(cv::Mat &frame) {
    const int w = frame.cols;
    const int h = frame.rows;
    bool rev = false;
    cv::Mat frame_copy = frame.clone();
    for(int z = 0; z < h; ++z) {
        for(int i = 2; i < w-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(rev == true)
                break;
            else
                pixel = frame_copy.at<cv::Vec3b>(z, (w-i-1));
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        rev = (rev == true) ? false : true;
    }
}

void ac::RandomIntertwine(cv::Mat &frame) {
    cv::Mat frame1 = frame.clone(), frame2 = frame.clone();
    randomFilter(frame1);
    randomFilter(frame2);
    const int w = frame.cols;
    const int h = frame.rows;
    bool rev = false;
    for(int z = 0; z < h; ++z) {
        for(int i = 2; i < w-2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(rev == true)
                pixel = frame1.at<cv::Vec3b>(z, i);
            else
                pixel = frame2.at<cv::Vec3b>(z, (w-i-1));
            
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        rev = (rev == true) ? false : true;
    }
}

void ac::RandomFour(cv::Mat &frame) {
    cv::Mat frames[4];
    frames[0] = frame;
    for(int j = 1; j < 4; ++j) {
        frames[j] = frame.clone();
        randomFilter(frames[j]);
    }
    const int w = frame.cols, h = frame.rows;
    static unsigned int row = 0;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(row == 0) break;
            else {
                pixel = frames[row].at<cv::Vec3b>(z, i);
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++row;
        if(row > 3) row = 0;
    }
}

void ac::BlendThree(cv::Mat &frame) {
    static double pos = 1.0, pos_max = 8.0;
    cv::Mat frames[3];
    frames[0] = frame;
    for(int j = 1; j < 3; ++j) {
        frames[j] = frame.clone();
        randomFilter(frames[j]);
    }
    const int w = frame.cols, h = frame.rows;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b values[4];
            for(int j = 0; j < 3; ++j)
                values[j] = frames[j].at<cv::Vec3b>(z, i);
            
            pixel[0] = values[0][0] + values[1][0] + values[2][0];
            pixel[1] = values[0][1] + values[1][1] + values[2][1];
            pixel[2] = values[0][2] + values[1][2] + values[2][2];
            
            for(int j = 0; j < 3; ++j) {
                pixel[j] /= 3;
                pixel[j] *= static_cast<unsigned char>(pos);
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
    
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::AcidTrails(cv::Mat &frame) {
    const int w = frame.cols, h = frame.rows;
    cv::Mat frame_copies[3];
    
    for(int j = 0; j < 3; ++j)
        frame_copies[j] = frame.clone();
    
    ac::SelfScale(frame_copies[0]);
    ac::TrailsInter(frame_copies[0]);
    ac::Type(frame_copies[1]);
    ac::Outward(frame_copies[2]);
    
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b copy1 = frame_copies[0].at<cv::Vec3b>(z, i);
            cv::Vec3b copy2 = frame_copies[1].at<cv::Vec3b>(z, i);
            cv::Vec3b copy3 = frame_copies[2].at<cv::Vec3b>(z, i);
            cv::Vec3b value;
            for(int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>(((copy1[j] ^ copy2[j]) + copy3[j]));
            }
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
    }
}

void ac::RandomTwo(cv::Mat &frame) {
    cv::Mat frames[2];
    frames[0] = frame.clone();
    frames[1] = frame.clone();
    randomFilter(frames[0]);
    randomFilter(frames[1]);
    static unsigned int index = 0;
    unsigned int w = frame.cols, h = frame.rows;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel = frames[index].at<cv::Vec3b>(z, i);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++index;
        if(index > 1) index = 0;
    }
}

void ac::HorizontalTrailsInter(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    static int counter = 0;
    const int w = frame.cols;// frame width
    const int h = frame.rows;// frame heigh
    for(int i = 0; i < w; ++i) {
        for(int z = 0; z < h; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel = collection.frames[counter+1].at<cv::Vec3b>(z, i);
            swapColors(frame, z, i);
            if(isNegative) invert(frame, z, i);
        }
        ++counter;
        if(counter > 6) counter = 0;
    }
}

void ac::Trails(cv::Mat &frame) {
    TrailsInter(frame);
    HorizontalTrailsInter(frame);
}

void ac::BlendTrails(cv::Mat &frame) {
    Negate(frame);
    rainbowBlend(frame);
    Trails(frame);
}

unsigned int ac::Box::frame_width = 0;
unsigned int ac::Box::frame_height = 0;

void ac::Box::initBox(int width, int height) {
    x = (rand()%width);
    y = (rand()%height);
    w = rand()%25;
    h = rand()%25;
    steps = rand()%10;
    index = 0;
    do {
        frame_index = rand()%28;
    } while(frame_index == 13 || frame_index == 14);
}

void ac::Box::drawBox(cv::Mat &frame) {
    cv::Mat temp;
    temp.create(cvSize(w, h), CV_8UC3);
    for(int yy = y, pos_y = 0; yy < y+h && yy < frame_height; ++yy, ++pos_y) {
        for(int ii = x,pos_x = 0; ii < x+w && ii < frame_width; ++ii, ++pos_x) {
            cv::Vec3b pixel = frame.at<cv::Vec3b>(yy, ii);
            cv::Vec3b &target = temp.at<cv::Vec3b>(pos_y, pos_x);
            target = pixel;
        }
    }
    ac::draw_func[frame_index](temp);
    for(int z = y, pos_y = 0; z < y+h && z < frame_height; ++z, ++pos_y) {
        for(int i = x, pos_x = 0; i < x+w && i < frame_width; ++i, ++pos_x) {
            if(i < frame.cols && z < frame.rows) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                pixel = temp.at<cv::Vec3b>(pos_y,pos_x);
            }
        }
    }
}

void ac::Box::sizeBox() {
    if(index > steps) {
        initBox(frame_width, frame_height);
        return;
    }
    ++index;
    unsigned int r1 = rand()%10;
    unsigned int r2 = rand()%10;
    if(w+r1 > frame_width) {
        initBox(frame_width, frame_height);
        return;
    } else {
        w += r1;
    }
    if(h+r2 > frame_height) {
        initBox(frame_width, frame_height);
        return;
    } else {
        h += r2;
    }
}

void ac::RandomFilteredSquare(cv::Mat &frame) {
    static std::unique_ptr<Box[]> boxes;
    unsigned int num_boxes = frame.cols/0.5;
    if(boxes == 0 || (frame.cols != Box::frame_width)) {
        boxes.reset(new Box[num_boxes]);
        Box::frame_width = frame.cols;
        Box::frame_height = frame.rows;
        for(int i = 0; i < num_boxes; ++i)
            boxes.get()[i].initBox(frame.cols, frame.rows);
    }
    
    for(int i = 0; i < num_boxes; ++i) {
        boxes.get()[i].sizeBox();
        boxes.get()[i].drawBox(frame);
    }
}
// blend with image 
void ac::ImageX(cv::Mat &frame) {
    if(blend_set == true) {
        static double alpha = 1.0, alpha_max = 8.0;
        static cv::Mat frame_blend = blend_image.clone();
        for(int i = 0; i < frame.cols-1; ++i) {
            for(int z = 0; z < frame.rows-1; ++z) {
                int cX = AC_GetFX(frame_blend.cols, i, frame.cols);
                int cY = AC_GetFZ(frame_blend.rows, z, frame.rows);
                
                if(cX >= frame_blend.cols || cY >= frame_blend.rows)
                    continue;
                
                cv::Vec3b &pixel = blend_image.at<cv::Vec3b>(cY, cX);
                cv::Vec3b pix = blend_image.at<cv::Vec3b>(cY+1, cX+1);
                pixel = pix;
                cv::Vec3b &pix_value = frame.at<cv::Vec3b>(z, i);
                for(int j = 0; j < 3; ++j)
                    pix_value[j] = static_cast<unsigned char>(pixel[j]+(pix_value[j]*alpha));
            }
        }
        static int direction = 1;
        procPos(direction, alpha, alpha_max);
    }
}

void ac::RandomQuads(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    for(int j = 0; j < 4; ++j) {
        unsigned int frame_index = 0;
        do {
            frame_index = rand()%28;
        } while(frame_index == 13 || frame_index == 14);
        ac::draw_func[frame_index](collection.frames[j]);
    }
    cv::Size quarter(frame.cols/2, frame.rows/2);
    ac::copyMat(collection.frames[0],0, 0, frame, ac::Rect(0, 0, quarter));
    ac::copyMat(collection.frames[1],frame.cols/2, 0, frame, ac::Rect(frame.cols/2,0, quarter));
    ac::copyMat(collection.frames[2],frame.cols/2, frame.rows/2, frame, ac::Rect(frame.cols/2, frame.rows/2, quarter));
    ac::copyMat(collection.frames[3],0, frame.rows/2, frame, ac::Rect(0,frame.rows/2, quarter));
}

void ac::QuadCosSinMultiply(cv::Mat &frame) {
    cv::Mat frame_copy = frame.clone();
    cv::Size quarter(frame.cols/2, frame.rows/2);
    DrawFunction procFunc = ac::draw_func[15];
    procFunc(frame_copy);
    procFunc(frame_copy);
    ac::copyMat(frame_copy,0, 0, frame, ac::Rect(0, 0, quarter));
    procFunc(frame_copy);
    ac::copyMat(frame_copy,frame.cols/2, 0, frame, ac::Rect(frame.cols/2,0, quarter));
    procFunc(frame_copy);
    ac::copyMat(frame_copy,frame.cols/2, frame.rows/2, frame, ac::Rect(frame.cols/2, frame.rows/2, quarter));
    procFunc(frame_copy);
    ac::copyMat(frame_copy,0, frame.rows/2, frame, ac::Rect(0,frame.rows/2, quarter));
}

void ac::QuadRandomFilter(cv::Mat &frame) {
    cv::Mat frame_copy = frame.clone();
    cv::Size quarter(frame.cols/2, frame.rows/2);
    unsigned int base_index = 0, index = 0;
    DrawFunction baseFilter = getRandomFilter(base_index);
    baseFilter(frame_copy);
    DrawFunction procFunc = getRandomFilter(index);
    procFunc(frame_copy);
    ac::copyMat(frame_copy,0, 0, frame, ac::Rect(0, 0, quarter));
    procFunc(frame_copy);
    ac::copyMat(frame_copy,frame.cols/2, 0, frame, ac::Rect(frame.cols/2,0, quarter));
    procFunc(frame_copy);
    ac::copyMat(frame_copy,frame.cols/2, frame.rows/2, frame, ac::Rect(frame.cols/2, frame.rows/2, quarter));
    procFunc(frame_copy);
    ac::copyMat(frame_copy,0, frame.rows/2, frame,ac::Rect(0,frame.rows/2, quarter));
}

void ac::RollRandom(cv::Mat &frame) {
    SquareVertical_Roll(frame);
    unsigned int index = 0;
    DrawFunction rand_func = getRandomFilter(index);
    rand_func(frame);
}

void ac::AverageRandom(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 8.0;
    cv::Mat frame_copy = frame.clone(), frame_copy2 = frame.clone();
    unsigned int index = 0;
    DrawFunction func = getRandomFilter(index);
    func(frame_copy);
    func(frame_copy2);
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b pix1 = frame_copy.at<cv::Vec3b>(z, i);
            cv::Vec3b pix2 = frame_copy2.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                pixel[j] = pixel[j] + pix1[j] + pix2[j];
                pixel[j] /= 1.5;
                pixel[j] = static_cast<unsigned char>(pixel[j] * alpha);
            }
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::HorizontalStripes(cv::Mat &frame) {
    static cv::Scalar value(1.0, 1.0, 1.0);
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                double rval = rand()%10;
                double val = rval * 0.001;
                value[j] += val;
                if(value[j] > 255) value[j] = 0;
                pixel[j] = pixel[j] ^ static_cast<unsigned int>(value[j]);
            }
        }
    }
    MedianBlur(frame);
    BlendWithSource(frame);
    Bitwise_XOR(frame);
}

void ac::DiamondStrobe(cv::Mat &frame) {
    static double pos = 1.0;// set pos to 1.0
    int w = frame.cols;// frame width
    int h = frame.rows;// frame height
    static unsigned int index1 = 0, index2 = 2;
    
    ++index1;
    if(index1 > 2) index1 = 0;
    ++index2;
    if(index2 > 2) index2 = 0;
    
    for(int z = 0; z < h; ++z) {// from top to bottom
        for(int i = 0; i < w; ++i) {// from left to right
            cv::Vec3b &buffer = frame.at<cv::Vec3b>(z, i);// get current pixel
            // calculate the colors of the gradient diamonds
            if((i%2) == 0) {// if i % 2 equals 0
                if((z%2) == 0) {// if z % 2 equals 0
                    // set pixel component values
                    buffer[index1] = static_cast<unsigned char>(1-pos*buffer[0]);
                    buffer[index2] = static_cast<unsigned char>((i+z)*pos);
                } else {
                    // set pixel coomponent values
                    buffer[index1] = static_cast<unsigned char>(pos*buffer[0]-z);
                    buffer[index2] = static_cast<unsigned char>((i-z)*pos);
                }
            } else {
                if((z%2) == 0) {// if z % 2 equals 0
                    // set pixel component values
                    buffer[index1] = static_cast<unsigned char>(pos*buffer[0]-i);
                    buffer[index2] = static_cast<unsigned char>((i-z)*pos);
                } else {
                    // set pixel component values
                    buffer[index1] = static_cast<unsigned char>(pos*buffer[0]-z);
                    buffer[index2] = static_cast<unsigned char>((i+z)*pos);
                }
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    // static direction starts off with 1
    static double pos_max = 7.0f;// pos maximum
    static int direction = 1;
    procPos(direction, pos, pos_max);
}

void ac::SmoothTrails(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    Smooth(frame, &collection);
}

ac::GridBox::GridBox() : color(rand()%255, rand()%255, rand()%255), on(true) {}
ac::GridBox::GridBox(const Rect &r, const cv::Vec3b &col) : location(r), color(col) {}
ac::GridBox::GridBox(const cv::Vec3b &col) : color(col), on(true) {}
ac::GridBox::GridBox(const ac::GridBox &gb) : location(gb.location),color(gb.color),on(gb.on) {}
ac::GridBox &ac::GridBox::operator=(const ac::GridBox &gb) {
    color = gb.color;
    location = gb.location;
    on = gb.on;
    return *this;
}
ac::Grid::Grid() :boxes(0), g_random(false) {}
ac::Grid::~Grid() {
    if(boxes != 0) {
        cleanBoxes();
    }
}

bool operator<(const ac::Point &p1, const ac::Point &p2) {
    if(p1.x < p2.x && p1.y < p2.y)
        return true;
    return false;
}

void ac::Grid::cleanBoxes() {
    if(boxes != 0) {
        for(int j = 0; j < g_w; ++j)
            delete [] boxes[j];
        
        delete [] boxes;
        boxes = 0;
    }
}

void ac::Grid::createGrid(cv::Mat &frame, unsigned int w, unsigned int h, unsigned int size) {
    cleanBoxes();
    g_w = w;
    g_h = h;
    g_s = size;
    boxes = new GridBox*[g_w];
    for(int i = 0; i < g_w; ++i) {
        boxes[i] = new GridBox[h];
    }
    if(!points.empty()) {
        points.erase(points.begin(), points.end());
    }
    for(int i = 0; i < g_w; ++i) {
        for(int z = 0; z < g_h; ++z) {
            cv::Vec3b pixel = frame.at<cv::Vec3b>(z*size, i*size);
            Point p(i, z);
            points.push_back(p);
            boxes[i][z] = GridBox(pixel);
            if(g_random)
                boxes[i][z].on = ((rand()%4) == 0) ? false : true;
            
        }
    }
    std::shuffle(points.begin(), points.end(), rng);
    current_offset = 0;
}


void ac::Grid::fillGrid(cv::Mat &frame) {
    if(current_offset < points.size())
        return;
    
    for(int i = 0; i < g_w; ++i) {
        for(int z = 0; z < g_h; ++z) {
            cv::Vec3b pixel = frame.at<cv::Vec3b>(z*g_s, i*g_s);
            boxes[i][z] = GridBox(pixel);
            if(g_random)
                boxes[i][z].on = ((rand()%4) == 0) ? false : true;
            
        }
    }
    current_offset = 0;
    std::shuffle(points.begin(), points.end(), rng);
}

void ac::Grid::updateGrid(unsigned int max) {
    unsigned int iter_max = current_offset+max;
    while(current_offset < points.size() && current_offset < iter_max) {
        const Point &p = points[current_offset];
        boxes[p.x][p.y].on = false;
        current_offset++;
    }
}

void ac::GridFilter8x(cv::Mat &frame) {
    static cv::Size s(0, 0);
    static const int box_size = 8;
    static Grid grid;
    if(frame.size() != s) {
        grid.createGrid(frame, frame.cols/box_size, frame.rows/box_size, box_size);
        s = frame.size();
    }
    unsigned int num = 0;
    if(frame.rows >= 1080)
        num = 100;
    else if(frame.rows >= 720)
        num = 75;
    else if(frame.rows >= 400)
        num = 50;
    else
        num = 25;
    grid.updateGrid(150+rand()%num);
    grid.fillGrid(frame);
    for(int z = 0; z < grid.g_h; ++z) {
        for(int i = 0; i < grid.g_w; ++i) {
            if(grid.boxes[i][z].on)
                fillRect(frame, ac::Rect(i*box_size, z*box_size, grid.g_s, grid.g_s), grid.boxes[i][z].color);
        }
    }
}

void ac::GridFilter16x(cv::Mat &frame) {
    static cv::Size s(0, 0);
    static const int box_size = 16;
    static Grid grid;
    if(frame.size() != s) {
        grid.createGrid(frame, frame.cols/box_size, frame.rows/box_size, box_size);
        s = frame.size();
    }
    unsigned int num = 0;
    if(frame.rows >= 1080)
        num = 50;
    else if(frame.rows >= 720)
        num = 40;
    else if(frame.rows >= 400)
        num = 30;
    else
        num = 20;
    grid.updateGrid(75+rand()%num);
    grid.fillGrid(frame);
    for(int z = 0; z < grid.g_h; ++z) {
        for(int i = 0; i < grid.g_w; ++i) {
            if(grid.boxes[i][z].on)
                fillRect(frame, ac::Rect(i*box_size, z*box_size, grid.g_s, grid.g_s), grid.boxes[i][z].color);
        }
    }
}

void ac::GridFilter8xBlend(cv::Mat &frame) {
    static cv::Size s(0, 0);
    static const int box_size = 8;
    static double alpha = 1.0, alpha_max = 8.0;
    static Grid grid;
    if(frame.size() != s) {
        grid.createGrid(frame, frame.cols/box_size, frame.rows/box_size, box_size);
        s = frame.size();
    }
    unsigned int num = 0;
    if(frame.rows >= 1080)
        num = 100;
    else if(frame.rows >= 720)
        num = 75;
    else if(frame.rows >= 400)
        num = 50;
    else
        num = 25;
    grid.updateGrid(150+rand()%num);
    grid.fillGrid(frame);
    for(int z = 0; z < grid.g_h; ++z) {
        for(int i = 0; i < grid.g_w; ++i) {
            if(grid.boxes[i][z].on) {
                cv::Vec3b pixel = frame.at<cv::Vec3b>(z*grid.g_s, i*grid.g_s);
                for(int j = 0; j < 3; ++j) {
                    pixel[j] = static_cast<unsigned char>((pixel[j]+grid.boxes[i][z].color[j])/2);
                    pixel[j] *= static_cast<unsigned char>(alpha);
                }
                fillRect(frame, ac::Rect(i*box_size, z*box_size, grid.g_s, grid.g_s), pixel);
            }
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::GridRandom(cv::Mat &frame) {
    static cv::Size s(0, 0);
    static const int box_size = 16;
    static Grid grid;
    if(frame.size() != s) {
        grid.g_random = true;
        grid.createGrid(frame, frame.cols/box_size, frame.rows/box_size, box_size);
        s = frame.size();
    }
    unsigned int num = 0;
    if(frame.rows >= 2000)
        num = 250;
    if(frame.rows >= 1080)
        num = 100;
    else if(frame.rows >= 720)
        num = 40;
    else if(frame.rows >= 400)
        num = 30;
    else
        num = 20;
    grid.updateGrid(75+rand()%num);
    grid.fillGrid(frame);
    for(int z = 0; z < grid.g_h; ++z) {
        for(int i = 0; i < grid.g_w; ++i) {
            if(grid.boxes[i][z].on)
                fillRect(frame, ac::Rect(i*box_size, z*box_size, grid.g_s, grid.g_s), grid.boxes[i][z].color);
        }
    }
}

void ac::GridRandomPixel(cv::Mat &frame) {
    static cv::Size s(0, 0);
    static const int box_size = 8;
    static Grid grid;
    if(frame.size() != s) {
        grid.createGrid(frame, frame.cols/box_size, frame.rows/box_size, box_size);
        s = frame.size();
    }
    unsigned int num = 0;
    if(frame.rows >= 2000)
        num = 400;
    if(frame.rows >= 1080)
        num = 200;
    else if(frame.rows >= 720)
        num = 100;
    else if(frame.rows >= 400)
        num = 50;
    else
        num = 20;
    grid.updateGrid(75+rand()%num);
    grid.fillGrid(frame);
    for(int z = 0; z < grid.g_h; ++z) {
        for(int i = 0; i < grid.g_w; ++i) {
            if(grid.boxes[i][z].on) {
                cv::Vec3b rpix(rand()%255,rand()%255,rand()%255);
                for(int j = 0; j < 3; ++j)
                    rpix[j] += grid.boxes[i][z].color[j];
                fillRect(frame, ac::Rect(i*box_size, z*box_size, grid.g_s, grid.g_s),rpix);
            }
        }
    }
}

void ac::Dual_SelfAlphaRainbow(cv::Mat &frame) {
    static double alpha1 = 2.0, alpha2 = 10.0, pos_max = 10.0;
    static bool  switch_on = true;
    rainbowBlend(frame);
    for(int z = 0; z < frame.rows-1; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if(switch_on == true) {
                for(int j = 0; j < 3; ++j)
                    pixel[j] = static_cast<unsigned char>(pixel[j]*alpha1);
            } else {
                for(int j = 0; j < 3; ++j)
                    pixel[j] = static_cast<unsigned char>(pixel[j]*alpha2);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
        switch_on = !switch_on;
    }
    static int direction[2] = { 1, 0 };
    procPos(direction[0], alpha1, pos_max);
    procPos(direction[1], alpha2, pos_max);
}

void ac::Dual_SelfAlphaBlur(cv::Mat &frame) {
    Dual_SelfAlphaRainbow(frame);
    MedianBlur(frame);
    MedianBlur(frame);
    Bitwise_XOR(frame);
}

void ac::SurroundPixelXor(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 4.0;
    for(int z = 0; z < frame.rows-3; ++z) {
        for(int i = 0; i < frame.cols-3; ++i) {
            cv::Vec3b pix[3];
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pix[0] = frame.at<cv::Vec3b>(z+1, i);
            pix[1] = frame.at<cv::Vec3b>(z, i+1);
            pix[2] = frame.at<cv::Vec3b>(z+1, i+1);
            cv::Scalar value;
            value[0] = pix[0][0]+pix[1][0]+pix[2][0];
            value[1] = pix[0][1]+pix[1][1]+pix[2][1];
            value[3] = pix[0][2]+pix[1][2]+pix[2][2];
            for(int j = 0; j < 3; ++j) {
                unsigned int val = static_cast<unsigned int>(value[j]);
                pixel[j] = static_cast<unsigned char>((val^pixel[j])*alpha);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::Darken(cv::Mat &frame) {
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[0] /= 6;
            pixel[1] /= 6;
            pixel[2] /= 6;
        }
    }
}

void ac::WeakBlend(cv::Mat &frame) {
    static unsigned int index = 0;
    static cv::Scalar value((rand()%5)+1,(rand()%5)+1,(rand()%5)+1);
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                unsigned int val = pixel[j]+(pixel[j]*value[index]);
                val /= 2;
                pixel[j] = static_cast<unsigned char>(val);
            }
            index ++;
            if(index > 2)
                index = 0;
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    for(int j = 0; j < 3; ++j) {
        value[j] += 1+((rand()%5) * 0.5);
        if(value[j] > 10) {
            value[j] = rand()%10;
        }
    }
}

void ac::AverageVertical(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 8.0;
    std::unique_ptr<cv::Scalar[]> values(new cv::Scalar[frame.rows]);
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j)
                values.get()[z][j] += pixel[j];
        }
    }
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Scalar val = values.get()[z];
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                val[j] /= frame.rows;
                pixel[j] += static_cast<unsigned char>(val[j]*alpha);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}


void ac::RandomCollectionAverage(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    unsigned int index = 0;
    DrawFunction randF = getRandomFilter(index);
    randF(frame);
    Smooth(frame, &collection);
}

void ac::RandomCollectionAverageMax(cv::Mat &frame) {
    static MatrixCollection<16> collection;
    unsigned int index = 0;
    DrawFunction randF = getRandomFilter(index);
    randF(frame);
    Smooth(frame, &collection);
}

void ac::SmoothTrailsSelfAlphaBlend(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    MedianBlur(frame);
    SelfAlphaBlend(frame);
    Smooth(frame, &collection);
}

void ac::SmoothTrailsRainbowBlend(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    MedianBlur(frame);
    rainbowBlend(frame);
    Smooth(frame, &collection);
}

void ac::MedianBlend(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    int r = rand()%10;
    for(int i = 0; i < r; ++i)
        MedianBlur(frame);
    
    collection.shiftFrames(frame);
    static double alpha = 1.0, alpha_max = 3.0;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Scalar value;
            for(int j = 0; j < collection.size()-1; ++j) {
                cv::Vec3b pixel = collection.frames[j].at<cv::Vec3b>(z, i);
                for(int q = 0; q < 3; ++q) {
                    value[q] += pixel[q];
                }
            }
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                unsigned int val = 1+static_cast<unsigned int>(value[j]);
                pixel[j] = static_cast<unsigned char>(pixel[j] ^ val);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::SmoothRandomImageBlend(cv::Mat &frame) {
    if(blend_set == true) {
        static MatrixCollection<8> collection;
        unsigned int index = 0;
        DrawFunction rfunc = getRandomFilter(index);
        cv::Mat temp_frame;
        cv::resize(blend_image, temp_frame, frame.size());
        rfunc(temp_frame);
        collection.shiftFrames(temp_frame);
        Smooth(frame, &collection);
    }
}

void ac::SmoothImageAlphaBlend(cv::Mat &frame) {
    if(blend_set == true) {
        static double alpha = 1.0, alpha_max = 2.0;
        static MatrixCollection<8> collection;
        cv::Mat temp_frame;
        cv::Mat temp_image;
        cv::Mat blend_image_scaled;
        cv::resize(blend_image, blend_image_scaled, frame.size());
        temp_frame = frame.clone();
        AlphaBlend(temp_frame,blend_image_scaled,frame,alpha);
        collection.shiftFrames(frame);
        Smooth(temp_frame, &collection);
        frame = temp_frame;
        static int direction = 1;
        procPos(direction, alpha, alpha_max, 8, 0.05);
    }
}

void ac::RandomAlphaBlend(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    double alpha = 1.0, alpha_max = 6.0;
    unsigned int index = 0;
    DrawFunction randFunc = getRandomFilter(index);
    cv::Mat temp = frame.clone(), rand_frame = frame.clone();
    randFunc(rand_frame);
    collection.shiftFrames(rand_frame);
    AlphaBlend(temp,rand_frame, frame, alpha);
    Smooth(frame, &collection);
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::RandomTwoFilterAlphaBlend(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 5.0;
    static MatrixCollection<8> collection;
    cv::Mat one, two, output;
    one = frame.clone();
    two = frame.clone();
    unsigned int index = 0;
    DrawFunction randFunc1 = getRandomFilter(index);
    DrawFunction randFunc2 = getRandomFilter(index);
    randFunc1(one);
    randFunc2(two);
    AlphaBlend(one, two, output, alpha);
    collection.shiftFrames(output);
    Smooth(frame, &collection);
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::PixelatedSquare(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    static double alpha = 1.0, alpha_max = 3.0;
    cv::Mat filter_1 = frame.clone();
    cv::Mat frame_copy;
    SurroundPixelXor(filter_1);
    GridFilter16x(filter_1);
    
    AlphaBlend(filter_1,frame,frame_copy,alpha);
    collection.shiftFrames(frame_copy);
    Smooth(frame, &collection);
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::AlphaBlendPosition(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 4.0;
    unsigned int pos_x = 0;
    for(int z = 0; z < frame.rows; ++z) {
        cv::Vec3b pix = frame.at<cv::Vec3b>(z, pos_x);
        ++pos_x;
        if(pos_x > frame.cols-1) pos_x = 0;
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j)
                pixel[j] = static_cast<unsigned char>((pixel[j]*alpha)+(pix[j]*alpha));
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::BlendRowAlpha(cv::Mat &frame) {
    static int row = 0;
    static double alpha = 1.0, alpha_max = 4.0;
    for(int i = 0; i < frame.cols; ++i) {
        row++;
        if(row > frame.cols) row = 0;
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>((pixel[j] ^ row)*alpha);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::BlendRow(cv::Mat &frame) {
    static int row = 0;
    for(int i = 0; i < frame.cols; ++i) {
        row++;
        if(row > frame.cols) row = 0;
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>(pixel[j] ^ row);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
}

void ac::BlendRowByVar(cv::Mat &frame) {
    static int row = 0;
    for(int i = 0; i < frame.cols; ++i) {
        row++;
        if(row > frame.cols) row = 0;
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>((pixel[j]+(z-i)) ^ row);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
}

void ac::BlendRowByDirection(cv::Mat &frame) {
    static int row = 0;
    static int direction = 1;
    for(int i = 0; i < frame.cols; ++i) {
        if(direction == 1) {
            ++row;
            if(row > frame.cols)
                direction = 0;
        } else if(direction == 0) {
            --row;
            if(row <= 0) {
                direction = 1;
            }
        }
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
                if(direction == 1)
                    pixel[j] = static_cast<unsigned char>((pixel[j]+i+z) & row);
                else if(direction == 0)
                    pixel[j] = static_cast<unsigned char>((pixel[j]^row));
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
}

void ac::BlendAlphaXor(cv::Mat &frame) {
    static int r = 3;
    static int direction = 1;
    static double alpha = 1.0, alpha_max = 10.0;
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                unsigned char val = static_cast<unsigned char>(r*alpha);
                pixel[j] += cv::saturate_cast<unsigned char>(pixel[j]^val);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    if(direction == 1) {
        ++r;
        if(r >= 255)
            direction = 0;
    } else if(direction == 0) {
        --r;
        if(r <= 3)
            direction = 1;
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
}

void ac::SelfXorScale(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 8.0;
    static unsigned int value = 1;
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>((pixel[j]^value)*alpha);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int direction = 1;
    if(direction == 1)  {
        ++value;
        if(value > 254)
            direction = 0;
    } else if(direction == 0) {
        --value;
        if(value <= 1)
            direction = 1;
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
}

void ac::BitwiseXorScale(cv::Mat &frame) {
    static cv::Mat frame1 = frame.clone();
    cv::Mat temp = frame.clone();
    
    if(frame1.size()!=frame.size())
        frame1 = temp.clone();
    
    static double alpha = 1.0, alpha_max = 2.0;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b pix = frame1.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                pixel[j] += static_cast<unsigned char>((pixel[j]^pix[j])*alpha);
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    frame1 = temp;
    static int direction = 1;
    procPos(direction, alpha, alpha_max);
}

void ac::XorTrails(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b value;
            for(unsigned int j = 0; j < collection.size(); ++j) {
                cv::Vec3b frame_val = collection.frames[j].at<cv::Vec3b>(z, i);
                for(unsigned int q = 0; q < 3; ++q) {
                    value[q] ^= frame_val[q];
                }
            }
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] = pixel[j]^value[j];
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
}

void ac::RainbowTrails(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b value;
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);;
            for(unsigned int j = 0; j < collection.size(); ++j) {
                cv::Vec3b frame_val = collection.frames[j].at<cv::Vec3b>(z, i);
                for(unsigned int q = 0; q < 3; ++q) {
                    value[q] += frame_val[q];
                }
            }
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = pixel[j]^value[j];
            }
        }
    }
}
void ac::NegativeTrails(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    static double alpha = 1.0, alpha_max = 8.0;
    collection.shiftFrames(frame);
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b value;
            for(unsigned int j = 0; j < collection.size(); ++j) {
                cv::Vec3b frame_val = collection.frames[j].at<cv::Vec3b>(z, i);
                for(unsigned int q = 0; q < 3; ++q) {
                    pixel[q] ^= pixel[q]+frame_val[q];
                }
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
}

void ac::IntenseTrails(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    collection.shiftFrames(frame);
    static double alpha = 1.0, alpha_max = 8.0;
    for(int i = 0; i < frame.cols; ++i) {
        for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b value = pixel;
            for(unsigned int j = 0; j < collection.size(); ++j) {
                cv::Vec3b frame_val = collection.frames[j].at<cv::Vec3b>(z, i);
                for(unsigned int q =0; q < 3; ++q) {
                    value[q] += static_cast<unsigned char>(frame_val[q]*alpha);
                    
                }
            }
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] ^= value[j];
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
}

void ac::SelfAlphaRGB(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 3.0;
    static int index = 0;
    for(int i = 0; i < frame.cols-2; ++i) {
        for(int z = 0;  z < frame.rows-2; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b pix[4];
            pix[0] = frame.at<cv::Vec3b>(z+1, i+1);
            pix[1] = frame.at<cv::Vec3b>(z+1, i);
            pix[2] = frame.at<cv::Vec3b>(z, i+1);
            pix[3] = pixel;
            switch(index) {
                case 0:
                    pixel[0] = static_cast<unsigned char>(pix[0][0]*alpha);
                    pixel[1] = static_cast<unsigned char>((pix[0][1]+pix[1][1])*alpha);
                    pixel[2] = static_cast<unsigned char>((pix[0][2]+pix[1][2]+pix[2][2])*alpha);
                    break;
                case 1:
                    pixel[2] = static_cast<unsigned char>(pix[0][0]*alpha);
                    pixel[1] = static_cast<unsigned char>((pix[0][1]+pix[1][1])*alpha);
                    pixel[0] = static_cast<unsigned char>((pix[0][2]+pix[1][2]+pix[2][2])*alpha);
                    break;
                case 2:
                    pixel[1] = static_cast<unsigned char>(pix[0][0]*alpha);
                    pixel[0] = static_cast<unsigned char>((pix[0][1]+pix[1][1])*alpha);
                    pixel[2] = static_cast<unsigned char>((pix[0][2]+pix[1][2]+pix[2][2])*alpha);
                    break;
                case 3:
                    pixel[0] = pixel[0]^static_cast<unsigned char>(pix[0][0]*alpha);
                    pixel[1] = pixel[1]^static_cast<unsigned char>((pix[0][1]+pix[1][1])*alpha);
                    pixel[2] = pixel[2]^static_cast<unsigned char>((pix[0][2]+pix[1][2]+pix[2][2])*alpha);
                    break;
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
    
    ++index;
    if(index > 3) index = 0;
}

void ac::BlendImageOnOff(cv::Mat &frame) {
    if(blend_set == true) {
        static double alpha = 1.0, alpha_max = 4.0;
        static int index = 0;
        for(int z = 3; z < frame.rows-3; ++z) {
            for(int i = 3; i < frame.cols-3; ++i) {
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b pix[4];
                pix[0] = blend_image.at<cv::Vec3b>(cY, cX);
                pix[1] = blend_image.at<cv::Vec3b>(cY+1, cX);
                pix[2] = blend_image.at<cv::Vec3b>(cY, cX+1);
                pix[3] = blend_image.at<cv::Vec3b>(cY+1, cX+1);
                cv::Scalar value;
                for(unsigned int j = 0; j < 4; ++j) {
                    for(unsigned int q = 0; q < 3; ++q) {
                        value[q] += pix[j][q];
                    }
                }
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                for(unsigned int j = 0; j < 3; ++j) {
                    value[j] /= 4;
                    unsigned char val = static_cast<unsigned char>(value[j]);
                    switch(index) {
                        case 0:
                            pixel[j] += static_cast<unsigned char>(val*alpha);
                            break;
                        case 1:
                            pixel[j] -= static_cast<unsigned char>(val*alpha);
                            break;
                    }
                }
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
            }
        }
        ++index;
        if(index > 1) index = 0;
        
        static int dir = 1;
        procPos(dir, alpha, alpha_max);
    }
}

void ac::XorSelfAlphaImage(cv::Mat &frame) {
    if(blend_set == true) {
        static double alpha = 1.0, alpha_max = 2.0;
        static double alpha_r = 14.0;
        for(int z = 0; z < frame.rows; ++z) {
            for(int i = 0; i < frame.cols; ++i) {
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                int cX = AC_GetFX(blend_image.cols, i, frame.cols);
                int cY = AC_GetFZ(blend_image.rows, z, frame.rows);
                cv::Vec3b pix = blend_image.at<cv::Vec3b>(cY, cX);
                for(unsigned int j = 0; j < 3; ++j) {
                    //pixel[j] ^= (1-((pixel[j] + pix[j])) * (2+static_cast<unsigned char>(alpha)));
                    pixel[j] = static_cast<unsigned char>(pixel[j] * alpha) + (pix[j] * alpha_r);
                }
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
            }
        }
        static int dir = 1, dir_r = 0;
        procPos(dir, alpha, alpha_max);
        procPos(dir_r, alpha_r, alpha_max);
    }
}

void ac::BitwiseXorStrobe(cv::Mat &frame) {
    static int index = 0;
    static double alpha1 = 1.0, alpha2 = 10.0, alpha3 = 5.0,alpha_max = 3.0;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            switch(index) {
                case 0:
                    pixel[0] += cv::saturate_cast<unsigned char>(pixel[0] * alpha1);
                    pixel[1] += cv::saturate_cast<unsigned char>(pixel[1] * alpha2);
                    pixel[2] += cv::saturate_cast<unsigned char>(pixel[2] * alpha3);
                    break;
                case 1:
                    pixel[2] += cv::saturate_cast<unsigned char>(pixel[0] * alpha1);
                    pixel[0] += cv::saturate_cast<unsigned char>(pixel[1] * alpha2);
                    pixel[1] += cv::saturate_cast<unsigned char>(pixel[2] * alpha3);
                    break;
                case 2:
                    pixel[1] += cv::saturate_cast<unsigned char>(pixel[0] * alpha1);
                    pixel[2] += cv::saturate_cast<unsigned char>(pixel[1] * alpha2);
                    pixel[0] += cv::saturate_cast<unsigned char>(pixel[2] * alpha3);
                    break;
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir1 = 1, dir2 = 0, dir3 = 1;
    procPos(dir1, alpha1, alpha_max);
    procPos(dir2, alpha2, alpha_max);
    procPos(dir3, alpha3, alpha_max);
    
    ++index;
    if(index > 2) index = 0;
    Bitwise_XOR(frame);
}


void ac::AlphaBlendRandom(cv::Mat &frame) {
    static double val = 0.30;
    static int val_dir = 1;
    unsigned int index = 0;
    DrawFunction func[2];
    func[0] = getRandomFilter(index);
    func[1] = getRandomFilter(index);
    cv::Mat copy[4];
    copy[0] = frame.clone();
    copy[1] = frame.clone();
    copy[2] = frame.clone();
    func[0](copy[0]);
    func[1](copy[1]);
    AlphaBlend(copy[0], copy[1], copy[3], 0.5);
    AlphaBlend(copy[2], copy[3], frame, val);
    if(val_dir == 1) {
        val += 0.05;
        if(val >= 1.0)
            val_dir = 0;
    } else {
        val -= 0.05;
        if(val <= 0.30)
            val_dir = 1;
    }
}

void ac::ChannelSortAlphaBlend(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 3.0;
    static unsigned int index = 0;
    std::vector<cv::Mat> v; // to hold the Matrix for split
    cv::split(frame, v);// split the channels into seperate matrices
    cv::Mat channels[3]; // output channels
    cv::Mat output; // for merge
    cv::sort(v[0], channels[0],cv::SORT_ASCENDING); // sort each matrix
    cv::sort(v[1], channels[1],cv::SORT_ASCENDING);
    cv::sort(v[2], channels[2],cv::SORT_ASCENDING);
    cv::sort(v[index], channels[index], cv::SORT_DESCENDING);
    cv::merge(channels, 3, output);
    ++index;
    if(index > 2) index = 0;
    cv::Mat copy = frame.clone();
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b pixadd = output.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
            	//pixel += pixadd;
                pixel[j] = static_cast<unsigned char>((pixel[j] * alpha) + (pixadd[j] * alpha));
            }
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max, 10, 0.01);
}

void ac::XorChannelSort(cv::Mat &frame) {
    std::vector<cv::Mat> v; // to hold the Matrix for split
    cv::split(frame, v);// split the channels into seperate matrices
    cv::Mat channels[3]; // output channels
    cv::Mat output; // for merge
    cv::sort(v[0], channels[0],(((rand()%2) == 0) ? cv::SORT_ASCENDING : cv::SORT_DESCENDING)); // sort each matrix
    cv::sort(v[1], channels[1],(((rand()%2) == 0) ? cv::SORT_ASCENDING : cv::SORT_DESCENDING)); // sort each matrix
    cv::sort(v[2], channels[2],(((rand()%2) == 0) ? cv::SORT_ASCENDING : cv::SORT_DESCENDING)); // sort each matrix
    cv::merge(channels, 3, output);
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b sorted = output.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] = pixel[j] ^ sorted[j];
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
}

void ac::GradientColors(cv::Mat &frame) {
    static unsigned int index = 0;
    static unsigned char val = 0;
    unsigned int inc = (frame.rows/255)+1;
    for(int i = 0; i < frame.cols; ++i) {
        val = 1;
    	for(int z = 0; z < frame.rows; ++z) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] = val;
            if((z%inc) == 0)
                ++val;
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    ++index;
    if(index > 2)
        index = 0;
}

void ac::GradientColorsVertical(cv::Mat &frame) {
    static unsigned int index = 0;
    static unsigned char val = 0;
    unsigned int inc = (frame.cols/255)+1;
    for(int z = 0; z < frame.rows; ++z) {
        val = 1;
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            pixel[index] = val;
         
            if((i%inc) == 0)
                ++val;
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    ++index;
    if(index > 2)
        index = 0;
}

void ac::Bitwise_XOR_Average(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 8.0;
    for(int z = 0; z < frame.rows; ++z) {
        cv::Scalar sval;
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j) {
                sval[j] += pixel[j];
            }
        }
        
        for(unsigned int j = 0; j < 3; ++j)
            sval[j] /= frame.cols;
        
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] = (pixel[j] * alpha) + (static_cast<unsigned char>(sval[j])*alpha);
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
     }
    static int dir = 1;
    procPos(dir, alpha, alpha_max, 0.01);
    Bitwise_XOR(frame);
}

void ac::NotEqual(cv::Mat &frame) {
    
    static MatrixCollection<2> collection;
    collection.shiftFrames(frame);
    static double alpha = 1.0, alpha_max = 3.0;
    
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            bool same_value =  true;
            cv::Vec3b value;
            for(unsigned int j = 0; j < collection.size(); ++j) {
                value = collection.frames[j].at<cv::Vec3b>(z, i);
                if(value != pixel) {
                    same_value = false;
                    break;
                }
            }
            if(same_value == false) {
                for(unsigned int j = 0; j < 3; ++j) {
                    pixel[j] = (pixel[j] * alpha) + (value[j] * alpha);
                }
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max, 0.10);
}

void ac::ImageShiftUpLeft(cv::Mat &frame) {
    if(blend_set) {
        static double alpha = 1.0, alpha_max = 3.0;
        static cv::Mat image = blend_image.clone();
        if(reset_filter == true) {
            reset_filter = false;
            image = blend_image.clone();
        }
        for(int i = 0; i < image.cols-1; ++i) {
            for(int z = 0; z < image.rows-1; ++z) {
                cv::Vec3b val = image.at<cv::Vec3b>(z+1, i+1);
                cv::Vec3b &target = image.at<cv::Vec3b>(z, i);
                target = val;
            }
        }
        for(int i = 0; i < frame.cols; ++i) {
            for(int z = 0; z < frame.rows; ++z) {
                int cX = AC_GetFX(image.cols, i, frame.cols);
                int cY = AC_GetFZ(image.rows, z, frame.rows);
                cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
                cv::Vec3b src_pixel = image.at<cv::Vec3b>(cY, cX);
                for(unsigned int j = 0; j < 3; ++j)
                    pixel[j] = static_cast<unsigned char>((alpha * pixel[j])) ^ src_pixel[j];
                
                swapColors(frame, z, i);// swap colors
                if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
            }
        }
        static int dir = 1;
        procPos(dir, alpha, alpha_max);
    }
}

void ac::GradientXorSelfScale(cv::Mat &frame) {
    static double alpha = 1.0, alpha_max = 3.0;
    for(int z = 0; z < frame.rows-1; ++z) {
        for(int i = 0; i < frame.cols-1; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            cv::Vec3b pix = frame.at<cv::Vec3b>(z+1, i+1);
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>((pixel[j] * alpha)) ^ pix[j];
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max, 10, 0.03);
}

void ac::SmoothSourcePixel(cv::Mat &frame) {
    static MatrixCollection<8> collection;
    static double alpha = 1.0, alpha_max = 3.0;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            unsigned int total = pixel[0]+pixel[1]+pixel[2]/3;
            for(unsigned int j = 0; j < 3; ++j) {
                pixel[j] = static_cast<unsigned char>(((pixel[j] ^ total) * static_cast<unsigned char>(alpha)));
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max, 15, 0.1);
    collection.shiftFrames(frame);
    Smooth(frame, &collection);
}

void ac::StrobeBlend(cv::Mat &frame) {
    unsigned int value1 = ((frame.cols/2)/255)+1;
    unsigned int num = 1, num2 = 1;
    static double alpha = 1.0, alpha_max = 8.0;
    static int index1 = 0, index2 = 2;
    static int frame_num = 0;
    
    ++frame_num;
    if(frame_num > 1) frame_num = 0;
    
    for(int z = 0; z < frame.rows; ++z) {
        num = 1;
        num2 = 1;
    	for(int i = 0; i < frame.cols/2; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if((i%value1)==0)
                num++;
            if(frame_num == 0) {
            	for(unsigned int j = 0; j < 3; ++j) {
                	pixel[j] = pixel[j] ^ static_cast<unsigned char>(num);
            	}
            } else {
                for(unsigned int j = 0; j < 3; ++j) {
                    pixel[j] = pixel[j] ^ static_cast<unsigned char>(num/(alpha+1));
                }
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
            //pixel[index1]= 255;
        }
        for(int i = frame.cols/2; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            if((i%value1)==0)
                num2++;
            if(frame_num == 0) {
            	for(unsigned int j = 0; j < 3; ++j) {
                	pixel[j] = pixel[j] ^ static_cast<unsigned char>(num2);
            	}
            } else {
                for(unsigned int j = 0; j < 3; ++j) {
                    pixel[j] = pixel[j] ^ static_cast<unsigned char>(num2/(alpha+1));
                }
            }
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
            //pixel[index2] = 0;
        }
    }
    if(++index1 > 2) index1 = 0;
    if(--index2 < 0) index2 = 2;
    static int dir = 1;
    procPos(dir, alpha, alpha_max, 15, 0.03);
}

void ac::FrameBars(cv::Mat &frame) {
    unsigned int diff_i = (frame.cols/255)+1;
    unsigned int diff_z = (frame.rows/255)+1;
    unsigned char val[2] = {0,0};
    static double alpha = 1.0, alpha_max = 8.0;
    static MatrixCollection<4> collection;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] += static_cast<unsigned char>(val[0]*alpha) + static_cast<unsigned char>(val[1]*alpha);
            
            swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel */
            
            if((i%diff_i) == 0) {
                val[0]++;
            }
        }
        if((z%diff_z) == 0) {
            val[1]++;
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
    collection.shiftFrames(frame);
    Smooth(frame, &collection);
}

void ac::Sort_Vertical_Horizontal(cv::Mat &frame) {
    cv::Mat value = frame.clone();
    VerticalChannelSort(value);
    ChannelSort(value);
    Add(frame, value, false);
    
}

void ac::Sort_Vertical_Horizontal_Bitwise_XOR(cv::Mat &frame) {
    cv::Mat value = frame.clone();
    VerticalChannelSort(value);
    ChannelSort(value);
    static bool sub = false;
    if(sub == false)
        Add(frame, value, false);
    else
        Sub(frame, value, false);
    sub = (sub == true) ? false : true;
    Bitwise_XOR(frame);
}

void ac::Scalar_Average_Multiply(cv::Mat &frame) {
    cv::Mat copy = frame.clone();
    VerticalChannelSort(frame);
    cv::Scalar average;
    ScalarAverage(frame, average);
    Transform(copy, frame, [&](cv::Vec3b &pixel, int i, int z) {
        for(unsigned int j = 0; j < 3; ++j) {
            pixel[j] *= average[j];
        }
    });
    cv::Mat out = frame.clone();
    AlphaBlend(out, copy, frame, 0.5);
}

void ac::Scalar_Average(cv::Mat &frame) {
    cv::Mat copy = frame.clone();
    cv::Scalar value;
    ScalarAverage(frame, value);
    Transform(copy, frame,[&](cv::Vec3b &pixel, int i, int z) {
        for(unsigned int j = 0; j < 3; ++j)
            pixel[j] *= value[j];
    });
    cv::Mat out = frame.clone();
    AlphaBlend(copy, out, frame, 0.5);
}

void ac::Total_Average(cv::Mat &frame) {
    cv::Mat frames[3];
    static double alpha = 1.0, alpha_max = 8.0;
    frames[0] = frame.clone();
    frames[1] = frame.clone();
    frames[2] = frame.clone();

    SelfScale(frames[0]);
    rainbowBlend(frames[1]);
    SelfAlphaRGB(frames[2]);
    
    unsigned long total[3];
    
    for(unsigned int j = 0; j < 3; ++j)
    	TotalAverageOffset(frames[j], total[j]);
    
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] += (alpha*total[j]);
        }
    }
    static int dir = 1;
    procPos(dir, alpha, alpha_max);
    
}

void ac::AlphaBlendImageXor(cv::Mat &frame) {
    if(blend_set == true) {
        static MatrixCollection<8> collection;
    	SmoothImageAlphaBlend(frame);
    	Bitwise_XOR(frame);
        collection.shiftFrames(frame);
        Smooth(frame, &collection);
    }
}

void ac::FlashWhite(cv::Mat &frame) {
    static cv::Vec3b white(255,255,255);
    static bool state = false;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            if(state)
                frame.at<cv::Vec3b>(z, i) = white;
        }
    }
    state = (state == true) ? false : true;
}

void ac::FlashBlackAndWhite(cv::Mat &frame) {
    static int index = 0;
    static cv::Vec3b white(255,255,255), black(0,0,0);
    if(index != 1 && index != 3) {
        for(int z = 0; z < frame.rows; ++z) {
            for(int i = 0; i < frame.cols; ++i) {
                switch(index) {
                    case 0:
                        frame.at<cv::Vec3b>(z, i) = white;
                        break;
                    case 2:
                        frame.at<cv::Vec3b>(z, i) = black;
                }
            }
        }
    }
    ++index;
    if(index > 3) index = 0;
}

// No Filter
void ac::NoFilter(cv::Mat &) {}

// Alpha Blend with Original Frame
void ac::BlendWithSource(cv::Mat &frame) {
    ac::pass2_alpha = 0.50; // set to 50%
    Pass2Blend(frame);// call Pass2 function
}

// Apply color map to cv::Mat
void ac::ApplyColorMap(cv::Mat &frame) {
    if(set_color_map > 0 && set_color_map < 13) {
        cv::Mat output_f1 = frame.clone();
        cv::applyColorMap(output_f1, frame, (int)set_color_map-1);
        const int w = frame.cols;
        const int h = frame.rows;
        color_map_set = true;
        for(int z = 0; z < h; ++z) {
            for(int i = 0; i < w; ++i) {
                ac::swapColors(frame, z, i);
                if(isNegative) ac::invert(frame, z, i);
            }
        }
        color_map_set = false;
    }
}

// set cv::Mat brightness
void ac::setBrightness(cv::Mat &frame, double alpha, int beta) {
    cv::Mat c = frame.clone();
    c.convertTo(frame, -1, alpha, beta);
}

// set cv::Mat gamma
void ac::setGamma(cv::Mat &frame, cv::Mat &outframe, const double gamma) {
    cv::Mat lookUpTable(1, 256, CV_8U);
    uchar* p = lookUpTable.ptr();
    for(int i = 0; i < 256; ++i) {
        p[i] = cv::saturate_cast<unsigned char>(pow(i / 255.0, gamma) * 255.0);
    }
    cv::Mat res = frame.clone();
    LUT(frame, lookUpTable, outframe);
}

// set cv::Mat saturation
void ac::setSaturation(cv::Mat &frame, int saturation) {
    cv::Mat image;
    cv::cvtColor(frame, image, CV_BGR2HSV);
    const int w = frame.cols;
    const int h = frame.rows;
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = image.at<cv::Vec3b>(z, i);
            pixel[1] = static_cast<unsigned char>(saturation);
        }
    }
    cv::cvtColor(image, frame, CV_HSV2BGR);
}

void ac::Negate(cv::Mat &frame) {
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j)
                pixel[j] = ~pixel[j];
        }
    }
}

void ac::Add(cv::Mat &src, cv::Mat &add, bool sat) {
    if(src.size() != add.size())
        return;
    if(src.empty() || add.empty())
        return;
    
    for(int z = 0; z < src.rows; ++z) {
        for(int i = 0; i < src.cols; ++i) {
            cv::Vec3b &pixel = src.at<cv::Vec3b>(z, i);
            cv::Vec3b pix = add.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] = (sat == true) ? cv::saturate_cast<unsigned char>(pixel[j]+pix[j]) : static_cast<unsigned char>(pixel[j]+pix[j]);
        }
    }
}

void ac::Sub(cv::Mat &src, cv::Mat &sub, bool sat) {
    if(src.size() != sub.size())
        return;
    if(src.empty() || sub.empty())
        return;
    
    for(int z = 0; z < src.rows; ++z) {
        for(int i = 0; i < src.cols; ++i) {
            cv::Vec3b &pixel = src.at<cv::Vec3b>(z, i);
            cv::Vec3b pix = sub.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                pixel[j] = (sat == true) ? cv::saturate_cast<unsigned char>(pixel[j]-pix[j]) : static_cast<unsigned char>(pixel[j]-pix[j]);
        }
    }
}

template<typename Func>
void ac::Transform(const cv::Mat &source, cv::Mat &output, Func func) {
    
    if(output.empty() || output.size() != source.size())
        output.create(source.size(), CV_8UC3);

    for(int z = 0; z < source.rows; ++z) {
        for(int i = 0; i < source.cols; ++i) {
            cv::Vec3b &pixel = output.at<cv::Vec3b>(z, i);
            cv::Vec3b value = source.at<cv::Vec3b>(z, i);
            func(value, i, z);
            pixel = value;
            ac::swapColors(output, z, i);
            if(isNegative) ac::invert(output, z, i);
        }
    }
}

void ac::ScalarAverage(const cv::Mat &frame, cv::Scalar &s) {
    s = cv::Scalar();
    if(frame.empty()) return;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b col = frame.at<cv::Vec3b>(z, i);
            for(unsigned int j = 0; j < 3; ++j)
                s[j] += col[j];
        }
    }
    unsigned long total_pixels = frame.rows * frame.cols;
    for(unsigned int j = 0; j < 3; ++j)
        s[j] /= total_pixels;
}

void ac::TotalAverageOffset(cv::Mat &frame, unsigned long &value) {
    if(frame.empty()) return;
    value = 0;
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            value += (pixel[0]+pixel[1]+pixel[2]);
        }
    }
    value /= (frame.rows * frame.cols);
}

// filter color keyed image
void ac::filterColorKeyed(const cv::Vec3b &color, const cv::Mat &orig, const cv::Mat &filtered, cv::Mat &output) {
    if(colorkey_set == false || color_image.empty()) return;
    if(orig.size()!=filtered.size()) {
        std::cerr << "filterColorKeyed: Error not same size...\n";
        return;
    }
    output = orig.clone();
    for(int z = 0; z < orig.rows; ++z) {
        for(int i = 0; i < orig.cols; ++i) {
            int cX = AC_GetFX(color_image.cols, i, orig.cols);
            int cY = AC_GetFZ(color_image.rows, z, orig.rows);
            cv::Vec3b add_i = color_image.at<cv::Vec3b>(cY, cX);
            if(add_i == color) {
                cv::Vec3b pixel = filtered.at<cv::Vec3b>(z, i);
                cv::Vec3b &dst = output.at<cv::Vec3b>(z, i);
                dst = pixel;
            }
        }
    }
}

// Alpha Blend function
void ac::AlphaBlend(const cv::Mat &one, const cv::Mat &two, cv::Mat &output,double alpha) {
    if(one.size() != two.size()) {
        return;
    }
    
    if(output.empty() || output.size() != one.size())
        output.create(one.size(), CV_8UC3);
    
    for(int z = 0; z < one.rows; ++z) {
        for(int i = 0; i < one.cols; ++i) {
            cv::Vec3b pix[2];
            cv::Vec3b &pixel = output.at<cv::Vec3b>(z, i);
            pix[0] = one.at<cv::Vec3b>(z, i);
            pix[1] = two.at<cv::Vec3b>(z, i);
            pixel[0] = static_cast<unsigned char>((pix[0][0] * alpha) + (pix[1][0] * alpha));
            pixel[1] = static_cast<unsigned char>((pix[0][1] * alpha) + (pix[1][1] * alpha));
            pixel[2] = static_cast<unsigned char>((pix[0][2] * alpha) + (pix[1][2] * alpha));
        }
    }
}

template<int Size>
void ac::Smooth(cv::Mat &frame, MatrixCollection<Size> *collection) {
    collection->shiftFrames(frame);
    for(int z = 0; z < frame.rows; ++z) {
        for(int i = 0; i < frame.cols; ++i) {
            cv::Scalar test;
            for(int q = 0; q < collection->size()-1; ++q) {
                cv::Mat &framev = collection->frames[q];
                cv::Vec3b pix = framev.at<cv::Vec3b>(z, i);
                for(int j = 0; j < 3; ++j) {
                    test[j] += pix[j];
                }
            }
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i);
            for(int j = 0; j < 3; ++j) {
                test[j] /= (collection->size()-1);
                pixel[j] = cv::saturate_cast<unsigned char>(test[j]);
            }
            ac::swapColors(frame, z, i);// swap colors
            if(isNegative) invert(frame, z, i);// if isNegative invert pixel
        }
    }
}


// Make two copies of the current frame, apply filter1 to one, filter2 to the other
// then Alpha Blend them together
void ac::filterFade(cv::Mat &frame, int filter1, int filter2, double alpha) {
    const int h = frame.rows; // frame height
    const int w = frame.cols;// framew idth
    // make copies of original frame
    cv::Mat frame1 = frame.clone(), frame2 = frame.clone();
    // apply filters on two copies of original frame
    ac::draw_func[filter1](frame1);
    ac::draw_func[filter2](frame2);
    // loop through image setting each pixel with alphablended pixel
    for(int z = 0; z < h; ++z) {
        for(int i = 0; i < w; ++i) {
            cv::Vec3b &pixel = frame.at<cv::Vec3b>(z, i); // target pixel
            cv::Vec3b frame1_pix = frame1.at<cv::Vec3b>(z, i); // frame1 pixel
            cv::Vec3b frame2_pix = frame2.at<cv::Vec3b>(z, i); // frame2 pixel
            // loop through pixel components and set target pixel to alpha blended pixel of two frames
            for(int q = 0; q < 3; ++q)
                pixel[q] = static_cast<unsigned char>(frame2_pix[q]+(frame1_pix[q]*alpha));
        }
    }
}

// Copy cv::Mat
void ac::copyMat(const cv::Mat &src,unsigned int src_x, unsigned int src_y ,cv::Mat &target, const ac::Rect &rc) {
    for(int i = 0; i < rc.w; ++i) {
        for(int z = 0; z < rc.h; ++z) {
            //if(src_y+z < src.rows && src_x+i < src.cols && y+z < target.rows && x+i < target.cols) {
            ASSERT(src_y+z < src.rows && src_x+i < src.cols && rc.y+z < target.rows && rc.x+i < target.cols);
            cv::Vec3b &pixel = target.at<cv::Vec3b>(rc.y+z, rc.x+i);
            cv::Vec3b src_pixel = src.at<cv::Vec3b>(src_y+z, src_x+i);
            pixel = src_pixel;
            //}
        }
    }
}

void ac::copyMat(const cv::Mat &src, const Point &p, cv::Mat &target, const ac::Rect &rc) {
    copyMat(src, p.x, p.y, target, rc);
}

void ac::copyMat(const cv::Mat &src, unsigned int x, unsigned int y, cv::Mat &target, unsigned int rx, unsigned int ry, unsigned int rw, unsigned int rh) {
    copyMat(src, x,y,target,Rect(rx,ry,rw,rh));
}

void ac::fillRect(cv::Mat &m, const Rect &r, cv::Vec3b pixel) {
    for(int i = r.x; i < r.x+r.w; ++i) {
        for(int z = r.y; z < r.y+r.h; ++z) {
            ASSERT(i < m.cols && z < m.rows);
            cv::Vec3b &pix = m.at<cv::Vec3b>(z, i);
            pix = pixel;
        }
    }
}
/*
 ac::transformMat(frame, ac::Rect(0,0,frame.size()),  [](cv::Vec3b &pixel, unsigned int x, unsigned int y) {
 });
 */

template<typename F>
void ac::transformMat(cv::Mat &src, const ac::Rect &rc,F func) {
    for(int z = rc.y; z < rc.y+rc.h && z < src.rows; ++z) {
        for(int i = rc.x; i < rc.x+rc.w && i < src.cols; ++i) {
            cv::Vec3b &pixel = src.at<cv::Vec3b>(z, i);
            func(pixel, i, z);
        }
    }
}

// set custom callback
void ac::setCustom(DrawFunction f) {
    custom_callback = f;
}

// call custom fitler defined elsewhere
void ac::custom(cv::Mat &frame) {
    if(custom_callback != 0)
        custom_callback(frame);
}

void ac::setPlugin(DrawFunction f) {
    plugin_func = f;
}

void ac::plugin(cv::Mat &frame) {
    if(plugin_func != 0) {
        plugin_func(frame);
    }
}

ac::DrawFunction ac::getFilter(std::string name) {
    return ac::draw_func[filter_map[name]];
}

ac::DrawFunction ac::getRandomFilter(unsigned int &index) {
    unsigned int num;
    do {
        num = rand()%(draw_max-6);
    } while(ac::draw_strings[num] == "Blend Fractal" || ac::draw_strings[num] == "Blend Fractal Mood");
    index = num;
    return draw_func[num];
}
